import turtle as t

def koch(lengde,nivaa):
    if nivaa == 0:
        t.forward(lengde)
        return
    else:
        koch(lengde/3, nivaa-1)
        t.left(60)
        koch(lengde/3, nivaa-1)
        t.right(120)
        koch(lengde/3, nivaa-1)
        t.left(60)
        koch(lengde/3, nivaa-1)

def figur(lengde,nivaa):
    t.fillcolor(farger[-nivaa])
    t.begin_fill()
    koch(lengde, nivaa)
    t.right(120)
    koch(lengde, nivaa)
    t.right(120)
    koch(lengde, nivaa)
    t.right(120)
    t.end_fill()

# def again(lengde, nivaa, y):
#     t.right(120)
#     t.penup()
#     t.goto(0, y)
#     t.pendown()
#     figur(lengde, nivaa)

if __name__ == "__main__":
    #t.speed(0)
    t.setup(1200,800)
    t.bgcolor("dark blue")
    farger = ["green", "red", "silver", "gold"]
    t.tracer(0)
    t.right(60)
    # for y in range(100, 301, 100):
    #     again(y, y/100, y)

    for y in range(4, 0, -1):
        t.penup()
        t.goto(0, y*90)
        t.pendown()
        figur(y*150, y)

    t.update()
    t.done()
