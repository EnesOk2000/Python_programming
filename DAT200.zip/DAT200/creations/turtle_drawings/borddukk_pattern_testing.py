import turtle as t
t.speed(10)

t.dot(10)
t.goto(300,0)
t.dot(10)
t.goto(-300,0)
t.dot(10)
t.left(11.25)

for i in range(8):
    t.forward(100)
    t.left(112.5) #112.5
    t.forward(100)
    t.right(157.5) #157.5
    t.write(t.pos())

t.done()