import turtle as t

def line(lengde,nivaa):
    t.forward(lengde)
    t.backward(2*(lengde/3))
    t.left(30)
    t.forward(lengde/3)
    t.backward(lengde/3)
    t.right(60)
    t.forward(lengde/3)
    t.backward(lengde/3)
    t.left(30)

    t.forward(lengde/3)
    t.left(30)
    t.forward(lengde/6)
    t.backward(lengde/6)
    t.right(60)
    t.forward(lengde/6)
    t.backward(lengde/6)
    t.left(30)

    t.backward(2*(lengde/3))

def linje(lengde,nivaa):
    if nivaa == 0:
        t.forward(lengde)
        return
    t.forward(lengde/3)
    t.left(30)
    linje(lengde/4, nivaa-1)
    t.right(60)
    linje(lengde/4, nivaa-1)
    t.left(30)
    t.penup()
    t.backward(lengde/3)
    t.pendown()



if __name__ == "__main__":
    t.speed(0)
    t.setup(1200,800)
    #t.tracer(0)
    t.left(90)

    #for i in range(6):
    #    line(300,3)
    #    t.right(60)

    linje(300,3)

    #t.update()
    t.done()
