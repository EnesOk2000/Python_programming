import turtle as t
import math as m

def stjerne(lengde):
    t.forward(10)

if __name__ == "__main__":
    t.speed(0)
    #t.tracer(0)
    t.pensize(2)
    t.setup(0.8, 0.8)
    t.penup()
    t.goto(0, -100)
    t.pendown()

    antall_kanter = 11 # int(input("Skriv inn ønsket antall kanter: "))
    sum_vinkler=180*(antall_kanter-2)
    stor=sum_vinkler/antall_kanter
    inni=360/antall_kanter
    roter=inni/2

    radius=100
    pi=3.14
    cir=2*pi*radius
    lengde=cir/antall_kanter
    t.fillcolor("yellow")
    t.begin_fill()
    t.left(roter) # comment this one out to tilt or not tilt the whole figure.
    for i in range(antall_kanter):
        t.forward(lengde)
        t.left(inni) #stor, da vil du få stjerner tegnet opp
    t.end_fill()

    spissere=lengde*2 #base=lengde. jo høyere verdi, jo spissere spiss
    for g in range(antall_kanter):
        t.penup()
        p2=t.pos()
        #t.dot()
        t.forward(lengde/2)
        t.right(90)
        t.forward(spissere)
        p1=t.pos()
        #t.dot()
        t.backward(spissere)
        t.left(90)
        t.forward(lengde/2)
        p3=t.pos()
        #t.dot()
        t.pendown()
        t.fillcolor("red")
        t.begin_fill()
        t.goto(p1)
        t.goto(p2)
        t.goto(p3)
        t.end_fill()
        t.left(inni)
    

    # spisser utenfor mangekanten
    # for k in range(antall_kanter):
    #     t.right(60)
    #     t.forward(lengde)
    #     t.left(60*2)
    #     t.forward(lengde)
    #     t.right(60-inni)

    # spisser innenfor mangekanten
    # for q in range(antall_kanter):
    #     t.left(60)
    #     t.forward(lengde)
    #     t.right(60*2)
    #     t.forward(lengde)
    #     t.left(stor-60)



    # t.penup()
    # t.goto(0, -100)
    # t.pendown()
    # t.setheading(0)
    # t.circle(radius,360,antall_kanter)

    #t.update()
    t.done()
