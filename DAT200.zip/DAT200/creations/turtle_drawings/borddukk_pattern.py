import turtle as t

def kvadrat(lengde,i):
    if i%2:
        t.fillcolor("red")
        t.pencolor('red')
    else:
        t.fillcolor("dark red")
        t.pencolor('dark red')
    t.begin_fill()
    for i in range(4):
        t.forward(lengde)
        t.right(90)
    t.end_fill()

def stjerne(lengde,i):
    if i%2:
        t.fillcolor("red")
        t.pencolor('red')
        q = 0
    else:
        t.fillcolor("dark red")
        t.pencolor('dark red')
        q = 1
    t.begin_fill()
    for i in range(8):
        t.forward(lengde)
        t.left(112.5)
        t.forward(lengde)
        t.right(157.5)
    t.end_fill()
    if q:
        t.fillcolor("red")
        t.pencolor('red')
    else:
        t.fillcolor("dark red")
        t.pencolor('dark red')


if __name__ == "__main__":
    #t.speed(10)
    t.tracer(0)
    t.setup(0.8, 0.8, 0, 0)
    t.bgcolor("black")
    #t.hideturtle()

    lengde_kvadrat = 200 #200, 100
    lengde_stjerne = lengde_kvadrat * 0.344 # 70.43096
    kol = 6 #6 , 12
    rad = 3 #3 , 6


    t.penup()
    t.goto(-605,330)
    t.pendown()
    for k in range(rad): #3
        for i in range(kol): #6
            if k%2:
                w = i
            else:
                w = i+1
            kvadrat(lengde_kvadrat, w)
            t.forward(lengde_kvadrat/2)
            t.right(90-11.25)
            stjerne(lengde_stjerne, w+1)
            t.left(90-11.25)
            t.forward(lengde_kvadrat/2)
        t.penup()
        t.backward(kol*lengde_kvadrat)
        t.right(90)
        t.forward(lengde_kvadrat)
        t.left(90)
        t.pendown()


    t.update()
    t.done()
