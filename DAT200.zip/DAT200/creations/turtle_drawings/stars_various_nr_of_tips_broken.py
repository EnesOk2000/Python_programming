import turtle as t

def stjerne(lengde):
    t.left(11.5)
    le=90+45
    ri=180-45
    t.fillcolor("blue")
    t.begin_fill()
    for i in range(8):
        t.forward(lengde)
        t.left(le) # 112.5
        t.forward(lengde)
        t.right(ri) # 157.5
    t.end_fill()

if __name__ == "__main__":
    t.speed(5)
    #t.tracer(0)
    t.setup(0.8, 0.8)
    t.bgcolor("black")
    t.pencolor("yellow")
    t.pensize(5)

    t.penup()
    t.goto(-200, 100)
    t.pendown()
    #t.forward(100)

    #rotate = 25 # 11.5, 25

    #lengde=100
    #t.left(rotate)

    #stjerne(lengde)

    #for i in range(6):
    #    t.forward(lengde)
    #    t.left() # 112.5, 70
        # 112.5 = 90 + ro
        # 70 = 45 + ro
    #    t.forward(lengde)
    #    t.right(130) # 157.5, 130
        # 157.5 = 180 - ro/2  eller 135 + ro  gives 8: 8*5=40
        # 130 = 155 - ro    eller 115 + ro  gives 6: 6*5=30

    #t.right(rotate) #11.5
    #t.forward(300)
    #n=30
    #f=n*4

    #for i in range(20):
    #    t.forward(100)
    #    t.left(n)  #30
    #    t.forward(100)
    #    t.right(f) #120

    #angel = 60
    #i = angel/2

    #t.forward(100)
    #t.backward(100)
    #t.left(angel)
    #t.forward(100)
    #t.backward(100)
    #t.right(angel)

    #t.forward(100)
    #t.left(180-angel)
    #t.forward(100)

    #t.left(angel)
    #t.forward(200)


    #########star##############
    # y=5
    # n=360/y
    # lengde=100/(y/6)
    # t.forward(300)
    # t.backward(300)
    # for i in range(y):
    #     t.forward(lengde)
    #     t.left(n) #45
    #     t.forward(lengde)
    #     t.right(n*2) #90
    #########star##############
    t.speed(1)
    antall = 4
    vinkel = 120/antall
    avinkel = vinkel+antall*vinkel
    lengde = 100
    # antall = 4
    # vinkel = 120/antall
    # avinkel = antall*30
    #
    for i in range(4): #3, 4, 8
        t.forward(lengde)
        t.left(vinkel) # 40, 30, 20
        t.forward(lengde)
        t.right(avinkel) # 160, 120, 80

    #t.update()
    t.done()
