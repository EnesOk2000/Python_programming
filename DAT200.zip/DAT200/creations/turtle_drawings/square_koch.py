import turtle as t

def koch(lengde,nivaa):
    if nivaa == 0:
        t.forward(lengde)
        return
    else:
        koch(lengde/3, nivaa-1)
        t.left(90)
        koch(lengde/3, nivaa-1)
        t.right(90)
        koch(lengde/3, nivaa-1)
        t.right(90)
        koch(lengde/3, nivaa-1)
        t.left(90)
        koch(lengde/3, nivaa-1)

def figur(lengde,nivaa):
    koch(lengde, nivaa)
    t.right(90)
    koch(lengde, nivaa)
    t.right(90)
    koch(lengde, nivaa)
    t.right(90)
    koch(lengde, nivaa)
    t.right(90)

if __name__ == "__main__":
    #t.speed(10)
    t.setup(1200,800)
    t.tracer(0)

    t.penup()
    t.goto(-400, 300)
    t.pendown()
    figur(200,0)

    t.penup()
    t.goto(200, 300)
    t.pendown()
    figur(200,1)

    t.penup()
    t.goto(-400, -50)
    t.pendown()
    figur(200,2)

    t.penup()
    t.goto(50, -50)
    t.pendown()
    figur(200,3)




    t.update()
    t.done()
