class Koe:
    # Legger et element på slutten av køen
    def enqueue(self, element):
        pass

    # Tar ut et element fra starten av køen
    def dequeue(self):
        pass

    # Returnerer første element i køen uten å fjerne det
    def peek(self):
        pass


class Deque:
    # Legger et element på slutten av køen. Tilsvarer enqueue
    def append(self, element):
        pass

    # Legger et element på starten av køen
    def appendleft(self, element):
        pass

    # Tar ut et element fra slutten av køen
    def pop(self):
        pass

    # Tar ut et element fra starten av køen. Tilsvarer dequeue
    def popleft(self):
        pass

    # Returnerer siste element i køen uten å fjerne det
    def peek(self):
        pass

    # Returnerer første element i køen uten å fjerne det
    def peekleft(self):
        pass

