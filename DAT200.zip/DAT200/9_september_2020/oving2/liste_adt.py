class Liste:
    # Legger til element på slutten av lista
    def append(self, element):
        pass

    # Legger inn det oppgitte elementet på oppgitt indeks, og forskyver alle elementer som ligger
    # etterpå ett hakk bak
    def insert(self, indeks, element):
        pass

    # Overskriver det som ligger på oppgitt indeks med det oppgitte elementet.
    # Tilsvarer Python liste[indeks] = element
    def put(self, indeks, element):
        pass

    # Fjerner første forekomst av oppgitt element
    def remove(self, element):
        pass

    # Fjerner elementet på oppgitt indeks
    # Tilsvarer Python del liste[indeks]
    def delete(self, indeks):
        pass

    # Legger alle elementete i oppgitt samling til i lista
    def append_all(self, samling):
        pass

    # Setter inn den oppgitte samlingen på oppgitt indeks, og forskyver alt som ligger bak
    def insert_all(self, indeks, samling):
        pass

    # Returnerer elementet på oppgitt indeks.
    # Tilsvarer Python variabel = liste[indeks]
    def get(self, indeks):
        pass

    # Finner første indeks hvor dette elementet forekommer
    def search(self, element):
        pass

    # Gå gjennom lista, element for element
