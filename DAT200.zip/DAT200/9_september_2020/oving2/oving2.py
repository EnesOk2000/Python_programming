import numpy as np

class ArrayListe:
    def __init__(self, startkapasitet = 10, startbuffer = 3):
        self.array = np.zeros(startkapasitet, dtype=object)
        self.lengde = 0
        self.startbuffer = startbuffer

    def __len__(self):
        return self.lengde

    def utvid(self, ny_storrelse=None):                     # Kjøretid Theta(n)
        if ny_storrelse is None:
            ny_storrelse = len(self.array)*3
        ny_array = np.zeros(ny_storrelse, dtype=object)
        ny_startbuffer = len(self.array)
        for index in range(len(self.array)):
            ny_array[index+ny_startbuffer] = self.array[index]
        self.array = ny_array
        self.startbuffer = ny_startbuffer

    def append(self, element):                  # Kjøretid: Worst case Theta(n) hvis jeg må lage en ny array ellers Theta(1)
        if self.lengde+self.startbuffer-1 >= len(self.array):
            self.utvid()
        self.array[self.lengde+self.startbuffer] = element
        self.lengde += 1

    def appendleft(self, element):              # Kjøretid: Theta(n)
        if self.startbuffer <= 0:
            self.utvid()
        self.startbuffer -= 1
        self.array[self.startbuffer] = element # må kanskje endre denne litt
        self.lengde += 1


    def pop(self):
        var = self.array[-1+self.lengde+self.startbuffer]        # Kjøretid Theta(1)
        self.array[-1+self.lengde+self.startbuffer] = 0       # Kjøretid Theta(1)

        #print(var)
        return var

    def popleft(self):
        var = self.array[self.startbuffer]        # Kjøretid Theta(1)
        self.array[self.startbuffer] = 0       # Kjøretid Theta(1)

        #print(var)
        return var

    def insert(self, indeks, element):          # Best case på slutten O(1).    Worst case starten O(n)
        if self.lengde >= len(self.array):
            self.utvid()
        for index in range(self.lengde-1, indeks-1, -1):
            self.array[index+1] = self.array[index]
        self.array[indeks] = element
        self.lengde += 1

    def put(self, indeks, element):     # Kjøretid Theta(1)
        self.array[indeks] = element

    def remove(self, element):          # Kjøretid Theta(1)
        index = self.search(element)
        self.delete(index)

    def delete(self, indeks):                   # Best case siste element O(1). Worst case første element O(n)
        for i in range(indeks, self.lengde):
            self.array[i] = self.array[i+1]
        self.lengde -= 1

    def append_all(self, samling):                              # Kjøretid O(m) best case. Kjøretid O(n + m) worst case
        if self.lengde + len(samling) >= len(self.array):
            self.utvid((self.lengde + len(samling))*2)
        for element in samling:
            self.append(element)

    def insert_all(self, indeks, samling):                  # Kjøretid O(n)
        if self.lengde + len(samling) >= len(self.array):
            self.utvid((self.lengde + len(samling))*2)
        for i in range(self.lengde-1, indeks-1, -1):
            self.array[i+len(samling)] = self.array[i]
        for i in range(len(samling)):
            self.array[indeks+i] = samling[i]

    def get(self, indeks):          # Kjøretid Theta(1)
        return self.array[indeks]

    def search(self, element):
        for index in range(self.lengde):        # Kjører maks n ganger
            if element == self.array[index]:    # Kjører maks n ganger
                return index                    # Kjører maks 1 gang
        return -1                               # Kjører maks 1 gang

    def __iter__(self):
        return ArrayListIterator(self)

    def __getitem__(self, item):
        return self.get(item)

    def __setitem__(self, key, value):
        self.put(key, value)

    def __contains__(self, item):
        if self.search(item) != -1:
            return True
        return False

    def __delitem__(self, key):
        self.delete(key)

class ArrayListIterator:
    def __init__(self, lista):
        self.lista = lista
        self.nv_element = 0

    def __next__(self):
        if self.nv_element >= len(self.lista):
            raise StopIteration
        resultat = self.lista.get(self.nv_element)
        self.nv_element += 1
        return resultat

if __name__ == "__main__":
    liste = ArrayListe(10)
    print("- - -",end=" ")
    for index in range(7):
            print(index,end=" ")
    print()
    for index in range(10):
        print(index,end=" ")
    print()
    for i in range(0,10):
        print(liste[i],end=" ")

    print()
    print("*******************************")
    liste.append(2)
    liste.append(5)
    liste.append(7)
    print("- - -",end=" ")
    for index in range(7):
            print(index,end=" ")
    print()
    for index in range(10):
        print(index,end=" ")
    print()
    for i in range(0,10):
        print(liste[i],end=" ")
    print()
    print("*******************************")
    print()
    liste.appendleft(9)
    print("- - -",end=" ")
    for index in range(7):
            print(index,end=" ")
    print()
    for index in range(10):
        print(index,end=" ")
    print()
    for i in range(0,10):
        print(liste[i],end=" ")
    print()
    print("*******************************")
    print()
    liste.appendleft(4)
    liste.appendleft(12)
    liste.appendleft(15) # før denne settes inn skal startbuffer utvides med len(self.array)*2

    liste.popleft()
    for i in range(0,30):
        print(liste[i],end=" ")
    print()
    #for element in liste:
    #    print(element, end=" ")
    #print()
    #print(liste[-8])
