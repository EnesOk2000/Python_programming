# Binærsøk:
# - Sammenlikn det du leiter etter med midten av lista
# - Hvis det du leiter etter er større, sjekk slutten av lista
# - Hvis det du leiter etter er mindre, sjekk starten
# - Hvis det er likt har du funnet det
# - Har lista ett element som er ulikt det du leiter etter, fins ikke elementet i lista
def binaersoek(sortert_liste, element):
    midten = len(sortert_liste)//2
    if sortert_liste[midten] == element:
        return midten
    if len(sortert_liste) == 1:
        return -1
    if sortert_liste[midten] < element:
        resultat = binaersoek(sortert_liste[midten:], element)
        if resultat == -1:
            return -1
        else:
            return midten + resultat
    if sortert_liste[midten] > element:
        return binaersoek(sortert_liste[:midten], element)


if __name__ == "__main__":
    liste = [2, 5, 6, 8, 15, 18, 23, 24, 29]
    print(binaersoek(liste, 8))
    print(binaersoek(liste, 25))
    print(binaersoek(liste, 29))
    print(binaersoek(liste, 2))

