# Rekursjon versjon av algoritmen
# Kjøretid O(n)
# Minnebruk O(n)
def palindrom_rekursjon(ord):
    if len(ord) == 0 or len(ord) == 1:
        print(ord)
        return True
    elif ord[0] == ord[-1]:
        print(ord)
        ord=ord[1:]
        ord=ord[:-1]
        return palindrom_rekursjon(ord)
    else:
        print(ord)
        return False

# Iterativ versjon av algoritmen
# Kjøretid Theta(n/2)
# Minnebruk Theta(1)
def palindrom_iterativ(ord):
    if ord == 0 or ord == 1:
        return True
    for i in range(len(ord)//2+1):
        print(ord[i], ord[-i-1])
        if ord[i] == ord[-i-1]:
            continue
        else:
            return False
    return True

if __name__ == "__main__":
    print(palindrom_rekursjon("regninger"))
    print()
    print(palindrom_rekursjon("reginger"))
    print("\n********************************\n")
    print(palindrom_iterativ("regninger"))
    print()
    print(palindrom_iterativ("reginger"))
