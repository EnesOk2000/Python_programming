class Hanoi:
    def __init__(self, antDisk):
        self.antDisk = antDisk
        self.start = []
        self.mellom = []
        self.slutt = []
        for i in range(antDisk, 0, -1):
            self.start.append(i)
        self.skriv()
        self.teller = 0

    def skriv(self):
        print(self.start, "\t\t", self.mellom, "\t\t", self.slutt)

    def flytt(self, fra, til):
        til.append(fra[-1])
        fra.pop(-1)
        self.skriv() ### Kommenter denne ut for å få bort hvert steg

    def vinn(self, n, fra, hjelp, til):
        if n == 0:
            self.teller += 1
            if self.teller == 2**self.antDisk:
                self.skriv()
            return
        else:
            self.vinn(n-1, fra, til, hjelp)
            self.flytt(fra, til)
            self.vinn(n-1, hjelp, fra, til)

    def antSteg(self):
        print(self.teller)

if __name__ == "__main__":
    tall = 5
    hanoi = Hanoi(tall)
    hanoi.vinn(tall, hanoi.start, hanoi.mellom, hanoi.slutt)
    hanoi.antSteg()

