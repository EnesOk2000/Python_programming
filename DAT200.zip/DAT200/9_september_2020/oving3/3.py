import turtle as t

def koch(lengde,nivaa):
    if nivaa == 0:
        t.forward(lengde)
        return
    else:
        koch(lengde/3, nivaa-1)
        t.left(60)
        koch(lengde/3, nivaa-1)
        t.right(120)
        koch(lengde/3, nivaa-1)
        t.left(60)
        koch(lengde/3, nivaa-1)

def figur(lengde,nivaa):
    koch(lengde, nivaa)
    t.right(120)
    koch(lengde, nivaa)
    t.right(120)
    koch(lengde, nivaa)

if __name__ == "__main__":
    #t.speed(10)
    t.tracer(0)
    t.penup()
    t.goto(-300, 150)
    t.pendown()
    figur(500,3)
    t.update()
    t.done()
