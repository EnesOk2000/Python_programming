def tri(n):
    tall = 0
    for i in range(n+1):
        tall += i
    return tall

for i in range(11):
    print(tri(i))
print(tri(20))

# Samme bare skrevet i golang
#func triangular(n uint) uint{
#	tall := 0
#	for i := 0; n+1; i++ {
#		tall += i
#	}
#    return tall
#}
