import random
import time
import sortering.innsettingssortering
import sortering.shellsort
import sortering.flettesortering
import sortering.quicksort
import sortering.timsort
import sortering.tellesortering


# Lager tilfeldig liste
def lag_tilfeldig_liste(lengde, rekkevidde = 1000):
    liste = []
    for i in range(lengde):
        liste.append(random.randint(-rekkevidde,rekkevidde))
    return liste


# For å teste nesten sorterte lister
def lag_nesten_sortert_liste(listelengde, permutasjon):
    liste = []
    for i in range(listelengde):
        liste.append(i + random.randint(-permutasjon, permutasjon))
    return liste


# For å teste liste med sorterte del-lister
def lag_liste_med_runs(listelengde, lengdeparameter=1000):
    liste = []
    teller = 0
    for i in range(listelengde):
        liste.append(teller)
        teller += 1
        if random.randint(0,lengdeparameter) == 0:
            teller -= 100
    return liste


# Kjøretid O(n)
def lista_sortert(liste):
    for index in range(len(liste) - 1):
        if liste[index] > liste[index+1]:
            return False
    return True


# Finner laveste og høyeste verdi i ei liste, for tellesortering. Kjøretid Theta(n)
def min_maks_verdi(liste):
    min_verdi = liste[0]
    maks_verdi = liste[0]
    for element in liste:
        if element < min_verdi:
            min_verdi = element
        if element > maks_verdi:
            maks_verdi = element
    return min_verdi, maks_verdi


def kjor_test(liste, med_enkle, ekstratekst):
    print()
    if med_enkle:
        # Innsettingsortering
        liste2 = liste[:]
        print(lista_sortert(liste2))
        tid_start = time.process_time()
        sortering.innsettingssortering.sorter(liste2)
        tid_slutt = time.process_time()
        print(lista_sortert(liste2))
        print(f"Tid innsettingssortering {len(liste2)} {ekstratekst} elementer: {tid_slutt - tid_start}")

        # Shell sort
        liste2 = liste[:]
        print(lista_sortert(liste2))
        tid_start = time.process_time()
        sortering.shellsort.sorter(liste2)
        tid_slutt = time.process_time()
        print(lista_sortert(liste2))
        print(f"Tid shell sort {len(liste2)} {ekstratekst} elementer: {tid_slutt - tid_start}")

    # Flettesortering
    liste2 = liste[:]
    print(lista_sortert(liste2))
    tid_start = time.process_time()
    liste2 = sortering.flettesortering.flettesortering_bytter_algoritme(liste2)
    tid_slutt = time.process_time()
    print(lista_sortert(liste2))
    print(f"Tid flettesortering {len(liste2)} {ekstratekst} elementer: {tid_slutt-tid_start}")

    # quicksort
    liste2 = liste[:]
    print(lista_sortert(liste2))
    tid_start = time.process_time()
    sortering.quicksort.sorter(liste2)
    tid_slutt = time.process_time()
    print(lista_sortert(liste2))
    print(f"Tid quicksort {len(liste2)} {ekstratekst} elementer: {tid_slutt-tid_start}")

    # Tellesortering
    liste2 = liste[:]
    print(lista_sortert(liste2))
    tid_start = time.process_time()
    min_verdi, maks_verdi = min_maks_verdi(liste2)
    liste2 = sortering.tellesortering.tellesortering(liste2, min_verdi, maks_verdi)
    tid_slutt = time.process_time()
    print(lista_sortert(liste2))
    print(f"Tid tellesortering {len(liste2)} {ekstratekst} elementer: {tid_slutt-tid_start}")


if __name__ == "__main__":
    # Lager første liste
    liste = lag_tilfeldig_liste(5000, 5000)
    kjor_test(liste, True, "tilfeldige")

    # Lager større liste for å teste de raske algoritmene
    liste = lag_tilfeldig_liste(150000, 50000)
    kjor_test(liste, False, "tilfeldige")

    liste = lag_nesten_sortert_liste(150000, 20)
    kjor_test(liste, True, "nesten sorterte")

    liste = lag_liste_med_runs(150000)
    kjor_test(liste, True, "sorterte del-lister")
