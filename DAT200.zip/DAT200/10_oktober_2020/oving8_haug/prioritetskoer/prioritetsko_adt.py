class Prioritetsko:
    # Legg inn et element med oppgitt prioritet
    def add(self, verdi, prioritet):
        pass

    # Tar ut og returnerer verdien med lavest verdi i "prioritet" variabelen
    def remove(self):
        pass

    # Finner verdien med laveste verdi i "prioritet" variabelen og returnerer den, men fjerner den ikke
    def peek(self):
        pass

    # Setter prioriteten til en ny verdi
    def senk_prioritet(self, verdi, ny_prioritet):
        pass
    