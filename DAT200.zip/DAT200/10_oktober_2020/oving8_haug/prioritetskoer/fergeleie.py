from binaerhaug import Prioritetsko
from collections import deque
import random

# LØsningsforslag øving 8 oppgave 3: Fergeleie

HENDELSE_KJORETOY_KOMMER = 1
HENDELSE_FERGE_KOMMER = 2

# Parameter: Hvor lang tid i sekunder det tar mellom hvert fergeanløp. 30 minutter * 60 sekunder = 1800 sekunder.
TID_MELLOM_FERGEANLOP = 1800

# Kapasitet til ferga
FERGE_KAPASITET = 80 # 40, 200

MAKS_TID = 20000

# Uforandret
class Hendelse:
    def __init__(self, type, tidsstempel):
        self.type = type
        self.tidsstempel = tidsstempel


# Parameter: Lengde til kjøretøy
def finn_lengde_kjoretoy():
    tilfeldig_tall = random.randint(1, 100)
    if tilfeldig_tall <= 75:
        return 1
    if tilfeldig_tall <= 85:
        return 2
    if tilfeldig_tall <= 90:
        return 4
    return random.randint(3, 8)


# Funksjon som håndterer hendelsen "kjøretøy ankommer fergeleie"
def haandter_kjoretoy_kommer(kjoretoy, hendelser, tidspunkt):
    global kjoretoy_id
    lengde_kjoretoy = finn_lengde_kjoretoy()
    print(f"Håndterer at et kjøretøy med lengde {lengde_kjoretoy} kommer på tid {tidspunkt}")
    kjoretoy.append(lengde_kjoretoy)
    ny_tid = tidspunkt + random.randint(1, 60)
    hendelser.add(ny_tid, Hendelse(HENDELSE_KJORETOY_KOMMER, ny_tid))


# Funksjon som håndterer hendelsen "ferga kommer"
def haandter_ferge_kommer(kjoretoy, hendelser, tidspunkt):
    naavaerende_kapasitet = FERGE_KAPASITET
    print(f"Ferga kommer på tid {tidspunkt}. {len(kjoretoy)} kjøretøy venter.")
    while len(kjoretoy) > 0:
        lengde = kjoretoy[0]
        if lengde > naavaerende_kapasitet:
            break
        naavaerende_kapasitet -= kjoretoy.popleft()
    ny_tid = tidspunkt + TID_MELLOM_FERGEANLOP
    hendelser.add(ny_tid, Hendelse(HENDELSE_FERGE_KOMMER, ny_tid))


# Kjører selve simuleringen
def kjor_simulering():
    # Initialiserer FIFO kø, prioritetskø og systemtid
    kjoretoy = deque()
    hendelser = Prioritetsko()
    systemtid = 0

    # Ønsker å finne maksimal kølengde. Har derfor variabel for dette her.
    maks_koelengde = 0

    # Legger til en hendelse for at et kjøretøy kommer og en hendelse for at ferga kommer
    # for å starte simuleringen.
    hendelser.add(0, Hendelse(HENDELSE_KJORETOY_KOMMER, 0))

    # Løkke som kjører simuleringen helt til maksimaltid er oppnådd.
    while systemtid < MAKS_TID:
        hendelse = hendelser.remove()
        systemtid = hendelse.tidsstempel
        if hendelse.type == HENDELSE_KJORETOY_KOMMER:
            haandter_kjoretoy_kommer(kjoretoy, hendelser, systemtid)
        if hendelse.type == HENDELSE_FERGE_KOMMER:
            haandter_ferge_kommer(kjoretoy, hendelser, systemtid)
        if len(kjoretoy) > maks_koelengde:
            maks_koelengde = len(kjoretoy)
    print(f"Simulering ferdig. Maks kølengde = {maks_koelengde}")


if __name__ == "__main__":
    kjor_simulering()

# Konklusjon: Ferga som er 80 stor er litt for liten. Ferga som er 200 stor er stor nok.
# Egentlig hadde en ferge på kanskje 120 vært ideell. To ferger, en på 80 og en på 40 hadde
# også fungert.
