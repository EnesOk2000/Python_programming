## Enes Ok
## Pholit Hantula
from binaerhaug import Prioritetsko
from collections import deque
import random

HENDELSE_ANKOMMET = 1
HENDELSE_BEHANDLET = 2

STORRELSE_BAAT = 200 ##############################
TID_MELLOM_HVER_FERGE = 1800 ###################### 30 minutter * 60 sekunder = 1800 sekunder.

PASSASJERKOE_TOM = -1
MAKS_TID = 100000

class Hendelse:
    def __init__(self, type, tidsstempel):
        self.type = type
        self.tidsstempel = tidsstempel

def finn_lengde_kjoretoy():
    tilfeldig_tall = random.randint(1, 100)
    if tilfeldig_tall <= 75:
        return 1
    if tilfeldig_tall <= 85:
        return 2
    if tilfeldig_tall <= 90:
        return 4
    return random.randint(3, 8)

def haandter_ankomst(passasjerer, hendelseskoe, systemtid):
    lengde_kjoretoy = finn_lengde_kjoretoy()
    passasjerer.append(lengde_kjoretoy)
    print(f"Passasjer ankommer på tid: {systemtid}. Passasjerkølengde {len(passasjerer)}. Kjøretøy med lengde {lengde_kjoretoy}.")
    ny_tid = systemtid + random.randint(1, 30)
    hendelsen = Hendelse(HENDELSE_ANKOMMET, ny_tid)
    hendelseskoe.add(hendelsen, ny_tid) ###### denne her er motsatt i fergeleie_untouched.py


def haandter_behandlet(passasjerer, hendelseskoe, systemtid):
    if len(passasjerer) == 0:
        print(f"Skulle behandle passasjer men køen er tom. Tid {systemtid}")
    else:

        #print(f"Behandlet passasjer på tid: {systemtid}. Passasjerkølengde {len(passasjerer)}")
        ledig_plass = STORRELSE_BAAT ##################################
        print(f"Ferga kommer på tid {systemtid}. {len(passasjerer)} kjøretøy venter.")
        while len(passasjerer) > 0: ############################## ledig_plass: kjører evig hvis båten ikke er full
            lengde = passasjerer[0]
            if lengde > ledig_plass:
                print("Båten er full. Ingen buss etc mer nå.")
                break
            print(f"Båt fylles. Passasjer går inn i båt på tid: {systemtid}. Passasjerkølengde {len(passasjerer)}. Kjøretøy med lengde {lengde}.")
            ledig_plass -= passasjerer.popleft()
    ny_tid = systemtid + TID_MELLOM_HVER_FERGE
    hendelsen = Hendelse(HENDELSE_BEHANDLET, ny_tid)
    hendelseskoe.add(hendelsen, ny_tid)


def kjor_simulering():
    hendelseskoe = Prioritetsko()
    passasjerer = deque()
    systemtid = 0

    maks_koelengde = 0

    antall_behandlet = 0
    antall_ledige_ganger = 0

    hendelseskoe.add(Hendelse(HENDELSE_ANKOMMET, 0), 0)
    hendelseskoe.add(Hendelse(HENDELSE_BEHANDLET, TID_MELLOM_HVER_FERGE), TID_MELLOM_HVER_FERGE)

    while systemtid < MAKS_TID:
        hendelse = hendelseskoe.remove()
        systemtid = hendelse.tidsstempel
        if hendelse.type == HENDELSE_ANKOMMET:
            haandter_ankomst(passasjerer, hendelseskoe, systemtid)
            if len(passasjerer) > maks_koelengde:
                maks_koelengde = len(passasjerer)
        if hendelse.type == HENDELSE_BEHANDLET:
            haandter_behandlet(passasjerer, hendelseskoe, systemtid)

    print("Simulering ferdig")
    print(f"Maksimal kølengde: {maks_koelengde}. Dermed trengs det området med plass til så mange personbiler.")
    if STORRELSE_BAAT*0.75 < maks_koelengde < STORRELSE_BAAT*1.25:
        print(f"Denne båten er stor nok sidend en har plass til {STORRELSE_BAAT}.")
    elif STORRELSE_BAAT*0.75 > maks_koelengde:
        print(f"Båten er for stor! Båten må være mindre enn {STORRELSE_BAAT}.")
    elif STORRELSE_BAAT*1.25 < maks_koelengde:
        print(f"Båten er for liten! Båten må være større enn {STORRELSE_BAAT}.")

if __name__ == "__main__":
    kjor_simulering()
