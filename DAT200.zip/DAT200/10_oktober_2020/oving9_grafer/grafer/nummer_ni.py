from binaerhaug import Prioritetsko

class Intervall:
    def __init__(self, start, slutt):
        if slutt < start:
            raise ValueError("Et intervall kan ikke slutte før det starter!")
        self.__start = start
        self.__slutt = slutt
    @property
    def start(self):
        return self.__start
    @property
    def slutt(self):
        return self.__slutt
    def __str__(self):
        return f"Intervall ({self.start} -> {self.slutt})"

# Forventer ei liste av intervaller som input
def intervall_tester(intervall_liste):
    koe = Prioritetsko()                        # Binærhaug / Binary Heap
    resultat = []
    aktive = []
    print("en")
    for intervall in intervall_liste: # n kjøretid
        print("en")
        koe.add(intervall, intervall)
    while len(koe) > 0: # n kjøretid
        nv_tid = koe.lavest_prioritet()         # Henter ut prioriteten til elementet som skal hentes ut. Kjøretid Theta(1)
        nv_intervall = koe.remove()     # Kjøretid O(log(n)) i nesten alle tilfeller
        print("en")
        if nv_tid == nv_intervall.start:
            koe.add(nv_intervall, nv_intervall.slutt) # Kjøretid O(1) best case, O(log(n)) worst case
            for intervall in aktive:
                resultat.append((nv_intervall, intervall))
            aktive.append(nv_intervall)
        else:
            aktive.remove(nv_intervall)
    print("tom")
    return resultat

if __name__ == "__main__":
    il = []
    intervall_tester(il)
