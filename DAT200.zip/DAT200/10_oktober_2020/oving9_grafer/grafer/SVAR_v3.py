from graf_naboliste import GrafNaboliste
from binaerhaug import Prioritetsko

def open_file():
    with open("oving_9_eksempelfil.txt", "r") as file:
        width = int(file.readline())
        height = int(file.readline())
        camp_xcor = int(file.readline())
        camp_ycor = int(file.readline())
        mountain_xcor = int(file.readline())
        mountain_ycor = int(file.readline())
        B = []
        for x in range(width):
            B.append([])
        for line in file:
            numbers = line.split(",")
            col_val = 0
            for number in numbers:
                try:
                    j = int(number)
                    B[col_val].append(j)
                    col_val += 1
                except ValueError:
                    pass
        print("**************B-MATRISEN MED ALLE FJELLHØYDENE****************")
        print()
        # this nested for loop says: for every column, make a row.
        for j in range(len(B[0])): # for every col until last col, 8
            for i in range(len(B)): # for every row as long as there are rows, 12
                print(B[i][j], end=" ")
            print()
        print()

    grafen = GrafNaboliste()
    print("*******KOORDINATENE******")
    print()
    B_start = 0
    B_slutt = 0
    ### For loop som lager alle nodene
    for j in range(0, height):
        for i in range(0, width):
            print(f"({i},{j})", end=" ")
            grafen.add_node(f"({i},{j})")
            if i == camp_xcor and j == camp_ycor:
                #print()
                #print()
                startnode = B_start
                #print(startnode, i, j)
                #print()
                #print()
            if i == mountain_xcor and j == mountain_ycor:
                #print()
                #print()
                sluttnode = B_slutt
                #print(sluttnode, i, j)
                #print()
                #print()
            B_start += 1
            B_slutt += 1
        print()

    print()
    print("***********LAGER ALLE HORISONTALE KANTENE*****************")
    ### for loop som lager alle HORISONTALE kantene
    node_nr = -2
    for j in range(0, height):
        node_nr += 1
        print()
        for i in range(0, width-1):
            node_nr += 1
            #print("*", end=" ")
            hoydeforskjell = abs(B[i+1][j]-B[i][j])
            vekt = 1 + hoydeforskjell
            print(f"Vekt mellom node {node_nr} og {node_nr+1}: {vekt}")
            grafen.add_edge(node_nr, node_nr+1, vekt)
            grafen.add_edge(node_nr+1, node_nr, vekt)

    print()
    print("***********LAGER ALLE VERTIKALE KANTENE*****************")
    ### for loop som lager alle VERTIKALE kantene
    q = -1
    for j in range(0, height-1):
        print()
        for i in range(0, width):
            q += 1
            #print("*", end=" ")
            hoydeforskjell = abs(B[i][j+1]-B[i][j])
            vekt = 1 + hoydeforskjell
            print(f"Vekt mellom node {q} og {q+width}: {vekt}")
            grafen.add_edge(q, q+width, vekt)
            grafen.add_edge(q+width, q, vekt)
    print()
    return grafen, startnode, sluttnode

#def bygg_demograf():
def dijkstra(graf, startnode, sluttnode):
    nodekoe = Prioritetsko()                # Theta(1)
    graf.fjern_kostnader()                  # Theta(V)
    graf.set_kostnad(startnode, 0)          # Theta(1)
    nodekoe.add(startnode, 0)               # Theta(1)
    while len(nodekoe) > 0:                 # Kjører O(V) ganger
        nv_node = nodekoe.remove()          # O(log(V)) med binærhaug, O(V) med array-basert
        if nv_node == sluttnode:            # O(1)
            return
        naboer = graf.get_naboer(nv_node)   # Totalt O(E)
        for nabo in naboer:                 # Totalt O(E)
            kostnad_til_nabo = graf.get_kostnad(nv_node) + graf.get_vekt(nv_node, nabo)     # Theta(1)
            if graf.get_kostnad(nabo) is None:
                graf.set_kostnad(nabo, kostnad_til_nabo)
                graf.set_forrige_node(nabo, nv_node)
                nodekoe.add(nabo, kostnad_til_nabo)                 # O(log(V)) med binærhaug, O(1) array-basert
            elif graf.get_kostnad(nabo) > kostnad_til_nabo:
                graf.set_kostnad(nabo, kostnad_til_nabo)
                graf.set_forrige_node(nabo, nv_node)
                nodekoe.senk_prioritet(nabo, kostnad_til_nabo)      # O(log(V)) med binærhaug, O(1) array-basert


def skriv_korteste_vei(grafen, startnode):
    nv_node = startnode
    arr =[]
    while nv_node is not None:
        #print(f"Node: {grafen.get_nodedata(nv_node)}")
        arr.append(grafen.get_nodedata(nv_node))
        nv_node = grafen.get_forrige_node(nv_node)
    for i in range(len(arr)-1,-1,-1):
        #if i == 0:
        #    print(arr[i], end=" ")
        #else:
        #    print(f"{arr[i]} --->", end=" ")
        print(arr[i])

if __name__ == "__main__":
    grafen, startnode, sluttnode = open_file()
    print("**********HER ER TESTEN***********")
    print()
    dijkstra(grafen, startnode, sluttnode)
    print(f"Korteste vei fra Camp til Mosefejll: {grafen.get_kostnad(sluttnode)}")
    print()
    skriv_korteste_vei(grafen, sluttnode)
