######### SVAR PÅ ØVING 9 - GRAFER #########
from graf_naboliste import GrafNaboliste
from binaerhaug import Prioritetsko

def open_file():
    with open("oving_9_eksempelfil.txt", "r") as file:
        width = int(file.readline())
        height = int(file.readline())
        camp_xcor = int(file.readline())
        camp_ycor = int(file.readline())
        mountain_xcor = int(file.readline())
        mountain_ycor = int(file.readline())
        # print(width, height, camp_xcor, camp_ycor, mountain_xcor, mountain_ycor, sep="\n")
        A = []
        # M , antall rader, bredde
        # N,  antall kolonner , høyde
        # i, index for radnummer, xcor
        # j, index for kolonnenummer, ycor
        B =[]
        for x in range(width):
            B.append([])
        for line in file:
            numbers = line.split(",")
            alle_elementer_i_en_rad = []
            col_val = 0
            for number in numbers:
                try:
                    j = int(number)
                    B[col_val].append(j)
                    col_val += 1
                    alle_elementer_i_en_rad.append(j)
                except ValueError:
                    # print("PASS")
                    pass
            # print(alle_elementer_i_en_rad)
            if alle_elementer_i_en_rad:  # Means the same as alle_elementer_i_en_rad != [] because bool([]) = False.
                A.append(alle_elementer_i_en_rad)
        print("**************A-MATRISEN MED ALLE FJELLHØYDENE****************")
        for y in A:
            for x in y:
                print(x, end=" ")
            print()
        print("*********")
        for j in range(len(B[0])): # for every col until last col
            for i in range(len(B)): # for every row as long as there are rows
                print(B[i][j], end=" ")
            print()


        print(A[0][2])
        print(A)
        print(B)
        print(B[0][2])
    #return width, height, camp_xcor, camp_ycor, mountain_xcor, mountain_ycor, A

    A_start = 0
    A_slutt = 0
    #for x in A:
        #for y in x:
            #A_start+=1
            #if x == camp_xcor & y == camp_ycor:
            #    startnode = A_start
            #    print(A_start)


    grafen = GrafNaboliste()
    #a = grafen.add_node("A")        # Indeks 0
    #b = grafen.add_node("B")        # Indeks 1
    print()
    print(mountain_xcor, mountain_ycor)
    print("*******KOORDINATENE******")
    ### For loop som lager alle nodene
    for i in range(0, height):
        for j in range(0, width):
            print(f"({i},{j})", end=" ")
            grafen.add_node(f"({i},{j})")
            if j == camp_xcor and i == camp_ycor:
                #print()
                #print()
                startnode = A_start
                #print(startnode, i, j)
                #print()
                #print()
            if j == mountain_xcor and i == mountain_ycor:
                #print()
                #print()
                sluttnode = A_slutt
                #print(sluttnode, i, j)
                #print()
                #print()
            A_start += 1
            A_slutt += 1
        print()

    antall_noder = width*height
    #print(antall_noder)
    #grafen.add_edge(0, 1, 5)
    #grafen.add_edge(1, 0, 5)
    print()
    print("***********LAGER ALLE HORISONTALE KANTENE*****************")
    ### for loop som lager alle HORISONTALE kantene
    node_nr = -2
    for i in range(0, height):
        node_nr += 1
        print()
        for j in range(0, width-1):
            node_nr += 1
            #print("*", end=" ")
            hoydeforskjell = abs(A[i][j+1]-A[i][j])
            vekt = 1 + hoydeforskjell
            #print(i, end=" ")
            #print(f"Connect from node {i} to node {i+1}.")
            #print(f"Kant fra node {node_nr} til node {node_nr+1} med vekt {vekt}")
            print(f"Vekt mellom node {node_nr} og {node_nr+1}: {vekt}")
            grafen.add_edge(node_nr, node_nr+1, vekt)
            grafen.add_edge(node_nr+1, node_nr, vekt)

    print()
    print("***********LAGER ALLE VERTIKALE KANTENE*****************")
    ### for loop som lager alle VERTIKALE kantene
    q = -1
    for i in range(0, height-1):
        print()
        for j in range(0, width):
            q += 1
            #print("*", end=" ")
            #print(f"({i},{j})", end=" ")
            hoydeforskjell = abs(A[i+1][j]-A[i][j])
            vekt = 1 + hoydeforskjell
            #print(i, end=" ")
            #print(f"Connect from node {i} to node {i+1}.")
            #print(f"Kant fra node {node_nr} til node {node_nr+1} med vekt {vekt}")
            print(f"Vekt mellom node {q} og {q+width}: {vekt}")
            grafen.add_edge(q, q+width, vekt)
            grafen.add_edge(q+width, q, vekt)

    return grafen, startnode, sluttnode

#def bygg_demograf():
def dijkstra(graf, startnode, sluttnode):
    nodekoe = Prioritetsko()                # Theta(1)
    graf.fjern_kostnader()                  # Theta(V)
    graf.set_kostnad(startnode, 0)          # Theta(1)
    nodekoe.add(startnode, 0)               # Theta(1)
    while len(nodekoe) > 0:                 # Kjører O(V) ganger
        nv_node = nodekoe.remove()          # O(log(V)) med binærhaug, O(V) med array-basert
        if nv_node == sluttnode:            # O(1)
            return
        naboer = graf.get_naboer(nv_node)   # Totalt O(E)
        for nabo in naboer:                 # Totalt O(E)
            kostnad_til_nabo = graf.get_kostnad(nv_node) + graf.get_vekt(nv_node, nabo)     # Theta(1)
            if graf.get_kostnad(nabo) is None:
                graf.set_kostnad(nabo, kostnad_til_nabo)
                graf.set_forrige_node(nabo, nv_node)
                nodekoe.add(nabo, kostnad_til_nabo)                 # O(log(V)) med binærhaug, O(1) array-basert
            elif graf.get_kostnad(nabo) > kostnad_til_nabo:
                graf.set_kostnad(nabo, kostnad_til_nabo)
                graf.set_forrige_node(nabo, nv_node)
                nodekoe.senk_prioritet(nabo, kostnad_til_nabo)      # O(log(V)) med binærhaug, O(1) array-basert


def skriv_korteste_vei(grafen, startnode):
    nv_node = startnode
    while nv_node is not None:
        print(f"Node: {grafen.get_nodedata(nv_node)}")
        nv_node = grafen.get_forrige_node(nv_node)

if __name__ == "__main__":
    #values_from_file = open_file()
    #for value in values_from_file:
    #    if type(value) == int:
    #        print(value)
    #    else:
    #        for x in value:
    #         for y in x:
    #             print(y, end=" ")
    #         print()
    #grafen = bygg_demograf()
    grafen, e, h = open_file()
    print(e)
    print(h)
    print("**********HER ER TESTEN***********")
    #print(grafen.get_nodedata(0))
    #print(grafen.get_nodedata(10))
    #print(grafen.get_nodedata(11))
    #print(grafen.get_nodedata(12))
    #print(grafen.get_nodedata(13))
    #print(grafen.get_vekt(0, 1))
    #print(grafen.get_vekt(77, 78))
    #print(grafen.get_vekt(77, 89))
    #print(grafen.get_vekt(90, 78))
    dijkstra(grafen, e, h)
    print(f"Korteste vei fra Camp til Mosefejll: {grafen.get_kostnad(h)}")
    skriv_korteste_vei(grafen, h)
    for row in range(5):
        for col in range(3):
            print("#",end=" ")
        print()
