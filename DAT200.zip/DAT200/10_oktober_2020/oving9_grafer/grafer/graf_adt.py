class GrafADT:
    # Returnerer en referanse
    def add_node(self, dataobjekt):
        pass

    # Returnerer ingenting
    def add_edge(self, fra_node, til_node, vekt):
        pass

    def get_nodedata(self, node_referanse):
        pass

    def get_vekt(self, fra_node, til_node):
        pass

    def set_kostnad(self, node_referanse, kostnad):
        pass

    def get_kostnad(self, node_referanse):
        pass

    def fjern_kostnader(self):
        pass

    # Antall noder i grafen
    def get_antall_noder(self):
        pass

