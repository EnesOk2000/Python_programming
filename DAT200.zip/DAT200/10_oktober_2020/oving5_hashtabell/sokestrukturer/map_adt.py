class Map:
    # Setter inn en oppgitt nøkkel med oppgitt verdi, overskriver gammel verdi
    # hvis nøkkelen allerede ligger der
    def put(self, nokkel, verdi):
        pass

    def __setitem__(self, key, value):
        self.put(key, value)

    # Henter ut verdien for oppgitt nøkkel
    def get(self, nokkel):
        pass

    def __getitem__(self, key):
        return self.get(key)

    # Fjerner en nøkkel fra map-et. Fjerner også verdien.
    def delete(self, nokkel):
        pass

    # Finnes nøkkelen i samlingen?
    def cotains(self, nokkel):
        pass

    def __contains__(self, nokkel):
        return self.cotains(nokkel)

    # Iterator: Trenger en iterator som returnerer nøkler slik at man kan bruke
    # en for-loop til å gå gjennom alle nøklene i samlingen.


# Map som holdes sortert på nøkkel
class SortedMap (Map):
    # Hent første nøkkel som er større enn oppgitt nøkkel hvis det fins en slik
    def next(self, nokkel):
        pass

    # Hent ut første nøkkel som er mindre
    def previous(self, nokkel):
        pass

    # Hent ut den laveste nøkkelen
    def first(self):
        pass

    # Hent ut den høyeste nøkkelen
    def last(self):
        pass

    # Hent ut alle nøkler mellom to oppgitte nøkler
    def between(self, forste, siste):
        pass

    # Finn det k-ende elementet, Selection problemet
    def finn_k_ende(self, k):
        pass
