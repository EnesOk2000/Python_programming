class Mengde:
    # Legger til en nøkkel hvis den ikke allerede er der
    def add(self, nokkel):
        pass

    # Sletter en nøkkel
    def delete(self, nokkel):
        pass

    # Henter ut nøkkelen
    def get(self, nokkel):
        pass

    # Inneholder mengden nøkkelen?
    def contains(self, nokkel):
        pass

    # Iterator

    # Returnerer en ny mengde som inneholder både elementene i denne mengden og elementene
    # i den oppgitte mengden.
    def union(self, mengde):
        pass

    # Returnerer en ny mengde som inneholder elementene som er med i både self og
    # den oppgitte mengden
    def intersection(self, mengde):
        pass

    # Returnerer en ny mengde som inneholder elementene som er med i self men ikke
    # i den oppgitte mengden
    def difference(self, mengde):
        pass

    # Delmengde: Returnerer True hvis denne mengden inneholder alle elementene i den oppgitte
    # mengden, False ellers
    def subset(self, mengde):
        pass


# Mengde som holdes sortert på nøkkel
class SortertMengde (Mengde):
    # Hent første nøkkel som er større enn oppgitt nøkkel hvis det fins en slik
    def next(self, nokkel):
        pass

    # Hent ut første nøkkel som er mindre
    def previous(self, nokkel):
        pass

    # Hent ut den laveste nøkkelen
    def first(self):
        pass

    # Hent ut den høyeste nøkkelen
    def last(self):
        pass

    # Hent ut alle nøkler mellom to oppgitte nøkler
    def between(self, forste, siste):
        pass

    # Finn det k-ende elementet, Selection problemet
    def finn_k_ende(self, k):
        pass
