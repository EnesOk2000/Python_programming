import numpy as np
import student as std


class HashMap:
    # Konstruktør: Theta(n)
    def __init__(self, startkapasitet=7):
        self.array = np.zeros(startkapasitet, dtype=object)
        self.antall_elementer = 0

    # Kjøretid Theta(n)
    def rehash(self):
        ny_array = np.zeros(len(self.array)*2, dtype=object)
        for element in self:
            self.put(element, self[element], ny_array)
        self.array = ny_array

    # Kjøretid Theta(1)
    def finn_hashverdi(self, nokkel, array=None):
        if array is None:
            array = self.array
        hashverdi = hash(nokkel)
        if hashverdi < 0:
            hashverdi = -hashverdi
        hashverdi = hashverdi % len(array)
        return hashverdi

    # Finner første ledige plass for å sette inn oppgitt nøkkel
    #
    # Kjøretid O(antall forsøk den må gjøre). Dette er O(1) best case, O(n) worst case.
    # Average case kan holdes på O(1) ved å ikke la hashtabellen bli for full.
    def finn_ledig_plass(self, nokkel, array=None):
        if array is None:
            array = self.array
        hashverdi = self.finn_hashverdi(nokkel, array)
        while array[hashverdi] != 0 and array[hashverdi][0] != nokkel \
                and array[hashverdi][0] is not None:
            hashverdi += 1
            hashverdi = hashverdi % len(array)
        return hashverdi

    # Prøver å finne nøkkelen. Returnerer enten indeksen til nøkkelen eller indeksen
    # til første celle som inne inneholder noe. De ulike operasjonene som bruker
    # denne har ulik håndtering av at den ikke finner det.
    #
    # Kjøretid O(antall forsøk til den finner nøkkelen eller en tom plass). Kjøretid
    # i O-notasjon som for finn_ledig_plass, men returnerer tidligere hvis den finner
    # det den leiter etter.
    def finn_nokkel(self, nokkel):
        hashverdi = self.finn_hashverdi(nokkel)
        while self.array[hashverdi] != 0 and (self.array[hashverdi][0] != nokkel \
                or self.array[hashverdi][0] is None):
            hashverdi += 1
            hashverdi = hashverdi % len(self.array)
        return hashverdi

    # Setter inn en oppgitt nøkkel med oppgitt verdi, overskriver gammel verdi
    # hvis nøkkelen allerede ligger der
    #
    # Kjøretid Theta(1) uten prøving
    # Med prøving, kjøretid O(antall forsøk)
    def put(self, nokkel, verdi, array=None):
        ok_antall_elementer = False
        if array is None:
            array = self.array
            ok_antall_elementer = True
        if ((self.antall_elementer + 1)/len(array) > 0.6):
            self.rehash()
        liste_element = (nokkel, verdi)
        hashverdi = self.finn_ledig_plass(nokkel, array)
        if array[hashverdi] == 0:
            array[hashverdi] = liste_element
            if ok_antall_elementer:
                self.antall_elementer += 1
        elif array[hashverdi][0] == nokkel:
            array[hashverdi] = liste_element
        elif array[hashverdi][0] is None:
            array[hashverdi] = liste_element
            if ok_antall_elementer:
                self.antall_elementer += 1

    def __setitem__(self, key, value):
        self.put(key, value)

    # Henter ut verdien for oppgitt nøkkel
    #
    # Kjøretid Theta(1)
    # Med prøving, kjøretid O(antall forsøk)
    def get(self, nokkel):
        hashverdi = self.finn_nokkel(nokkel)
        if self.array[hashverdi] == 0:
            raise KeyError(f"Finner ikke nøkkelen {nokkel}")
        return self.array[hashverdi][1]

    def __getitem__(self, key):
        return self.get(key)

    # Fjerner en nøkkel fra map-et. Fjerner også verdien.
    #
    # Kjøretid Theta(1)
    # Med prøving, kjøretid O(antall forsøk)
    def delete(self, nokkel):
        hashverdi = self.finn_nokkel(nokkel)
        if self.array[hashverdi] != 0 and self.array[hashverdi][0] == nokkel:
            self.array[hashverdi] = (None, None)
            self.antall_elementer -= 1

    # Finnes nøkkelen i samlingen?
    #
    # Kjøretid Theta(1)
    # Med prøving, kjøretid O(antall forsøk)
    def contains(self, nokkel):
        hashverdi = self.finn_nokkel(nokkel)
        if self.array[hashverdi] == 0:
            return False
        return True

    def __contains__(self, nokkel):
        return self.contains(nokkel)

    # Kjøretid Theta(1)
    def __len__(self):
        return self.antall_elementer

    def __iter__(self):
        return HashMapIterator(self)

    def skriv_hashmap(self):
        for index, element in enumerate(self.array):
            if element == 0:
                print(f"{index}: {element}")
            elif element[0] is None:
                print(f"{index}: ({element[0]}, {element[1]})")
            else:
                print(f"{index}: ({element[0]}, {element[1]}) hashverdi {self.finn_hashverdi(element[0])}")

    # Iterator: Trenger en iterator som returnerer nøkler slik at man kan bruke
    # en for-loop til å gå gjennom alle nøklene i samlingen.
    #
    # Kjøretid hele iterasjonen: Theta(lengden til den indre arrayen i hashtabellen)
class HashMapIterator:
    def __init__(self, hashmapet):
        self.hashmapet = hashmapet
        self.index = 0

    def __next__(self):
        while self.index < len(self.hashmapet.array) and (self.hashmapet.array[self.index] == 0\
                or self.hashmapet.array[self.index][0] is None):
            self.index += 1
        if self.index >= len(self.hashmapet.array):
            raise StopIteration
        nokkel = self.hashmapet.array[self.index][0]
        self.index += 1
        return nokkel

    def __iter__(self):
        return self


if __name__ == "__main__":
    #studentliste = std.lag_student_liste()
    #nokkelliste = [100, 77, 37, 18, 35]
    #map = HashMap()
    #for student in nokkelliste:
    #    map.put(student, student)
    #    map.skriv_hashmap()
    #    print()

    fil = "ordfil_for_anagrammer.txt"
    #fil = input("Skriv inn navnet på filen :")
    with open(fil, "r") as filen:
        d = dict()
        for line in filen:
            line = line.strip("\n")
            line = line.strip(" ")
            words = line.split(" ")
            for word in words:
                rep=''.join(sorted(word))
                d[word]=rep

    i=0
    for x, y in d.items():
        #print(x, y)
        for x2, y2 in d.items():
            i+=1
            if i == 1:
                continue
            i=0
            if y == y2:
                print(x, "and", x2, "are anagrams!")

    #map.skriv_hashmap()

    #for key in list(d.keys()):
    #    print(str(key), "=", str(d[key]))

    #for nokkel in map:
    #    print(f"{nokkel}: {map[nokkel]}")
    #print()
    #map.skriv_hashmap()
    #print()
    #map.delete("Bø")
    #map.skriv_hashmap()
    #print()
    #for nokkel in map:
    #    print(f"{nokkel}: {map[nokkel]}")
    #print()
    #print(map.get("Vik"))
    #print(map.get("Nilsen"))
