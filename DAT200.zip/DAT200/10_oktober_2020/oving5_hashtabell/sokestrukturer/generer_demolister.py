import random


def lag_tilfeldig_liste(lengde, rekkevidde = 1000):
    liste = []
    for i in range(lengde):
        liste.append(random.randint(0,rekkevidde))
    return liste


if __name__ == "__main__":
    liste = lag_tilfeldig_liste(4, 100)
    for element in liste:
        print(f"elemenet: {element} hash: {element%7}")
