import tkinter

FARGER = ["red", "green", "blue", "orange", "gray"]


# Plotter for de studentene som ikke får til å installere matplotlib. Denne vil være forståelig
# når dere er ferdige med dette faget, den bruker bare konsepter som er pensum i DAT110.
class Plotter:
    def __init__(self):
        self.main_window = tkinter.Tk()
        self.tegnevindu = tkinter.Canvas(self.main_window, width=1000, height=600)
        self.tegnevindu.pack(side='left')
        self.max_x = 1000
        self.max_y = 1000
        self.min_x = 0
        self.min_y = 0
        self.grafer = []
        self.drawing_width = 1000
        self.drawing_height = 600
        self.etiketter = None

    # Beregner x-koordinatet i canvas objektet fra x-koordinatet i grafen
    def __beregn_x(self, x):
        return 50 + (self.drawing_width-100)*((x-self.min_x)/(self.max_x-self.min_x))

    # Beregner y-koordinatet i canvas objektet fra y-koordinatet i grafen
    def __beregn_y(self, y):
        return self.drawing_height - 50 - (self.drawing_height-100)*((y-self.min_y)/(self.max_y-self.min_y))

    # Sender inn en graf til plotting. Merk at denne ikke selv plotter, bare registrerer listene
    # og finner ut om maks og min verdier for koordinataksene må endres
    def plot(self, x_koordinater, y_koordinater):
        max_x = x_koordinater[0]
        max_y = y_koordinater[0]
        min_x = x_koordinater[0]
        min_y = y_koordinater[0]
        for x in x_koordinater:
            if x > max_x:
                max_x = x
            if x < min_x:
                min_x = x
        for y in y_koordinater:
            if y > max_y:
                max_y = y
            if y < min_y:
                min_y = y
        if len(self.grafer) == 0:
            self.max_x = max_x
            self.max_y = max_y
            self.min_x = min_x
            self.min_y = min_y
        else:
            if max_x > self.max_x:
                self.max_x = max_x
            if max_y > self.max_y:
                self.max_y = max_y
            if min_x < self.min_x:
                self.min_x = min_x
            if min_y < self.min_y:
                self.min_y = min_y
        self.grafer.append(x_koordinater)
        self.grafer.append(y_koordinater)

    # Tegner opp grafene. Kalles fra show() og skal ikke kalles direkte av brukere.
    def __tegn_grafer(self):
        teller = 0
        while teller < len(self.grafer):
            x_koordinater = self.grafer[teller]
            y_koordinater = self.grafer[teller+1]
            if teller//2 < len(FARGER):
                farge = FARGER[teller//2]
            else:
                farge = "black"
            teller += 2
            forrige_x = self.__beregn_x(x_koordinater[0])
            forrige_y = self.__beregn_y(y_koordinater[0])
            self.tegnevindu.create_oval(forrige_x - 2, forrige_y - 2, forrige_x + 2, forrige_y + 2, fill=farge)
            for i in range(len(x_koordinater)):
                nv_x = self.__beregn_x(x_koordinater[i])
                nv_y = self.__beregn_y(y_koordinater[i])
                self.tegnevindu.create_oval(nv_x - 2, nv_y - 2, nv_x + 2, nv_y + 2, fill=farge)
                self.tegnevindu.create_line(forrige_x, forrige_y, nv_x, nv_y, fill=farge)
                forrige_x = nv_x
                forrige_y = nv_y

    # Tegner opp koordinataksene. Kalles fra skow() og skal ikke kalles direkte av brukere.
    def __tegn_akser(self):
        min_x = self.__beregn_x(self.min_x)
        min_y = self.__beregn_y(self.min_y)
        maks_x = self.__beregn_x(self.max_x)
        maks_y = self.__beregn_y(self.max_y)
        origo_x = self.__beregn_x(0.0)
        origo_y = self.__beregn_y(0.0)
        self.tegnevindu.create_line(min_x, origo_y, maks_x, origo_y)
        self.tegnevindu.create_line(origo_x, min_y, origo_x, maks_y)
        self.tegnevindu.create_text(maks_x, origo_y + 20, text=str(round(self.max_x)))
        self.tegnevindu.create_text(origo_x - 20, maks_y, text=str(round(self.max_y)))
        self.tegnevindu.create_text(min_x + 10, origo_y + 20, text=str(round(self.min_x)))
        self.tegnevindu.create_text(origo_x - 20, min_y, text=str(round(self.min_y)))

    # Setter akse-etikettene
    def legend(self, legend):
        self.etiketter = legend

    # Tegner akse-etikettene. Kalles fra show() og skal ikke kalles direkte av brukere.
    def __tegn_legend(self):
        if self.etiketter is not None:
            start_y = self.__beregn_y(self.max_y)
            start_x = self.__beregn_x(0.0) + 10
            slutt_y = start_y + len(self.etiketter)*20 + 10
            slutt_x = start_x + 200
            self.tegnevindu.create_rectangle(start_x, start_y, slutt_x, slutt_y)
            for teller, etikett in enumerate(self.etiketter):
                if teller < len(FARGER):
                    farge = FARGER[teller]
                else:
                    farge = "black"
                self.tegnevindu.create_line(start_x + 10, start_y + teller*20 + 12, start_x + 40, start_y + teller*20 + 12, fill=farge)
                self.tegnevindu.create_text(start_x + 50, start_y + teller*20 + 5, text=etikett, anchor=tkinter.NW)

    # Viser fram grafene. Kall til denne "stopper" resten av programmet og bør være det siste du gjør i programmet.
    # Hvorfor kommer jeg tilbake til i temaet "grafiske brukergrensesnitt"
    def show(self):
        self.__tegn_akser()
        self.__tegn_grafer()
        self.__tegn_legend()
        tkinter.mainloop()
