from plotter import Plotter
import math


# Funksjon som lager ei liste med tall med et flyttall som steglengde. range() funksjon for flyttall.
def lag_talliste(min, max, steg=1.0):
    liste = []
    tall = min
    if steg > 0.0:
        while tall < max:
            liste.append(tall)
            tall += steg
    elif steg < 0.0:
        while tall > max:
            liste.append(tall)
            tall += steg
    else:
        raise ValueError("Steglengde kan ikke være 0!")
    return liste


x_koordinater = range(10)
y_koordinater = [x**2 for x in x_koordinater]       # Hvert element i y_koordinater er tilsvarende element i
                                                    # x_koordinater opphøyd i andre, list comprehension
y_2 = [x*5 for x in x_koordinater]                  # Hvert element i y_2 er tilsvarende element i x_koordinater
                                                    # ganget med 5, list comprehension
x_3 = lag_talliste(-5, 10, 0.2)
y_3 = [math.sin(x)*30 for x in x_3]                 # Hvert element i y_3 er sinus av tilsvarende element i x_3

plt = Plotter()                                     # LAger plotteren (den er en klasse som man trenger et objekt av)
plt.plot(x_koordinater, y_2)                        # Sender inn en graf til plotting, samme grunnsyntaks som matplotlib
plt.plot(x_koordinater, y_koordinater)
plt.plot(x_3, y_3)
plt.legend(("x*5", "x i andre", "sinus av x"))      # Setter etikettene
plt.show()                                          # Viser grafene
