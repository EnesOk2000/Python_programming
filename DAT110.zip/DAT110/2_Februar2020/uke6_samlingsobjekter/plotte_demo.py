import matplotlib.pyplot as plt
import numpy as np

# Vanlig Python
x_koordinater = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
y_koordinater = []
for verdi in x_koordinater:
    y_koordinater.append(verdi**2)


# numpy
x_koordinater = np.array([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
y_koordinater = x_koordinater**2
y_2 = x_koordinater*5

plt.plot(x_koordinater, y_koordinater)
plt.plot(x_koordinater, y_2)
plt.show()
