import numpy as np

array = np.arange(7)        # numpy array av heltall, tallene fra og med 0, til men ikke med 7
print(array)
array2 = np.zeros(6)        # numpy array av flyttall, 6 elementer som alle er 0.0
array2[2] = 14.7
print(array2[2])
print(array2[-2])
array = array * 5           # Matematiske operasjoner på numpy arrays gjøres på alle elementene
print(array)
array3 = np.array([2, 3, 2, 3, 2, 3, 2])    # Lager en array fra ei Python liste
print(array3)
array = array * array3                      # Siden operasjonen gjøres element for element må de to array-ene være like lange
print(array)
matrise1 = np.array([[1, 2, 3], [4, 5, 6]])     # Lager en 3x2 matrise fra ei liste av lister
print(matrise1)
matrise2 = np.array([[4, 3], [5, 4], [6, 5]])   # Lager en 2x3 matrise
matrise3 = matrise1 @ matrise2                  # @ operatoren gir matrisemultiplikasjon (* operatoren gjør element-for-element multiplikasjon)
print(matrise2)
print(matrise3)
matrise4 = matrise2 @ matrise1
print(matrise4)
