from kort import Kort,Kortstokk

class Spiller:
    def __init__(self, navn, kort):
        self.navn = navn
        self.kort = kort

    def __str__(self):
        return f"Spiller {self.navn} har kortene {self.kort}"

class Kortspill:
    def __init__(self):
        self.kortstokk = Kortstokk()
        self.kortstokk.lag_standard_kort()
        self.kortstokk.stokk()
        self.spillere = []
        self.bunke = []
        self.tur = 1

    def lag_spillere(self):
        antall_spillere = int(input("Hvor mange spillere skal det være?"))
        for i in range(1,antall_spillere):
            navn = input(f"Navnet til spiller {i}: ")
            haand=[]
            for j in range(4):
                kortet = self.kortstokk.trekk()
                haand.append(kortet)
            spilleren = Spiller(navn, haand)
            self.spillere.append(spilleren)

    def skriv_ut_spillere(self):
        print("Spillere: ")
        for spiller in self.spillere:
            print(spiller)

    def startbunke(self):
        kortet = self.kortstokk.trekk()
        self.bunke.append(kortet)
        print("Øverste kort i bunken er "+str(self.bunke[-1]))
        return self.bunke[-1]

    def turrotasjon(self):
        if self.antall_spillere == self.tur:
            self.tur=1
        else:
            self.tur+=1

    def vinner(self):
        vinner = ""
        for spiller in self.spillere:
            if self.kort == []:
                vinner = spiller
                break
        return vinner

    def spilltur(self):
        mulig=[]
        for el_haand in self.kort:
            if self.bunke[-1] == el_haand:
                    print(str(el_haand) + "er i din hånd og i bunken")
                    mulig.append(el_haand)
                    lov=1
            elif el_haand=="Spar 8":
                    lov=1
            else:
                    lov=0
        if lov==0:
            kortet = self.kortstokk.trekk()
            self.haand.append(kortet)
        elif lov==1:
            put=self.kort
            self.bunke.append(put)
            print(mulig)
    def tom_kortstokk(self):
        fjern=self.bunke[0:-2]
        self.kortstokk.append(fjern)
        self.kortstokk.stokk()

    def spill_spillet(self):
        self.startbunke()
        self.skriv_ut_spillere()
        vinner = self.vinner()
        while vinner=="":
            self.spilltur()
            self.turrotasjon()
        print(f"Og vinneren er: {vinner}")

if __name__ == "__main__":
    spillet = Kortspill()
    spillet.lag_spillere()
    spillet.spill_spillet()
