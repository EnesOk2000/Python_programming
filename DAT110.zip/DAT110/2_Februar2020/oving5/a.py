class question:
    def __init__(self,Q,alt,A):
        self.Q=Q
        self.alt=alt
        self.A=A
    def riktig(self,tall):
        tall=input("Velg riktig svaralternativ: ")
        if str(tall) == str(self.A):
            return True
        elif str(tall) != str(self.A):
            return False
    def __str__(self):
        string=self.Q+"\n"
        for i in range(4):
            string+=str(i)+": "+self.alt[i]+"\n"
        return string
def lagQ():
    liste1=["Oslo","Helsinki","København","Stockholm"]
    sporsmal1 = question("Hva er hovedstaden i Norge?",liste1,liste1[0])
    sporsmal2 = question("Hva er hovedstaden i Finland?",liste1,liste1[1])
    sporsmal3 = question("Hva er hovedstaden i Danmark?",liste1,liste1[2])
    sporsmal4 = question("Hva er hovedstaden i Sverige?",liste1,liste1[3])
    return [sporsmal1,sporsmal2,sporsmal3,sporsmal4]

qiste = lagQ()
antRiktig=0
for k in range(4):
    p=qiste[k]
    print(p)
    Bsvar=str(input("Skriv et tall mellom 0 og 3: "))
    p.riktig()
print("Totalt antall riktig: "+antRiktig)
