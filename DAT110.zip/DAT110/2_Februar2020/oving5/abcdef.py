class Sporsmaal:
    def __init__(self,sporre,alternativ,svar):
        self.sporre=sporre
        self.alternativ=alternativ
        self.svar=svar
    def riktig(self,tall=0):
        tall=input("Velg riktig svaralternativ: ")
        if str(tall) == str(self.svar):
            return True
        elif str(tall) != str(self.svar):
            return False
    def __str__(self):
        string=self.sporre+"\n"
        for i in range(4):
            string+=str(i)+": "+self.alternativ[i]+"\n"
        return string
def lagSporsmaal():
    svaralternativ1=["For","While","If","Try"]
    sporsmal1=Sporsmaal("Hvilken løkkestruktur bruker man for å kjøre en blokk et oppgitt antall ganger?",svaralternativ1,svaralternativ1.index("For"))
    sporsmal2=Sporsmaal("Hvilken løkkestruktur bruker man for å kjøre en blokk så lenge en gitt påstand er sant?",svaralternativ1,svaralternativ1.index("While"))
    sporsmal3=Sporsmaal("Hvilket kodeord bruker man ofte for å sjekke om noe er riktig eller ikke?",svaralternativ1,svaralternativ1.index("If"))
    sporsmal4=Sporsmaal("Hvilket kodeord brukes når man vil kjøre en blokk inntil det kommer en linje i blokken som ikke kan kjøres?",svaralternativ1,svaralternativ1.index("Try"))
    svaralternativ2=["or","not","and","xor"]
    sporsmal5=Sporsmaal("Hvilken logisk operator gir bare sann hvis begge argumentene er sanne?",svaralternativ2,svaralternativ2.index("and"))
    return [sporsmal1,sporsmal2,sporsmal3,sporsmal4,sporsmal5]

sporsmaal_liste=lagSporsmaal()
antRiktig=0
for k in range(5):
    sp=sporsmaal_liste[k]
    print("Spørsmål:\n"+str(sp))
    sjekk=sp.riktig()
    if sjekk == True:
        antRiktig+=1
        print("Korrekt!"+"\n")
    elif sjekk == False:
        print("Feil svar!"+"\n")
print("Totalt antall riktig: "+str(antRiktig))
