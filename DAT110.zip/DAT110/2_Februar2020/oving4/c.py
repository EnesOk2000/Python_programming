with open("oving3.txt", "r") as fil:
    a = set()
    for line in fil:
        words = line.split(" ")
        line = line.lower()
        for word1 in words:
            word1 = word1.strip(".,:;)«\n")
            a.add(word1)

with open("oving4.txt", "r") as fil2:
    b = set()
    for line in fil2:
        words = line.split(" ")
        line = line.lower()
        for word in words:
            word = word.strip(".,:;)«\n")
            b.add(word)

duplicates = a.intersection(b)
print(duplicates)
