def laan(startverdi=0,renteprosent=0,antAar=0):
    if startverdi==0:
        startverdi=float(input("Skriv inn startverdi på lånet: "))
        renteprosent=float(input("Skriv inn renten i antall prosent: "))
        antAar=float(input("Skriv inn antall år: "))
    okningstall=1+renteprosent/100
    sluttverdi=startverdi*okningstall**antAar
    #print(sluttverdi)
    return sluttverdi
#laan()
liste=list(range(1,21))
nyliste=list()
for i in range(20):
    antAar=liste[i]
    verdi=laan(100000,2.89,antAar)
    nyliste.append(verdi)
print(nyliste)

from plotter import Plotter
import math

# Funksjon som lager ei liste med tall med et flyttall som steglengde. range() funksjon for flyttall.
def lag_talliste(min, max, steg=1.0):
    liste = []
    tall = min
    if steg > 0.0:
        while tall < max:
            liste.append(tall)
            tall += steg
    elif steg < 0.0:
        while tall > max:
            liste.append(tall)
            tall += steg
    else:
        raise ValueError("Steglengde kan ikke være 0!")
    return liste

x=liste
y=nyliste
plt = Plotter()                                     # LAger plotteren (den er en klasse som man trenger et objekt av)
plt.plot(x,y)
plt.show()
