import unittest
# Denne funksjonen skal finne ut om det er fem av samme tall på rad i en
# todimensjonal matrise representert som en Python liste av lister. Hvis det er
# fem på rad, skal funksjonen returnere tallet. Hvis det ikke er fem på rad,
# skal funksjonen returnere None. Funksjonen skal returnere første gang den
# ser 5 på rad, og trenger ikke egen håndtering av om det er flere tilfeller
# av 5 på rad.
def fem_paa_rad(matrise):
    fem_paa_rad_funnet = False # lager et flagg for å signalisere denne tilstanden

    for rad_liste in matrise: # går gjennom hver rad i matrisen. variabel lik liste for hver rad.
        for element in rad_liste: # går gjennom hvert element i hver rad. variabel lik hvert element i radlisten
            telling = 0 # initialiserer tellingen for hvert element
            for rad_nr in range(len(matrise)): # går gjennom hver rad og varabel er indeksen på raden
                for kolonne_nr in range(len(rad_liste)): # går gjennom hver kolonne og varabel er indeksen på kolonne
                    #print(kolonne)
                    if telling == 5: # hvis 5 av samme tall er funnet settes flagget lik sant fordi vi fant det vi lette etter
                        fem_paa_rad_funnet = True
                        fem_paa_rad_funnet_tall = element # tar med oss hvilket element det er 5 av.
                        break # trenger ikke å finne eller teste noe mer nå
                    elif element == matrise[rad_nr][kolonne_nr]:
                        telling += 1
                    else:
                        telling = 0

    if fem_paa_rad_funnet:
        return fem_paa_rad_funnet_tall
    else:
        return None
# Dette er måten jeg valget å løse oppgaven på. Det ble mye nøstete løkker, men dette var en logisk og forståelig
# løsning for meg, og jeg fant det hensiktsmessig å bruke så mange løkker. Det finnes nok kortere måter å løse denne på,
# men etter min mening var dette en ryddig og god nok løsning.

# Eksempel på en unit-test av metoden. Denne viser hvordan metoden skal
# brukes, men viser langt fra alle tilfellene. Den viser korrekte returverdier
# for tre eksempel-matriser.
class TestFemPaaRad(unittest.TestCase):
    def test_fem_paa_rad(self):
        # Matrise som ikke har fem på rad, hvor funksjonen skal returnere None
        matrise = [[1, 2, 3, 4, 5, 6], [1, 2, 2, 3, 3, 2], [5, 3, 3, 3, 9, 7]]
        self.assertIsNone(fem_paa_rad(matrise))

        # Matrise som har fem firere på rad i andre rad, og hvor funksjonen skal returnere 4.
        matrise = [[1, 2, 4, 4, 2, 2], [3, 4, 4, 4, 4, 4], [5, 5, 5, 2, 2, 2]]
        self.assertEqual(fem_paa_rad(matrise), 4)

        # Matrise som har fem toere på rad i tredje rad, og hvor funksjonen skal returnere 2.
        matrise = [[1, 2, 4, 4, 2, 2, 2], [3, 4, 4, 9, 4, 4, 5], [2, 2, 2, 2, 2, 3, 5], [6, 6, 4, 6, 6, 3, 2]]
        self.assertEqual(fem_paa_rad(matrise), 2)

if __name__ == "__main__":
    unittest.main()
