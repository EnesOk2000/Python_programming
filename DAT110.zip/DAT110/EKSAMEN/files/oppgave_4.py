antall_tider = 0
total_varighet = 0
min=600
max=0
nettleser_liste = []
nettleser_liste_brukerantall = []
with open("oppgave_4.txt", "r") as filen: # with sørger for at filen lukkes når vi er ferdig å behandle filen
    for linje in filen:
        try:
            deler = linje.split("\t")
            antall_tider += 1
            if len(deler) < 4:
                continue
            tid_deler = deler[0].split(":")
            if len(tid_deler) < 3:
                continue
            if len(tid_deler[0]) != 1 and len(tid_deler[0]) != 2:
                continue
            if len(tid_deler[1]) != 2:
                continue
            if len(tid_deler[2]) != 2:
                continue

            timer = int(tid_deler[0])
            miuntter = int(tid_deler[1])
            sekunder = int(tid_deler[2])

            varighet = timer * 60 * 60 + miuntter * 60 + sekunder
            total_varighet += varighet

            if int(varighet)<int(min):
                min=varighet
            if int(varighet)>int(max):
                max=varighet

            if deler[2] not in nettleser_liste:
                nettleser_liste.append(deler[2])
                nettleser_liste_brukerantall.append(1)
            else:
                nettleser_index = nettleser_liste.index(deler[2])
                nettleser_liste_brukerantall[nettleser_index] += 1
        except:
            continue

    print(f"Maksimal varighet i sek av alle tidenes varighet ble: {max}")
    print(f"Minimal varighet i sek av alle tidenes varighet ble: {min}")
    gjennomsnitt = total_varighet / antall_tider
    print("Gjennomsnittet av alle tidenes varighet ble:", format(gjennomsnitt,'.2f'))
    print("Alle nettlesere som er brukt og antall ganger de ble brukt:")
    for nr in range(len(nettleser_liste)):
        print("Nettleser:", nettleser_liste[nr],"\t\tAntall ganger nettleser er brukt", nettleser_liste_brukerantall[nr])
