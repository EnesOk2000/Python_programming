def skriv_sum(liste_av_tall):
    sum = 0.0
    # Oppgave d) Gå gjennom lista "liste_av_tall", og legg sammen tallene i
    # variabelen "sum". Du kan anta at dette er en standard Python liste.
    for verdi in liste_av_tall:
        sum += verdi
    print(f"Summen av tallene er: {sum}")
print("Skriv inn tall for summering.")
print("Avslutt med a")
print("Neste kunde n")
print("Angre siste inntasting med k")
fortsetter = True
tall_liste = []
while fortsetter:
    innverdi = input("Skriv inn neste tall: ")
    #Oppgave a): Sjekk om innverdien er en a. Hvis den er en a, skriv ut summen og avslutt programmet
    #            eller while-løkka
    if innverdi == "a":
        skriv_sum(tall_liste)
        break
    #Oppgave b): Sjekk om innverdien er en n. Hvis den er det, skriv ut summen,
    #            slett alle elementene i lista, og skriv ut "neste kunde"
    if innverdi == "n":
        skriv_sum(tall_liste)
        del tall_liste[:]
        print("neste kunde")
        continue
    if innverdi == "k":
        del tall_liste[-1]
        continue
    try:
        tall = float(innverdi)
        # Oppgave c): Sjekk at tall her en lovlig verdi (ikke mindre enn 0.0, ikke over 1000.0,
        # Og legg tallet inn i lista hvis det er lovlig. Skriv ut en feilmelding hvis det ikke er lovlig.
        if 0.0 <= tall and tall <= 1000.0:
            tall_liste.append(tall)
        else:
            print("Tallet er ikke lovlig!")

    except ValueError:
        print("Du må skrive inn en lovlig verdi!")
