def fakultet(heltall):
    resultat = 1
    for i in range(1,heltall+1):
        resultat *= i
    return resultat

# range funksjonen lagde i den opprinngelige koden en iterable som startet på 0 som gjør at
# resultat alltid vil returnere null.
# Dette fikses ved å angi en startverdi på 1 i range funksjonen og en sluttverdi på heltall+1.
# Da får man en iterable som f. eks. [1, 2, 3, 4, 5] hvis man oppga heltallet 5.
