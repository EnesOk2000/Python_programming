class TicTacToe:
    def __init__(self):
        self.brett = [["-", "-", "-"], ["-", "-", "-"], ["-", "-", "-"]]
        self.plasseringer = 0

    def vinner(self):
        for spiller in ("x", "o"):
            for y in range(3):
                if self.brett[0][y] == self.brett[1][y] == self.brett[2][y] == spiller:
                    return spiller
            for x in range(3):
                if self.brett[x][0] == self.brett[x][1] == self.brett[x][2] == spiller: # det var en y her ved feil
                    return spiller
            if self.brett[0][0] == self.brett[1][1] == self.brett[2][2] == spiller:
                return spiller
            if self.brett[2][0] == self.brett[1][1] == self.brett[0][2] == spiller:
                return spiller
        return None

    def skriv_brett(self):
        for y in range(3):
            for x in range(3):
                print(self.brett[x][y], end=" ")
            print() # det manglet en tabulator på denne linjen. Skal printe for hver iterasjon av y, ikke etter at begge for-loopene har iterert

    def plasser(self, spiller):
        plassert = False
        while not plassert:
            print(f"Hvor ønsker {spiller} å plassere?")
            x = int(input("x-koordinat: "))
            y = int(input("y-koordinat: "))
            if self.brett[x][y] == "-":
                self.brett[x][y] = spiller
                plassert = True
            else:
                print("Det er allerede en brikke her. Du kan ikke plassere her!")

    def spill_spillet(self):
        while not self.vinner():
            if self.plasseringer >= 9:
                print("Uavgjort!")
                return
            self.skriv_brett()
            self.plasser("x")
            if self.vinner():
                break
            if self.plasseringer >= 9:
                print("Uavgjort!")
                break # det sto "return" istedenfor "break"
            self.skriv_brett()
            self.plasser("o")
        print(f"Og vinneren er: {self.vinner()}")


if __name__ == "__main__":
    spill = TicTacToe()
    spill.spill_spillet()

