# Du skal lage et program som regner ut totalpris for en rekke varer. Brukeren
# skriver inn pris for hver vare. I tillegg til pris skal brukeren kunne skrive
# følgende kommandoer:
#  a: Skriv ut summen og avslutt
#  n: Skriv ut summen, slett tallene som er i systemet, og start på neste tallserie som skal summeres
#  k: Angre siste inntastete tall
#
# En del av koden er allerede oppgitt. Oppgavene er oppgitt som kommentarer i koden.
# Hver oppgave teller 3%


def skriv_sum(liste_av_tall):
    sum = 0.0

    # Oppgave d) Gå gjennom lista "liste_av_tall", og legg sammen tallene i
    # variabelen "sum". Du kan anta at dette er en standard Python liste.

    print(f"Summen av tallene er: {sum}")


print("Skriv inn tall for summering.")
print("Avslutt med a")
print("Neste kunde n")
print("Angre siste inntasting med k")
fortsetter = True
tall_liste = []
while fortsetter:
    innverdi = input("Skriv inn neste tall: ")

    #Oppgave a): Sjekk om innverdien er en a. Hvis den er en a, skriv ut summen og avslutt programmet
    #            eller while-løkka

    #Oppgave b): Sjekk om innverdien er en n. Hvis den er det, skriv ut summen,
    #            slett alle elementene i lista, og skriv ut "neste kunde"

    if innverdi == "k":
        del tall_liste[-1]
        continue
    try:
        tall = float(innverdi)

        # Oppgave c): Sjekk at tall her en lovlig verdi (ikke mindre enn 0.0, ikke over 1000.0,
        # Og legg tallet inn i lista hvis det er lovlig. Skriv ut en feilmelding hvis det ikke er lovlig.

    except ValueError:
        print("Du må skrive inn en lovlig verdi!")
