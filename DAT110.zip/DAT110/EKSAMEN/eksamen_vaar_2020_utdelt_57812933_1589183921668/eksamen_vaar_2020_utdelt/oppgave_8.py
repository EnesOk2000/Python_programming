import datetime

# Eksempel: En enkel "twitter-klon" hvor brukere skriver tweets, og kan lese
# Tweets fra andre brukere.

# Klassene har kommentarer av følgende format:
# Klasse: navnet på klassen
# Ansvar: Hva objektene av klassen har ansvar for av funksjonalitet
# Avhengig av: Hvilke andre klasser som denne klassen bruker, og derfor avhenger av.
#              Man bør prøve å være avhengig av så få klasser som mulig.

# Klasse: Bruker
# Ansvar: Lagre og hente data om brukere, lagre og finne hvilke tweets som
#         er skrevet av denne gruppa
# Avhengig av: Ingen
class Bruker:
    neste_id = 1            # Klasse-variabel som inneholder ID til neste bruker

    def __init__(self, brukernavn, passord):
        self.brukernavn = brukernavn            # Definerer instans-variabelen self.brukernavn
        self.passord = passord
        self.id = Bruker.neste_id
        Bruker.neste_id += 1                    # Bruker klasse-variabler med klassenavn.variabelnavn
        self.tweets = []

    def hent_tweets(self):
        return self.tweets

    def hent_fem_siste_tweets(self):            # Siden tweets settes inn når de blir skrevet, er de 5 nyeste tweet-ene sist i lista
        if len(self.tweets) <= 5:
            return self.tweets
        return self.tweets[len(self.tweets)-5:]

    def __str__(self):
        return f"{self.id}: {self.brukernavn}"

# Klasse: Tweet
# Ansvar: Lagre og hente data om en enkelt tweet. Sørge for at brukeren vet om tweets som
#         vedkommende har skrevet
# Avhengig av: Bruker
class Tweet:
    neste_id = 1            # Klasse-variabel som inneholder ID til neste tweet

    def __init__(self, tittel, tekst, dato, forfatter: Bruker):
        self.tittel = tittel
        self.tekst = tekst
        self.dato = dato
        self.forfatter = forfatter
        if self not in forfatter.tweets:            # Sørger for at tweet-en blir lagt inn i
            forfatter.tweets.append(self)           # brukeren sin liste hvis den ikke allerede er det
        self.id = Tweet.neste_id
        Tweet.neste_id += 1
        self.likes = []

    def __str__(self):
        return f"{self.id}: {self.tittel} \n{self.tekst}\n\n"


#Lager test-data for testeformål
def lag_test_data():
    brukeren = Bruker("Arne Einarsen", "dfgre24")
    brukere = {}
    brukere[brukeren.id] = brukeren
    brukeren = Bruker("Ida Hansen", "45.sdgsd")
    brukere[brukeren.id] = brukeren
    brukeren = Bruker("Nils Ås", "435dfgh!")
    brukere[brukeren.id] = brukeren
    tweets = {}
    ny_tweet = Tweet("Tittel", "Tester systemet", datetime.date(2020, 3, 20), brukere[1])
    tweets[ny_tweet.id] = ny_tweet
    ny_tweet = Tweet("System", "Systemtest", datetime.date(2020, 3, 21), brukere[1])
    tweets[ny_tweet.id] = ny_tweet
    ny_tweet = Tweet("Noe", "Noe", datetime.date(2020, 3, 22), brukere[2])
    tweets[ny_tweet.id] = ny_tweet
    return brukere, tweets


# Klasse: System
# Ansvar: Holde oversikt over brukerne og tweetene, vite hvem som er logget inn
# Avhengig av: Bruker, Tweet
class System:
    def __init__(self):
        # Brukerlista og tweet-listene er dict-er heller enn lister slik at man kan bruke
        # faste ID-er til å slå opp brukerne og tweet-ene. I ei liste så vil indeksene
        # endre seg om man sletter et element i midten av lista. Merk at det kun er
        # system-klassen som skal vite at disse er dict-er heller enn lister.
        self.brukere = {}
        self.tweets = {}
        self.innlogget_bruker = None

    def sett_inn_test_data(self):
        self.brukere, self.tweets = lag_test_data()

    # Lager en bruker og setter brukeren inn i brukerlista.
    # Innsettingen "self.brukere[brukeren.id] = brukeren" setter inn et nøkkel-verdi par i dict-et
    # Hvor nøkkel er id-en og verdi er en referanse til brukeren.
    def lag_bruker(self, brukernavn, passord):
        brukeren = Bruker(brukernavn, passord)
        self.brukere[brukeren.id] = brukeren

    def logg_inn(self, bruker_id):
        self.innlogget_bruker = self.brukere[bruker_id]

    def brukerliste(self):
        return self.brukere

    def tweets_for_bruker(self, bruker_id=None):
        if bruker_id is None:
            bruker = self.innlogget_bruker
        else:
            bruker = self.brukere[bruker_id]
        tweets = bruker.hent_tweets()
        return tweets

    def alle_tweets_med_brukerinfo(self):
        tweet_utskrift_liste = []
        for tweet_id in self.tweets:
            tweet = self.tweets[tweet_id]
            streng = f"{tweet_id}: {tweet.tittel}\n{tweet.tekst}\nSkrevet av {tweet.forfatter.brukernavn}\nLikes: {len(tweet.likes)}\n"
            tweet_utskrift_liste.append(streng)
        return tweet_utskrift_liste

    # LAger en tweet for den innloggete brukeren og setter den inn i lista. Alle nye
    # tweets får nåværende tidspunkt som tidspunkt.
    def lag_tweet(self, tittel, tekst):
        ny_tweet = Tweet(tittel, tekst, datetime.datetime.now(), self.innlogget_bruker)
        self.tweets[ny_tweet.id] = ny_tweet

    def registrer_like(self, tweet_id):
        if self.innlogget_bruker is None:
            raise ValueError("Du må være logget inn for å registrere likes!")
        tweeten = self.tweets[tweet_id]
        tweeten.likes.append(self.innlogget_bruker)

# Klasse: Grensesnitt
# Ansvar: Lage et tekstbasert menysystem og grensesnitt mot brukeren av systemet
# Avhengig av: System
class Grensesnitt:
    def __init__(self, system):
        self.system = system

    def skriv_inn_ny_bruker(self):
        print("Skriv inn ny bruker: ")
        navn = input("Skriv inn brukernavn: ")
        passord = input("Skriv inn passord")
        self.system.lag_bruker(navn, passord)

    def skriv_brukerliste(self):
        brukerliste = self.system.brukerliste()
        print("Brukere: ")
        for nokkel in brukerliste:
            print(brukerliste[nokkel])

    def logg_inn_bruker(self):
        self.skriv_brukerliste()
        bruker_id = int(input("Logg inn hvilken bruker? "))
        self.system.logg_inn(bruker_id)

    def tweets_for_innlogget_bruker(self):
        print("Tweets for innlogget bruker: ")
        tweets = self.system.tweets_for_bruker()
        for tweet in tweets:
            print(tweet)

    def skriv_alle_tweets(self):
        tweetliste = self.system.alle_tweets_med_brukerinfo()
        for linje in tweetliste:
            print(linje)

    def skriv_tweet(self):
        print(f"Skriv inn tweet for {self.system.innlogget_bruker}")
        tittel = input("Tittel")
        print("Skriv inn teksten. Avslutt med tom linje")
        linja = input("> ")
        tekst = linja + "\n"
        while linja != "":
            linja = input("> ")
            if linja == "":
                break
            tekst += linja + "\n"
        self.system.lag_tweet(tittel, tekst)

    def registrer_like(self):
        if self.system.innlogget_bruker is None:
            print("Du må være logget inn for å like en tweet!")
        else:
            self.skriv_alle_tweets()
            tweet_id = int(input("Hvilken tweet ønsker du å like? "))
            self.system.registrer_like(tweet_id)

    def meny(self):
        avslutter = False
        while not avslutter:
            print("Velg hva du vil gjøre:")
            print("1: Skriv ut brukerliste")
            print("2: Skriv inn ny bruker")
            print("3: Logg inn bruker")
            print("4: Skriv ut tweets for bruker")
            print("5: Skriv ut alle tweets")
            print("6: Skriv inn tweet for innlogget bruker")
            print("7: Registrer like")
            print("a: avslutt")
            valg = input("Velg: ")
            if valg == "1":
                self.skriv_brukerliste()
            if valg == "2":
                self.skriv_inn_ny_bruker()
            if valg == "3":
                self.logg_inn_bruker()
            if valg == "4":
                self.tweets_for_innlogget_bruker()
            if valg == "5":
                self.skriv_alle_tweets()
            if valg == "6":
                self.skriv_tweet()
            if valg == "7":
                self.registrer_like()
            if valg == "a":
                avslutter = True


# Starter opp systemet og lager den nødvendige objektene
if __name__ == "__main__":
    systemet = System()
    systemet.sett_inn_test_data()
    grensesnitt = Grensesnitt(systemet)
    grensesnitt.meny()
