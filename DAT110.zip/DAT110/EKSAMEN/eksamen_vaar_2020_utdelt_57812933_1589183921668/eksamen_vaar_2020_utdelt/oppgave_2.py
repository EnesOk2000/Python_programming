#While-løkke: Starter aldri

#While-løkke: Evig løkke

# Denne funksjonen skal returnere fakultet av et gitt tall.
# Fakultet av et tall n er 1*2*3*4*...*n. For eksempel så skal
# fakultet(5) være 1*2*3*4*% = 120. Funksjonen slik den er skrevet nå
# returnerer alltid 0, uansett hvilket tall den får inn. Fiks
# problemet slik at funksjonen returnerer korrekt tall.

# Sjekk denne. Jeg fikker ikke at den er brukt som eksempel i år, men
# jeg tror jeg har brukt den en gang.
def fakultet(heltall):
    resultat = 1
    for i in range(heltall):
        resultat *= i
    return resultat

print(fakultet(5))
