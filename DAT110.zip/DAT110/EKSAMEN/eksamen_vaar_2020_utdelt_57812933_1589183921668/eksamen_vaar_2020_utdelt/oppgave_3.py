import unittest

# Denne funksjonen skal finne ut om det er fem av samme tall på rad i en
# todimensjonal matrise representert som en Python liste av lister. Hvis det er
# fem på rad, skal funksjonen returnere tallet. Hvis det ikke er fem på rad,
# skal funksjonen returnere None. Funksjonen skal returnere første gang den
# ser 5 på rad, og trenger ikke egen håndtering av om det er flere tilfeller
# av 5 på rad.
def fem_paa_rad(matrise):
    pass


# Eksempel på en unit-test av metoden. Denne viser hvordan metoden skal
# brukes, men viser langt fra alle tilfellene. Den viser korrekte returverdier
# for tre eksempel-matriser.
class TestFemPaaRad(unittest.TestCase):
    def test_fem_paa_rad(self):
        # Matrise som ikke har fem på rad, hvor funksjonen skal returnere None
        matrise = [[1, 2, 3, 4, 5, 6], [1, 2, 2, 3, 3, 2], [5, 3, 3, 3, 9, 7]]
        self.assertIsNone(fem_paa_rad(matrise))

        # Matrise som har fem firere på rad i andre rad, og hvor funksjonen skal returnere 4.
        matrise = [[1, 2, 4, 4, 2, 2], [3, 4, 4, 4, 4, 4], [5, 5, 5, 2, 2, 2]]
        self.assertEqual(fem_paa_rad(matrise), 4)

        # Matrise som har fem toere på rad i tredje rad, og hvor funksjonen skal returnere 2.
        matrise = [[1, 2, 4, 4, 2, 2, 2], [3, 4, 4, 9, 4, 4, 5], [2, 2, 2, 2, 2, 3, 5], [6, 6, 4, 6, 6, 3, 2]]
        self.assertEqual(fem_paa_rad(matrise), 2)


if __name__ == "__main__":
    unittest.main()
