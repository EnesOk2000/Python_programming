class Pakke:
    def __init__(self, vekt, lengde, bredde, hoyde, avsenderadresse, mottakeradresse, fragil, volum):
        self.vekt = vekt
        self.lengde = lengde
        self.bredde = bredde
        self.hoyde = hoyde
        self.avsenderadresse = avsenderadresse
        self.mottakeradresse = mottakeradresse
        self.fragil = fragil
        self.__volum = volum

    def get_volum(self):
        return self.lengde*self.bredde*self.hoyde

    def get_vekt(self): # denne lagde jeg for oppgave 5.2
        return self.vekt

    @property
    def vekt(self): # denne lagde jeg for oppgave 5.3
        return self.vekt

    @vekt.setter
    def vekt(self, ny_vekt):
        MIN_VEKT = 0
        MAKS_VEKT = 35
        if self.vekt < MIN_VEKT:
            raise ValueError("Vekten kan ikke være negativ!")
        elif MAKS_VEKT < self.vekt:
            raise ValueError("Vekten kan ikke være mer enn 35kg!")
        else:
            self.vekt = ny_vekt

    def __str__(self):
        resultat = f"Pakke fra {self.avsenderadresse} til {self.mottakeradresse} med vekt {self.vekt}"
        if self.fragil:
            resultat += " FRAGIL"
        return resultat

def beregn_pris_for_sende_pakke(pakke_obj):
    pakke_vekt_nbr = pakke_obj.get_vekt()
    if 0 <= pakke_vekt_nbr < 10:
        pris=149
    elif 10 <= pakke_vekt_nbr < 25:
        pris=268
    else:
        pris=381
    return pris
