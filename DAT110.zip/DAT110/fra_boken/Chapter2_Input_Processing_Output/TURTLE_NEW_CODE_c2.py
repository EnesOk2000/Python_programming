#
# This file contains all new ****TURTLE GRAPHICS***** code in chapter 2: Input, Processing, and Output
#

import turtle as t

t.showturtle()

t.forward(n)
t.backward(n)

t.left(d) # rotate turtle_tasks_chapter4's heading direction to the left by "d" degrees.
t.right(d)

t.setheading(d) # Sets the turtle_tasks_chapter4's heading direction to a specific angle
t.heading() # returns turtle_tasks_chapter4's current heading direction

t.penup() # does not draw
t.pendown() # draws

t.circle(r) # draws a circle with "r" radius. start drawing from bottom of circle.

t.dot() # creates a dot. put a number in the dot to make it bigger

t.pensize(5) # edits pen's width. returns current pensize as integer if () is empty

t.pencolor('red') # edits pen's color to red. returns current pencolor as string if () is empty

t.bgcolor("black") # edits the BackGround color of the canvas to black. returns current BGcolor as string if () is empty

t.setup(width, height) # defines the size of the turtle_tasks_chapter4 graphics window.

t.goto(x, y)

t.pos() # returns turtle_tasks_chapter4's current x and y position
t.xcor() # returns turtle_tasks_chapter4's current x position
t.ycor() # returns turtle_tasks_chapter4's current y position

t.speed(0) # no animation, drawn instantly. returns current speed as integer if () is empty
t.speed(1) # slowest animation drawing
t.speed(10) # fastest animation drawing

t.write("I am turtle_tasks_chapter4") # writes text at the turtle_tasks_chapter4's current position
t.write("STOP", font=("Arial",120,"italics"), align='center')

t.hideturtle() # hides turtle_tasks_chapter4
t.showturtle() # shows turtle_tasks_chapter4 (again)

t.fillcolor("red") # makes fill red. returns current fillcolor as string if () is empty
t.begin_fill()
# *** Draw figure you want to fill here
t.end_fill()
#fills figure with color
