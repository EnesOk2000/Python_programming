#
# This file contains all new code in chapter 2: Input, Processing, and Output
#

print("I'm here") # prints single-quote
print('Read "Hamlet" by today') # prints double-quote
print("""I'm reading "Hamlet" tonight""") # prints both single- and double-quote
print("""One    Two
Three   Four Five
Six""") # prints mutiline strings

length = 5
print("length") # prints the string "length"
print(length) # prints 5

print("The length is:", length) # prints several items. automatically makes space between each item
print("The length is "+"long") # combines two strings and makes it into one string
print("This is a long "+
      "sentence with a lot of words, "+
      "and so many characters"
      +".") # combines four strings and makes it into one string

print( type(1) ) # prints the data type: int
print( type(1.0) ) # prints the data type: float

first_name = "Enes"
last_name = input("What is your last name? ")

int(2.6) # returns 2
float(2) # returns 2.0

print(2+1) # addition
print(2-1) # subtraction
print(3*2) # multiplication
print(5/2) # float-point division

print(-19//3) # integer division
print(17%3) # returns remainder
print(3**3) # exponent

result = 3 * 3 + \
    4 * 4           # "\" allows you to spilt a statement into two lines

print("First name:",first_name,
      "Last name:",last_name) # also allows you to spilt a statement

total = (length + length +
         length + length) # also allows you to spilt a statement

print('One', end="")
print('Two', end=" ")
print('Three', end="+++")
print('Four') # Gets everything in one line

print("One", "Two", "Three", sep="~~~") #each item gets seperated by what sep is defined as

print("One\nTwo\nThree") # makes new line
print('One\tTwo\tThree') # makes tab
print('One\'Two\'Three') # makes single-quote
print("One\"Two\"Three") # makes double-quote
print("One\\Two\\Three") # makes backslash

print( format(123.456, '.2f') ) # ".2" indicates amount of decimals and "f" indicates data type float
print( format(123.456, '.2e') )# prints it in scientific notation

print( format(123456789, ',.2f') ) # makes it easier to read big nubmers
print( format(123456789, '20,.2f') ) # makes the number appear in 20 spaces. spaces appear left of number

print( format(123456789, '20,d') ) # this is for integer. no decimal specifier

print( format(0.4818, '.1%')) # converts the number to percantage

LENGTH = 12 # named constant is not to be changed and is easier to use many places. uppercase so it is easy to read.
