total_sales = float(input("Write the total amount of sales: "))
annual_profit = 0.23
profit = total_sales * annual_profit
print(profit)
