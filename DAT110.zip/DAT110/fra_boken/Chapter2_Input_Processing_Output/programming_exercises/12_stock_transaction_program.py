# makes variables of the given values and does calculations that have to do with the buying of the stock
share_buy = 2000
price_per_share_buy = 40
stock_total_buy = share_buy *  price_per_share_buy
stockbroker_rate = 0.03
commission_buy = stockbroker_rate * stock_total_buy

# makes variables of the given values and does calculations that have to do with the selling of the stock
share_sell = 2000
price_per_share_sell = 42.75
stock_total_sell = share_sell * price_per_share_sell
commission_sell = stockbroker_rate * stock_total_sell

net_money = stock_total_sell - commission_buy - commission_sell

# display output
print('Joe paid',stock_total_buy,'dollars for the stock.')
print('Joe paid his broker', commission_buy, 'dollars when he bought the stock.')
print('Joe paid his broker', commission_sell, 'dollars when he sold the stock.')
print('The amount of money that Joe had left when he sold the stock and paid his broker twice:',net_money,'dollars')
