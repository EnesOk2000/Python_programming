number_males = int(input('Number of males in the class: '))
number_females = int(input('Number of females in the class: '))
total_students = number_males + number_females
decimal_males = number_males / total_students # alternatively: percantage_males = (number_males / total_students) * 100
decimal_females = number_females / total_students
print("Percantage of males in the class:",format(decimal_males, '.0%'))
print("Percantage of females in the class:",format(decimal_females, '.0%'))
