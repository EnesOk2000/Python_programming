mass_pound = float(input("Write the mass of the object in pounds: "))
KG_PER_POUND = 0.454
mass_kg = KG_PER_POUND * mass_pound
print(mass_kg)
