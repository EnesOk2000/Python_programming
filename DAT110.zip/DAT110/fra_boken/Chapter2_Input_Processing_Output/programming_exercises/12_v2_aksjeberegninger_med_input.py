# makes variables of the given values and does calculations that have to do with the buying of the stock
share_buy = float(input('Skriv inn andel du kjøpte: '))
price_per_share_buy = float(input('Skriv inn hvor mye hver aksje kostet ved kjøp: '))
stock_total_buy = share_buy *  price_per_share_buy
stockbroker_rate = 0.05
commission_buy = stockbroker_rate * stock_total_buy

# makes variables of the given values and does calculations that have to do with the selling of the stock
# share_sell = 2000
# somtimes you don't want to sell all of your shares to make it so that you lose less money, but you are
# still betting som money in the company in case it goes up
price_per_share_sell = float(input('Skriv inn hvor mye hver aksje kostet ved salg: '))
stock_total_sell = share_buy * price_per_share_sell
commission_sell = stockbroker_rate * stock_total_sell

net_money = stock_total_sell - stock_total_buy - commission_buy - commission_sell

# display output
print()
print(price_per_share_buy, "pris per andel ved kjøp")
print(price_per_share_sell, "pris per andel ved salg")
print(stock_total_buy, "akjsepris ved kjøp")
print(stock_total_sell, "akjsepris ved salg")
print()
print(commission_sell+commission_buy, "betalt til megler")
if net_money > 0:
    print(net_money,"i fortjeneste.")
else:
    print(net_money,"kroner i tapt")
