price_item1 = float(input("Write the price of the 1. item: "))
price_item2 = float(input("Write the price of the 2. item: "))
price_item3 = float(input("Write the price of the 3. item: "))
price_item4 = float(input("Write the price of the 4. item: "))
price_item5 = float(input("Write the price of the 5. item: "))
subtotal = price_item1 + price_item2 + price_item3 + \
           price_item4 + price_item5
SALES_TAX = 1.07
total = subtotal * SALES_TAX
print(total)
