row_length=float(input("Type in the length of the row. "))
ep_assembly=float(input("Type in the amount of space used by an end-post assembly. "))
space_btwn_vines=float(input("Type in the space between the vines. "))

nbr_vines=int((row_length-2*ep_assembly)/space_btwn_vines)
print(nbr_vines,'grapevines will fit in the row')
