food_cost = float(input("How much did the food cost? "))
tip_percentage = 0.18
sales_tax = 0.07
tip_cost = food_cost * tip_percentage
tax_cost = food_cost * sales_tax
food_total = food_cost + tip_cost + tax_cost
print("Tip cost:",tip_cost)
print("Tax cost:",tax_cost)
print("Food total cost:",food_total)
