print("Enes Ok")
print("Rosenberggata 67, Stavanger, 4007")
print("40 31 36 68")
print("Datateknologi, bachelor")
