purchase = float(input("Enter the amount of a purchase: "))
instalment = float(input("Enter the number of payment instalments: "))
total_purchase = purchase * 1.05
per_instalment = total_purchase / instalment
print("The total amout of purchase is",total_purchase,"and each instalment will cost",per_instalment)
