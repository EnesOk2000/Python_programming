original_sugar = 1.5
original_butter = 1
original_flour = 2.75
original_cookies = 48
new_cookies = int(input("How many cookies do you want to make? "))
multiplier = new_cookies / original_cookies # multiplier is a number that expresses amount of cookies wanted compared to original recipe
new_sugar = original_sugar * multiplier
new_butter = original_butter * multiplier
new_flour = original_flour * multiplier
print('Ingredients for cooking',new_cookies,'cookies:')
print(format(new_sugar,'.2f'),'cup(s) of sugar')
print(format(new_butter,'.2f'),'cup(s) of butter')
print(format(new_flour,'.2f'),'cup(s) of flour')
