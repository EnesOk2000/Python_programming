import math as m # imports the math module to use the vaule of pi

circle_radius = float(input("Write the radius of a circle: ")) # creates variable which references what the user gives as radius
circumference = 2 * m.pi * circle_radius # calculates circumference
area = m.pi * circle_radius ** 2 # calculates area
print("The circumference of a circle with radius",circle_radius,"is:",format(circumference, '.2f')) # prints circumference
print("The area of a circle with radius",circle_radius,"is:",format(area, '.2f')) # prints area

# 1: collects input         2: performs calcuations with input          3: displays results (this is the output)
