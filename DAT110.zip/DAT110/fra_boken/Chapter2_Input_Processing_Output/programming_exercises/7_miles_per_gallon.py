miles_driven = float(input("Enter number of miles driven: "))
gallons_gas = float(input("Enter gallons of gas used: "))
MPG = miles_driven / gallons_gas
print("Amount of MPG:",MPG)
