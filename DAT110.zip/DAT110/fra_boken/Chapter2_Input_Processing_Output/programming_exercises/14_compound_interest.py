money_before=float(input("Type in the amount of originally deposited into the account. "))
interest_rate=0.01*float(input("Type in the annual interest rate. Write it in percent "))
compound_per_year=float(input("Type in the number of times per year that the interest is compounded (calculated). "))
years=float(input("Type in the number of years the account will be left to earn interest. "))

print(interest_rate)
money_after=float(money_before*(1+(interest_rate/compound_per_year))**(compound_per_year*years))
increase=money_after/money_before-1
print("The money in the account has increased from",format(money_before,".2f"),"to",format(money_after,".2f"))
print("Money has increased by",format(increase, ".0%"))
