CAR_SPEED = 70
time = 6
distance = CAR_SPEED * time
print("Distance traveled after",time,"hours:",distance)
time = 10
distance = CAR_SPEED * time
print("Distance traveled after",time,"hours:",distance)
time = 15
distance = CAR_SPEED * time
print("Distance traveled after",time,"hours:",distance)
