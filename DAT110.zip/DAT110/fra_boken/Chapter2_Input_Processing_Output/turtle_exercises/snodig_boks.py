import turtle as t

t.speed(6)
LENGDE=200
STREK=LENGDE/4.5

t.dot()
t.goto(LENGDE,LENGDE)
t.dot()
t.goto(LENGDE,-LENGDE)
t.dot()
t.goto(-LENGDE,LENGDE)
t.dot()
t.goto(-LENGDE,-LENGDE)
t.dot()
t.goto(LENGDE,LENGDE)

t.backward(STREK)
t.penup()
t.backward(STREK)
t.pendown()
t.backward(STREK*2)
t.penup()
t.backward(STREK)
t.pendown()
t.backward(STREK*2)
t.penup()
t.backward(STREK)
t.pendown()
t.backward(STREK)

t.goto(-LENGDE,-LENGDE)

t.forward(STREK)
t.penup()
t.forward(STREK)
t.pendown()
t.forward(STREK*2)
t.penup()
t.forward(STREK)
t.pendown()
t.forward(STREK*2)
t.penup()
t.forward(STREK)
t.pendown()
t.forward(STREK)

t.goto(0,0)
t.done()
