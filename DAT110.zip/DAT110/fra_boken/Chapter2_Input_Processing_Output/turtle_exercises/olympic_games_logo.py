import turtle as t


r=100
t.speed(10)
t.pensize(10)
t.bgcolor('papaya whip')

t.circle(r) #1

t.penup()
t.goto(230,0)
t.pendown()

t.pencolor('red')
t.circle(r) #2

t.penup()
t.goto(-230,0)
t.pendown()

t.pencolor('blue')
t.circle(r) #3

t.penup()
t.goto(-120,-100)
t.pendown()

t.pencolor('yellow')
t.circle(r) #4

t.penup()
t.goto(120,-100)
t.pendown()

t.pencolor('green')
t.circle(r) #5

t.done()
