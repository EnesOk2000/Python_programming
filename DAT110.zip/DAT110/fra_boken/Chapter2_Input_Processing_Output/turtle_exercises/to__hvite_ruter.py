import turtle as t

LENGDE = 200

t.speed(1)
#t.hideturtle()
t.pensize(20)
t.pencolor('red')
t.bgcolor("black")
t.fillcolor("yellow")
t.begin_fill()

t.left(45)
t.forward(LENGDE) # hjørne oppe til HØYRE
t.right(90)
t.forward(LENGDE) # hjørne helt til høyre
t.right(90)
t.forward(LENGDE) # hjørne nede til høyre
t.right(90)
t.forward(LENGDE*2) # hjørne oppe til VENSTRE
t.left(90)
t.forward(LENGDE) # hjørne helt til venste
t.left(90)
t.forward(LENGDE) # hjørne nede til venstre
t.left(90)
t.forward(LENGDE) # tilbake til utgangspunkt (origo)

t.end_fill()
t.done()
