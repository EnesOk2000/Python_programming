import turtle as t
import math as m

LENGDE = 200
HYPO = m.sqrt(LENGDE**2 + LENGDE**2)

t.speed(8)
t.pensize(5)
t.bgcolor("cyan")

def trekant(): # x = left / right
    t.forward(LENGDE)
    t.left(135) #x
    t.forward(HYPO)
    t.left(135) #x
    t.forward(LENGDE)
    t.left(90)

def trekant_monster():
    trekant()
    t.backward(LENGDE)
    trekant()
    t.forward(LENGDE)
    t.left(90)
    t.forward(LENGDE)
    t.left(90)
    trekant()

trekant_monster()
t.left(90)
t.forward(LENGDE)
t.right(90)
trekant_monster()
t.done()
