import turtle as t

LENGDE = 150

t.speed(4)
#t.hideturtle()
t.pensize(5)
t.pencolor('red')
t.bgcolor("black")
t.fillcolor("yellow")
t.begin_fill()

t.goto(LENGDE,LENGDE)
t.goto(LENGDE*2,0)
t.goto(LENGDE,-LENGDE)
t.goto(-LENGDE,LENGDE)
t.goto(-LENGDE*2,0)
t.goto(-LENGDE,-LENGDE)
t.goto(0,0)

t.end_fill()
t.done()
