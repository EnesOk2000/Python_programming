import turtle as t
import math as m

LENGDE = 200
HYPO = m.sqrt(LENGDE**2 + LENGDE**2)

t.speed(5)
#t.hideturtle()
t.pensize(5)
t.pencolor('red')
t.bgcolor("black")
t.fillcolor("yellow")
t.begin_fill()

t.goto(LENGDE,LENGDE)
t.goto(0,HYPO)
t.goto(LENGDE,-LENGDE)
t.goto(-LENGDE,LENGDE)
t.goto(0,-HYPO)
t.goto(-LENGDE,-LENGDE)
t.goto(0,0)

t.end_fill()
t.done()
