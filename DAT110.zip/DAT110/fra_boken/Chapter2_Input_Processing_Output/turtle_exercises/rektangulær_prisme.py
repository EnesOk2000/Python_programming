import turtle as t
import math as m

LENGDE = 200
HYPO = m.sqrt(LENGDE**2 + LENGDE**2)

t.speed(5)
t.pensize(5)
t.bgcolor("cyan")

for i in range(4):
    t.forward(LENGDE)
    t.right(90)

for i in range(4):
    t.backward(LENGDE)
    t.right(90)

t.right(45)
t.forward(HYPO)
t.backward(HYPO*2)
t.left(45)
t.forward(LENGDE)
t.right(45)
t.forward(HYPO)
t.left(45)
t.backward(LENGDE*2)
t.right(45)
t.forward(HYPO)

t.done()
