import turtle as t

LENGDE=100
t.speed(10)
t.bgcolor("sky blue")

t.fillcolor("white")
t.begin_fill()
t.goto(LENGDE, -LENGDE)
t.goto(-LENGDE, -LENGDE)
t.goto(0,0)
t.end_fill()

t.goto(-LENGDE, -LENGDE)
t.goto(0, LENGDE)
t.goto(LENGDE, -LENGDE)

t.done()
