import turtle as t
import math as m

LENGDE = 200
HYPO = m.sqrt(LENGDE**2 + LENGDE**2)

t.speed(8)
t.pensize(5)
t.bgcolor("cyan")

def trekant(): # x = left / right
    t.forward(LENGDE)
    t.left(135) #x
    t.forward(HYPO)
    t.left(135) #x
    t.forward(LENGDE)

def trekanter3():
    t.left(180)
    trekant()
    t.backward(LENGDE)
    t.right(90)
    trekant()
    t.left(90)
    t.forward(LENGDE)
    t.left(180)
    trekant()

t.penup()
t.goto(0,200)
t.pendown()
trekanter3()
t.backward(LENGDE)
t.left(90)
t.penup()
t.forward(LENGDE)
t.pendown()
trekanter3()
t.done()
