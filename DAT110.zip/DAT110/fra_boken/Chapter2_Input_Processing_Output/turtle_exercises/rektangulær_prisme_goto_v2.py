import turtle as t
import math as m

LENGDE = 200
HYPO = m.sqrt(LENGDE**2 + LENGDE**2)

t.speed(4)
t.pensize(5)
t.bgcolor("cyan")

t.penup()
t.goto(-LENGDE,LENGDE)
t.pendown()

t.goto(0,LENGDE)
t.goto(LENGDE,0)
t.goto(LENGDE,-LENGDE)
t.goto(0,-LENGDE)
t.goto(-LENGDE,0)
t.goto(-LENGDE,LENGDE)

t.goto(LENGDE,-LENGDE)
t.goto(0,-LENGDE)
t.goto(0,LENGDE)
t.goto(0,0)
t.goto(-LENGDE,0)
t.goto(LENGDE,0)
t.goto(0,0)

t.done()
