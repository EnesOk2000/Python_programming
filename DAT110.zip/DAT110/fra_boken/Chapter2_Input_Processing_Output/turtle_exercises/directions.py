import turtle as t

LENGDE=200
RADIUS=LENGDE/4
t.speed(0)
t.pensize(3)

t.goto(0,LENGDE)
t.penup()
t.goto(-15,LENGDE)
t.write("NORTH")
t.goto(0,LENGDE)
t.pendown()

t.goto(0,-LENGDE)
t.penup()
t.goto(-15,-LENGDE-15)
t.write("SOUTH")
t.goto(0,-LENGDE)
t.pendown()

t.goto(0,-RADIUS)
t.circle(RADIUS)
t.goto(0,0)

t.goto(-LENGDE,0)
t.penup()
t.goto(-LENGDE-30,-7)
t.write("WEST")

t.goto(LENGDE+4,-7)
t.write("EAST")
t.goto(LENGDE,0)
t.pendown()
t.goto(0,0)

t.done()
