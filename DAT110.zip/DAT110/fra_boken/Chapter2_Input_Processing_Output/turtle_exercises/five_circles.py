import turtle as t

r=100
t.speed(10)

t.circle(r) #1

t.penup()
t.goto(230,0)
t.pendown()

t.circle(r) #2

t.penup()
t.goto(-230,0)
t.pendown()

t.circle(r) #3

t.penup()
t.goto(-120,-100)
t.pendown()

t.circle(r) #4

t.penup()
t.goto(120,-100)
t.pendown()

t.circle(r) #5

t.done()
