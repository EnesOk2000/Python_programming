pennies = int(input("Enter the number of pennies: "))
nickels = int(input("Enter the number of nickels: "))
dimes = int(input("Enter the number of dimes: "))
quarters = int(input("Enter the number of quarters: "))

# the coins worth in cents
penny_worth = 1
nickle_worth = 5
dime_worth = 10
quarter_worth = 25

one_dollar = 100 # one usd is equal to 100 cents

entered_total = pennies * penny_worth + nickels * nickle_worth + dimes * dime_worth + quarters * quarter_worth

if entered_total == one_dollar:
    print("Congratulations you won the money counting game!")
elif entered_total < one_dollar:
    print("The amount entered was less than a dollar.")
elif entered_total > one_dollar:
    print("The amount entered was more than a dollar.")
