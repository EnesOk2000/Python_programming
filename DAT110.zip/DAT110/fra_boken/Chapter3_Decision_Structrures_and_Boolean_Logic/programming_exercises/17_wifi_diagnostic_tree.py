print("Reboot the computer and try to connect.")
user_response = input("Did that fix the problem? ")
if user_response == "no":
    print("Reboot the router and try to connect.")
    user_response = input("Did that fix the problem? ")
    if user_response == "no":
        print("Make sure the cables between the router and modem are plugged in firmly.")
        user_response = input("Did that fix the problem? ")
        if user_response == "no":
            print("Move the router to a new location and try to connect.")
            user_response = input("Did that fix the problem? ")
            if user_response == "no":
                print("Get a new router.")
