day = int(input("Enter the numeric value of a day: "))
month = int(input("Enter the numeric value of a month: "))
year = int(input("Enter the the two last digits of a year: "))
if day*month == year:
    print("The date is magic")
else:
    print("The date is not magic")
# today, 5. april 2020, is a magic date LOL
