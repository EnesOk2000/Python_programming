month_nbr = int(input("Write the number of a month: "))

if month_nbr < 1 or 12 < month_nbr:
    print("Error. Number too small or big.")
else:
    if 1 <= month_nbr and month_nbr <= 3:
        print("The month is in the first quarter of the year.")
    elif 4 <= month_nbr and month_nbr <= 6:
        print("The month is in the second quarter of the year.")
    elif 7 <= month_nbr and month_nbr <= 9:
        print("The month is in the third quarter of the year.")
    elif 10 <= month_nbr and month_nbr <= 12:
        print("The month is in the fourth quarter of the year.")

# Alternatively:

#if 1 <= month_nbr and month_nbr <= 3:
#        print("The month is in the first quarter of the year.")
#elif 4 <= month_nbr and month_nbr <= 6:
#        print("The month is in the second quarter of the year.")
#elif 7 <= month_nbr and month_nbr <= 9:
#        print("The month is in the third quarter of the year.")
#elif 10 <= month_nbr and month_nbr <= 12:
#        print("The month is in the fourth quarter of the year.")
#else:
#    print("Error")
