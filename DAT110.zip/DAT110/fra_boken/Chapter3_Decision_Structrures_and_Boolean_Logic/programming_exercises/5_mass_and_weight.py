mass = float(input("Enter the mass of an object: "))
GRAVITY = 9.8
weight = mass * GRAVITY
if 500 < weight:
    print("The object is too heavy.")
elif weight < 100:
    print("The object is too light.")
else:
    print(weight)
