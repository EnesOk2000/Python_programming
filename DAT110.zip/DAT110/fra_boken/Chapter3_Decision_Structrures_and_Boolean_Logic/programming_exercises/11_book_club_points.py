books_purchased = int(input("Enter the number of books you have purchased this month: "))
points = 5
multiplier = 0
if books_purchased < 0:
    print("Error. Invalid number entered")
elif books_purchased <= 1:
    multiplier = 0
elif books_purchased <= 3:
    multiplier = 1
elif books_purchased <= 5:
    multiplier = 3
elif books_purchased <= 7:
    multiplier = 6
elif books_purchased >= 8:
    multiplier = 12
print("The number of points awarded to you this month:",multiplier*points)
