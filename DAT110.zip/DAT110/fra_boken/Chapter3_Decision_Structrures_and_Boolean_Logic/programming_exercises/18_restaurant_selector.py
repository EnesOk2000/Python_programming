vegetarian = input("Is anyone in your party a vegetarian? ")
vegan = input("Is anyone in your party a vegan? ")
gluten_free = input("Is anyone in your party a gluten-free? ")
print("Here are your restaurant choices: ")

if vegetarian == "no" and vegan == "no" and gluten_free == "no":
    print("""\tJoe's Gourmet Burgers
\tMain Street Pizza Company
\tCorner Café
\tMama's Fine Italian
\tThe Chef's Kitchen""")

elif vegetarian == "no" and vegan == "no" and gluten_free == "yes":
    print("""\tMain Street Pizza Company
\tCorner Café
\tThe Chef's Kitchen""")

elif vegetarian == "no" and vegan == "yes" and gluten_free == "no":
    print("""\tCorner Café
\tThe Chef's Kitchen""")

elif vegetarian == "no" and vegan == "yes" and gluten_free == "yes":
    print("""\tCorner Café
\tThe Chef's Kitchen""")

elif vegetarian == "yes" and vegan == "no" and gluten_free == "no":
    print("""\tMain Street Pizza Company
\tCorner Café
\tMama's Fine Italian
\tThe Chef's Kitchen""")

elif vegetarian == "yes" and vegan == "no" and gluten_free == "yes":
    print("""\tMain Street Pizza Company
\tCorner Café
\tThe Chef's Kitchen""")

elif vegetarian == "yes" and vegan == "yes" and gluten_free == "no":
    print("""\tCorner Café
\tThe Chef's Kitchen""")

elif vegetarian == "yes" and vegan == "yes" and gluten_free == "yes":
    print("\tCorner Café\n\tThe Chef's Kitchen")

else:
    print("ERROR: Invalid input")


#if vegetarian == "yes":
#    if vegan == "yes":
#        if gluten == "yes":
#            print
#        else:
#            print
#    else:
#        if gluten == "yes":
#            print
#        else:
#            print
#else:
#    if vegan == "yes":
#        if gluten == "yes":
#            print
#        else:
#            print
#    else:
#        if gluten == "yes":
#            print
#        else:
#            print
