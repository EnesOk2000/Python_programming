year = int(input("Enter a year: "))
if year % 100 == 0 and year % 400:
    leap_year = True
elif year % 4 == 0:
    leap_year = True
else:
    leap_year = False

if leap_year:
    print("In",year,"February has 29 days.")
else:
    print("In",year,"February has 28 days.")
