nbr_seconds = int(input("Enter number of seconds: "))

# in seconds
minute = 60
hour = 3600
day = 86400

if day <= nbr_seconds:
    nbr_days = nbr_seconds // day
    nbr_seconds = nbr_seconds - nbr_days * day
    nbr_hours = nbr_seconds // hour
    nbr_seconds = nbr_seconds - nbr_hours * hour
    nbr_minutes = nbr_seconds // minute
    nbr_seconds = nbr_seconds - nbr_minutes * minute
    print(nbr_days,"days,",nbr_hours,"hours,",nbr_minutes,"minutes and",nbr_seconds,"seconds")
elif hour <= nbr_seconds:
    nbr_hours = nbr_seconds // hour
    nbr_seconds = nbr_seconds - nbr_hours * hour
    nbr_minutes = nbr_seconds // minute
    nbr_seconds = nbr_seconds - nbr_minutes * minute
    print(nbr_hours,"hours,",nbr_minutes,"minutes and",nbr_seconds,"seconds")
elif minute <= nbr_seconds:
    nbr_minutes = nbr_seconds // minute
    nbr_seconds = nbr_seconds - nbr_minutes * minute
    print(nbr_minutes,"minutes and",nbr_seconds,"seconds")
else:
    print(nbr_seconds,"seconds")
