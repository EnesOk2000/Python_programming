weight = int(float(input("Enter the weight of the package: ")))

if weight <= 2:
    rate_per_pound = 1.5
elif 2 < weight and weight < 6:
    rate_per_pound = 3
elif 6 <= weight and weight < 10:
    rate_per_pound = 4
elif 10 <= weight:
    rate_per_pound = 4.75

shipping_charges = weight * rate_per_pound

print("The shipping charge: ",shipping_charges,"$",sep="")
