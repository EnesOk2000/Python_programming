test1 = int(input("Enter the score on your first test: "))
test2 = int(input("Enter the score on your second test: "))
exam = int(input("Enter the score on your exam: "))
if (0 <= test1 and test1 <= 25 and
    0 <= test2 and test2 <= 25 and
    0 <= exam and exam <= 50):
    total_score = test1 + test2 + exam
    print("Total score:",total_score)
    if exam < 25 or total_score < 50:
        print("Grade: fail")
    elif total_score < 60:
        print("Grade: pass")
    elif total_score < 80:
        print("Grade: credit")
    else:
        print("Grade: distinction")
else:
    print("ERROR: points not in valid range")
