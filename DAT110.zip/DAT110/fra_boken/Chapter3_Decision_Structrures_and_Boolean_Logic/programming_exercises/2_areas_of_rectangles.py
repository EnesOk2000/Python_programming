length_rec1 = float(input("Input the length of the first rectangle: "))
width_rec1 = float(input("Input the width of the first rectangle: "))

length_rec2 = float(input("Input the length of the second rectangle: "))
width_rec2 = float(input("Input the width of the second rectangle: "))

area_rec1 = length_rec1 * width_rec1
area_rec2 = length_rec2 * width_rec2

if area_rec1 > area_rec2:
    print("The area of the first rectangle is the greatest.")
elif area_rec1 < area_rec2:
    print("The area of the second rectangle is the greatest.")
else:
    print("The areas of the rectangles are the same.")
