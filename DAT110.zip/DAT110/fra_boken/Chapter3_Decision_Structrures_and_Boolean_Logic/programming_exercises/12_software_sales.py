nbr_purchases = int(input("Enter number of purchases: "))
package_price = 99
discount = 0
subtotal = nbr_purchases * package_price
if 10 <= nbr_purchases and nbr_purchases <= 19:
    discount=0.1
elif 20 <= nbr_purchases and nbr_purchases <= 49:
    discount=0.2
elif 50 <= nbr_purchases and nbr_purchases <= 99:
    discount=0.3
elif 100 <= nbr_purchases:
    discount=0.4

discount_amount = subtotal * discount
total_amount = subtotal - discount_amount
if discount !=0:
    print("The amount of the discount is ",format(discount_amount,".2f"),
          "$ and the total amount of the purchase is ",format(total_amount,".2f"),"$",sep="")
else:
    print("The total amount of the purchase is ",total_amount,"$",sep="")
