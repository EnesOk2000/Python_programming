import turtle as t

SCREEN_WIDTH = 700
SCREEN_HEIGHT = 700
TARGET_LLEFT_X = 100
TARGET_LLEFT_Y = 250
TARGET_WIDTH = 25
FORCE_FACTOR = 30
PROJECTILE_SPEED = 1
NORTH = 90
SOUTH = 270
EAST = 0
WEST = 180

t.setup(SCREEN_WIDTH, SCREEN_HEIGHT)

t.hideturtle()
t.speed(0)
t.penup()
t.goto(TARGET_LLEFT_X,TARGET_LLEFT_Y)
t.pendown()
t.setheading(EAST)
t.forward(TARGET_WIDTH)
t.setheading(NORTH)
t.forward(TARGET_WIDTH)
t.setheading(WEST)
t.forward(TARGET_WIDTH)
t.setheading(SOUTH)
t.forward(TARGET_WIDTH)
t.penup()

t.goto(0,0)
t.setheading(EAST)
t.showturtle()
t.speed(PROJECTILE_SPEED)

angle = float(input("Enter the projectile's angle (0 to 360): "))
force = float(input("Enter the launch force (1 to 15): "))
distance = force * FORCE_FACTOR
t.setheading(angle)
t.pendown()
t.forward(distance)


if (t.xcor() >= TARGET_LLEFT_X and
    t.xcor() <= (TARGET_LLEFT_X + TARGET_WIDTH) and
    t.ycor() >= TARGET_LLEFT_Y and
    t.ycor() <= (TARGET_LLEFT_Y + TARGET_WIDTH)):
        print("Congratulations, Hanh :) You hit the target and won the game!")
else:
    print("You missed the target")
    if angle < 60:
        print("Try a greater angle")
    elif angle > 70:
        print("Try a smaller angle")
    if force < 9:
        print("Use more force")
    elif force > 10:
        print("Use less force")
t.done()
