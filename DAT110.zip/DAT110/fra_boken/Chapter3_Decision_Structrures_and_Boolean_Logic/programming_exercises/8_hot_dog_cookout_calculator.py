nbr_people = int(input("Enter the number of people attending the cookout: "))
nbr_hot_dog_per_person = int(input("Enter the number of hot dogs each person will be given: "))

total_hot_dogs = nbr_people * nbr_hot_dog_per_person
total_hot_dogs_buns = total_hot_dogs

hot_dogs_per_pack = 10
hot_dogs_buns_per_pack = 8

if total_hot_dogs / hot_dogs_per_pack > total_hot_dogs // hot_dogs_per_pack :
    min_hot_dogs_packs =  total_hot_dogs // hot_dogs_per_pack + 1 # add plus one to round up
else:
    min_hot_dogs_packs =  total_hot_dogs // hot_dogs_per_pack

if total_hot_dogs_buns / hot_dogs_buns_per_pack > total_hot_dogs_buns // hot_dogs_buns_per_pack :
    min_hot_dogs_buns_packs = total_hot_dogs_buns // hot_dogs_buns_per_pack + 1 # add plus one to round up
else:
    min_hot_dogs_buns_packs = total_hot_dogs_buns // hot_dogs_buns_per_pack

print("The minimum number of packages of hot dogs required:",min_hot_dogs_packs)
print("The minimum number of packages of hot dogs buns required:",min_hot_dogs_buns_packs)
nbr_hot_dogs_left = min_hot_dogs_packs * hot_dogs_per_pack - total_hot_dogs
nbr_hot_dogs_buns_left = min_hot_dogs_buns_packs * hot_dogs_buns_per_pack - total_hot_dogs_buns
print("The number of hot dogs that will be left over:",nbr_hot_dogs_left)
print("The number of hot dogs buns that will be left over:",nbr_hot_dogs_buns_left)
