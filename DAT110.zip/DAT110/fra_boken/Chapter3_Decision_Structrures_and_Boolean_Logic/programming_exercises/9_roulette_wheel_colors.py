number = int(input("Enter a number through the range of 0 to 36: "))

if number < 0 or 36 < number:
    print("Error. Number not in the range of 0 through 36.")
elif number == 0:
        print("Pocket number",number,"is green.")
elif 1 <= number and number <= 10:
    if number % 2 == 0:
        print("Pocket number",number,"is black.")
    else:
        print("Pocket number",number,"is red.")
elif 11 <= number and number <= 18:
    if number % 2 == 0:
        print("Pocket number",number,"is red.")
    else:
        print("Pocket number",number,"is black.")
elif 19 <= number and number <= 28 and number % 2 == 0:
        print("Pocket number",number,"is black.")
elif 19 <= number and number <= 28 and number % 2 != 0:
        print("Pocket number",number,"is red.")
elif 29 <= number and number <= 36 and number % 2 == 0:
        print("Pocket number",number,"is red.")
elif 29 <= number and number <= 36 and number % 2 != 0:
        print("Pocket number",number,"is black.")
