integer = int(input("Input an integer: "))

if 0 < integer:
    print("Positive")
elif integer < 0:
    print("Negative")
else:
    print("Zero")

if integer % 2 == 0:
    print("Even")
else:
    print("Odd")
