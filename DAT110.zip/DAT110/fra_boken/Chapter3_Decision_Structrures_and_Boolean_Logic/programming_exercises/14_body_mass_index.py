weight = float(input("Enter your weight in pounds: "))
height = float(input("Enter your height in inches: "))

bmi = weight * 703 / height**2
print("Your BMI: ",format(bmi,".1f"))

if bmi < 18.5:
    print("You are underweight.")
elif 18.5 <= bmi and bmi <= 25:
    print("You have optimal weight.")
else:
    print("You are overweight.")
