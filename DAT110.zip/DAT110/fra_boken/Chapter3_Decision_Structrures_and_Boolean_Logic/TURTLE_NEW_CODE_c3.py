#
# This file contains all new ****TURTLE GRAPHICS***** code in chapter 3: Decision structures and boolean logic
#

t.isdown() # returnerer True når the pen is down

t.isvisible() # returnerer True når the turtle_tasks_chapter4 is visible

