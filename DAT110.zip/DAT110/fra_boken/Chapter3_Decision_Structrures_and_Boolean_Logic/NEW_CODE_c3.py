#
# This file contains all new code in chapter 3: Decision structures and boolean logic
#

# logiske operatorer og if-elif-else setninger
if x == y and a == b: # and returnerer bare True når begge uttrykk på hver side returnerer True
    sulten=1
elif x < y or a < b: # or returnerer True når minst et av uttrykkene returnerer True
    sliten=1
elif not(s < t): # Reverserer svaret på uttrykket inni parantesen
    sliten=0
else:
    sulten=0

# Dette er ekempler på booliske uttrykk (og relasjon operatorer) og uttrykkene returnerer enten True eller False.
x > y # x er større enn y
x < y # x er mindre enn y
x >= y # x er større enn eller lik y
x <= y # y er mindre enn eller lik y
x == y # x er lik y. Må ikke forvirres med tildelingstegnet som definerer variabler, altså bare en =
x != y # x er ikke lik y

"A" < "B" # returnerer True
"Enes Ok" > "Enes" # True siden første streng er lenger
"Mark" < "Mary" # True siden ascii koden for "k" er mindre enn "y"
"New York" > "NewYork" # False siden ascii koden for mellomrom er mindre en stor Y


if x >= 10 and x <= 100: # bruk "and" for å se om variablen er i et intervall
    print("X er i intervallet")
# husk at et av krokodilletegnene være mot x-en og den andre ikke sånn at intervallet gir mening
if x < 20 or 50 < x: # bruk "or" for å se om variablen ikke er i et intervall.
    print("X er ikke i intervallet")


#Dette er flag: en variabel som indikerer om en spesifikk tilstand eksisterer eller ikke
hungry = True # boolsk variabel
sleepy = False
stupid = 1 # binærisk variabel???
weak = 0


if (x == y and
    y < z and
    a != b):
        penger = 1000
