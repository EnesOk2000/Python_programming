tuition_increase_per_year = 1.03
current_year = 2020
next_years = 5
tuition_accumulator = 8000
print("Year\tTuition fee")
print("----------------------")
for year in range(current_year,current_year+next_years+1):
    print(year,'\t',format(tuition_accumulator,'.1f'))
    tuition_accumulator *= tuition_increase_per_year

print()######################################################################
