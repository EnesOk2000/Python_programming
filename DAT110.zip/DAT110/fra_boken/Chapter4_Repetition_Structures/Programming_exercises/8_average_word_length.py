word = "w"
total_length = 0
total_words = 0
while word != "":
    word = input("Enter a word or just press Enter without typing anything to end: ")
    if word != "":
        total_length += len(word)
        total_words += 1
average_length_words = total_length / total_words
print(format(average_length_words,".0f")) # rounds down on 0.5, but rounds up one 0.501
