mile_per_kilometer = 1.60934
print("Miles\t\tKilometers")
print("----------------------")
mile = 10
while mile <= 80:
    kilometer = mile_per_kilometer * mile
    print(mile,'\t\t\t',format(kilometer,'.2f'))
    mile += 10

#####################################################################################

print()
print("Miles\t\tKilometers")
print("------------------------")
for mile in range(10,81,10):
    kilometer = mile_per_kilometer * mile
    print(mile,'\t\t\t',format(kilometer,'.2f'))
