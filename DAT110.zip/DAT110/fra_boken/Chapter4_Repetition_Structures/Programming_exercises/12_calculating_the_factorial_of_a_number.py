number = int(input("Enter a non-negative integer: "))
while number < 0:
    print("Invalid value. Please try again.")
    number = int(input("Enter a non-negative integer: "))
count = 1
product = 1
while count <= number:
    product *= count
    count += 1
print("WHILE-LOOP: The factorial of",number,"is:",product)

#######################################################################################

product = 1
for xount in range(1,number+1):
    product *= xount
print("FOR-LOOP: The factorial of",number,"is:",product)
