desired_hours_sleep_per_day = 8
days_in_week = 7
desired_hours_sleep_per_week = desired_hours_sleep_per_day * days_in_week
total_hours_sleep_in_a_week = 0
for day in range(1,days_in_week+1):
    hours_slept_in_a_day = float(input("Enter how many hours you slept on day number "+str(day)+" of the week: "))
    total_hours_sleep_in_a_week += hours_slept_in_a_day
sleep_debt = total_hours_sleep_in_a_week - desired_hours_sleep_per_week
if 0 <= sleep_debt:
    print("You have no sleep debt. I am jealous.")
else:
    print("You have sleep debt. Sleep more.")
