miles_per_hour = float(input("Enter the vehicle's speed in miles per hour: "))
hours_traveled = float(input("Enter the number of hours the vehicle traveled: "))
print("Hour\t\tDistance traveled")
print("-------------------------")
hour_count = 1.0
while hour_count <= hours_traveled:
    distance_traveled = miles_per_hour * hour_count
    print(hour_count,'\t\t\t',format(distance_traveled,'.0f'))
    hour_count += 0.5 # eller 1.0

print()############################################################################################

miles_per_hour = float(input("Enter the vehicle's speed in miles per hour: "))
hours_traveled = int(input("Enter the number of hours the vehicle traveled: "))
print("Hour\t\tDistance traveled")
print("-------------------------")
#i en range funksjon kan man ikke bruke float.
#legg merke til at while-loopen er litt annerledes enn for-loopen på denne måten
for hour_count in range(1,hours_traveled+1): # Kan ikke ha 0.5 som stepper.
    distance_traveled = miles_per_hour * hour_count
    print(hour_count,'\t\t\t',format(distance_traveled,'.0f'))
