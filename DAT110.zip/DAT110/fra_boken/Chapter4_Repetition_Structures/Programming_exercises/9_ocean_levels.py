ocean_level_increase_per_year = 1.6
current_year = 2020
next_years = 25
ocean_level_accumulator = 0
print("Year\tOcean level")
print("----------------------")
for year in range(current_year,current_year+next_years+1):
    ocean_level_accumulator += ocean_level_increase_per_year
    print(year,'\t',format(ocean_level_accumulator,'.1f'))

print()######################################################################

ocean_level_accumulator = 0
print("Year\tOcean level")
print("----------------------")
year_count = current_year
while year_count <= current_year+next_years:
    ocean_level_accumulator += ocean_level_increase_per_year
    print(year_count,'\t',format(ocean_level_accumulator,'.1f'))
    year_count += 1
