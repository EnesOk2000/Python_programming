nbr_of_years = int(input("Enter number of years: "))
months_per_year = 12
total_rainfall = 0
for year in range(1, nbr_of_years+1):
    for month in range(1, months_per_year+1):
        monthly_rainfall = float(input("Enter the amount of rainfall in inches for month number "+str(month)+
                                       " in year number "+str(year)+": "))
        total_rainfall += monthly_rainfall
nbr_of_months = months_per_year * nbr_of_years
average_rainfall_per_month = total_rainfall / nbr_of_months
print("Total number of months:",nbr_of_months)
print("Total amount of rainfall in inches:",format(total_rainfall,".2f"))
print("Average rainfall (in inches) per month for the entire period: ",format(average_rainfall_per_month,".2f"))
