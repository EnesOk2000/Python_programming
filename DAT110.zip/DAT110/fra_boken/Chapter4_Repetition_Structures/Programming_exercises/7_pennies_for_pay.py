day = int(input("Enter number of days: "))
print('Days\t\tDollars')
print('--------------------')
dollar = 1
for d in range(1, day+1):
    print(d, '\t\t\t', dollar)
    dollar *= 2

print()#########################################################################################################

day = int(input("Enter number of days: "))
print('Days\t\tDollars')
print('--------------------')
dollar = 1
d = 1
for d in range(1, day+1):
    print(d, '\t\t\t', dollar)
    dollar *= 2
    d += 1
