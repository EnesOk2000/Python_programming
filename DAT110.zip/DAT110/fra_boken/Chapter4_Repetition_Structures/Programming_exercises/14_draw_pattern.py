width = int(input("Enter the width of the pattern: "))

for row in range(width, 0, -1):
    for col in range(row):
        print("*",end="")
    print()
