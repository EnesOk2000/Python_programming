import turtle as t
t.speed(0)

number_lines = 50
corners = 3 # kan endre dette tallet til høyere. f. eks: tall fra 3 til 10.
degrees = 360 / corners

#for counter in range(number_lines):
#    t.forward(counter*10)
#    t.left(degrees)
#t.done()

############################################

import turtle as t
t.speed(0)

number_lines = 50
corners = 3 # kan endre dette tallet til høyere. f. eks: tall fra 3 til 10.
degrees = 360 / corners

line_count = 0
while line_count < number_lines:
    t.forward(line_count*10)
    t.left(degrees)
    line_count += 1

t.done()
