import turtle as t
t.speed(0)

corners = 8 # only draw stars when 8 or over and only even numbers
total_degrees = 180 * (corners - 2)
angle_degrees = total_degrees / corners
print(total_degrees, angle_degrees)
for x in range(corners):
    t.forward(300)
    t.left(angle_degrees)
t.done()
