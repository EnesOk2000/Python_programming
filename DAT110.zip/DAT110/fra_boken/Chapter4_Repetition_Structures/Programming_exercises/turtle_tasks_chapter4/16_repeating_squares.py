import turtle as t
t.speed(0)
t.penup()
t.goto(200,-300)
t.pendown()

#for number_squares in range(100):
#    for draw_one_square in range(4):
#        t.left(90)
#        t.forward(number_squares*5+10) # hvis det ikke er plus 10 så blir første blir første gang forward(0)
#t.done()

#####################

number_squares = 50
corners = 7 # try 3, 4, 5, 8, 10
degrees = 360 / corners
number_squares_count = 0
while number_squares_count < number_squares:
    corners_count = 0 # i learned something about nested loops yay
    while corners_count < corners:
        t.left(degrees)
        t.forward(number_squares_count*5+10)
        corners_count += 1
    number_squares_count += 1

t.done()
print(corners_count,number_squares_count)
