import turtle as t

t.speed(0)
t.ht() # t.hideturtle
t.bgcolor("black")
t.pensize(10)
LENGTH=200
t.penup()
t.goto(0,-LENGTH)
t.backward(LENGTH/2)
t.pendown()

t.pencolor('white')
t.fillcolor("red") # makes fill red. returns current fillcolor as string if () is empty
t.begin_fill()
for c in range(8):
    t.forward(LENGTH)
    t.left(45)
t.end_fill()
t.penup()
t.goto(0,-50)
t.write("STOP", font=("Arial",120,"bold"), align='center')
t.done()
