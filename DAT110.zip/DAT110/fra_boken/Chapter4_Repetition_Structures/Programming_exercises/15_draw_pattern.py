stairsteps = int(input("Enter the width of the pattern: "))

for row in range(stairsteps):
    print("#",end="")
    for col in range(row):
        print(" ",end="")
    print("#")

# this for-loop won't run since there is only 0 in the range function.
for i in range(0):
    print("Hello")
