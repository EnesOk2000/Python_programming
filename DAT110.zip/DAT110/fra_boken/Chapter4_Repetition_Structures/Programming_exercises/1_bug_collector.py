day = 1
total_bugs = 0
while day <= 5:
    bugs_today = int(input("Enter the number of bugs collected on day number "+str(day)+": "))
    total_bugs += bugs_today
    day += 1
print("The total number of bugs collected in the",str(day-1),"days is",total_bugs)

print()##############################################################################################################

DAYS = 5
total_bugs = 0
for day in range(1, DAYS+1):
    bugs_today = int(input("Enter the number of bugs collected on day number "+str(day)+": "))
    total_bugs += bugs_today
print("The total number of bugs collected in the",str(DAYS),"days is",total_bugs)

