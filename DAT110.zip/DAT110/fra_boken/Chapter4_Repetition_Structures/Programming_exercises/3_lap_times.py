nbr_laps = int(input("Enter the number of laps: "))

slowest_lap_time = 0
fastest_lap_time = 100000
total_time = 0
for lap in range(1,nbr_laps+1):
    lap_time = int(input("Enter the time spent in seconds on lap number "+str(lap)+": "))
    if slowest_lap_time < lap_time:
        slowest_lap_time = lap_time
    if fastest_lap_time > lap_time:
        fastest_lap_time = lap_time
    total_time += lap_time
print("Fastest lap:",fastest_lap_time,"sec")
print("Slowest lap:",slowest_lap_time,"sec")
print("Average lap time:",format(total_time/nbr_laps,".0f"),"sec")

print()################################################################################################################

nbr_laps = int(input("Enter the number of laps: "))

slowest_lap_time = 0
fastest_lap_time = 100000
total_time = 0
lap = 1
while lap <= nbr_laps:
    lap_time = int(input("Enter the time spent in seconds on lap number "+str(lap)+": "))
    if slowest_lap_time < lap_time:
        slowest_lap_time = lap_time
    if fastest_lap_time > lap_time:
        fastest_lap_time = lap_time
    total_time += lap_time
    lap += 1
print("Fastest lap:",fastest_lap_time,"sec")
print("Slowest lap:",slowest_lap_time,"sec")
print("Average lap time:",format(total_time/nbr_laps,".0f"),"sec")
