CALORIES_BURNED_PER_MIN = 4.2
minutes = 10
print("Minutes\t\tCalories burned")
print("------------------------")
while minutes <= 30:
    calories_burned = CALORIES_BURNED_PER_MIN * minutes
    print(minutes,'\t\t\t',format(calories_burned,'.0f'))
    minutes += 5

#####################################################################################

print()
print("Minutes\t\tCalories burned")
print("------------------------")
for minutes in range(10,31,5):
    calories_burned = CALORIES_BURNED_PER_MIN * minutes
    print(minutes,'\t\t\t',format(calories_burned,'.0f'))
