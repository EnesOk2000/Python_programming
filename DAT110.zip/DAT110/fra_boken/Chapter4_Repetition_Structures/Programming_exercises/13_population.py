number_organisms_start = int(input("Enter the starting number of organisms: "))
while number_organisms_start < 0:
    print("Invalid value. Please try again.")
    number_organisms_start = int(input("Enter the starting number of organisms: "))

average_daily_increase = float(input("Enter the average daily population increase (as a percentage): "))
while average_daily_increase < 0:
    print("Invalid value. Please try again.")
    average_daily_increase = float(input("Enter the average daily population increase (as a percentage): "))

days_to_multiply = int(input("Enter the number of days the organisms will be left to multiply: "))
while days_to_multiply <= 0:
    print("Invalid value. Please try again.")
    days_to_multiply = int(input("Enter the number of days the organisms will be left to multiply: "))

print("\nDay\t\t\tApproximate population")
print("--------------------------------------")
population = number_organisms_start
increase = 1 + average_daily_increase / 100
for day in range(1,days_to_multiply+1):
    if day != 1:
        population *= increase
        print(day,"\t\t\t",format(population,".0f"))
    else:
        print(day,"\t\t\t",population)

print()#############################################################
population = number_organisms_start
count = 1
while count <= days_to_multiply:
    print(count,"\t\t\t",format(population,".2f"))
    population *= increase
    count += 1
