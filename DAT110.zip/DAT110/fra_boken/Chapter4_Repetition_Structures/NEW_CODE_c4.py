#
# This file contains all new code in chapter 4: Repetition structures
#

proceed = True
while proceed:
    print("123")
    svar =  input("Igjen. OK?")
    if svar != "OK":
        proceed = False
print("Du stoppet.")

keep_going = "ja"
while keep_going == "ja":
    print("HAAAII")
    keep_going =  input("Skriv ja hvis du vil fortsette? ")
print("Du sa ikke ja.")

x=2
while x <10:
    x*=2
    print(x)
print("Det var det.")

for num in [3, 9, 5]: # en liste etter "in"
    print(num, end=" ")

print()

for ord in ["Oi", "sann", ", så deg ikke!"]: # en liste etter "in"
    print(ord, end="")

print()

for x in range(20, -21, -2):
    # Første tall er startverdi til x. Andre tall er sluttverdi, men ikke inkludert. Tredje tall er stepper.
    # Range funksjonen lager iterable. Noe liggnende liste.
    print(x, end = " ")

print()

start = int(input("Tast inn startverdi: "))
slutt = int(input("Tast inn sluttverdi: "))

print()
print("Number\tSquare")
print("--------------")

for number in range(start, slutt + 1):
    square = number**2
    print(number, '\t', square)

accumulator = 0
for tall in range(start,0,-1):
    accumulator += tall
print("\nThe running total is",accumulator)

x += 5
x -= 5
x *= 5
x /= 5
x %= 2

print("Skriv inne en høyde i tall for å regne liksom BMI eller 0 for å avslutte")
hoyde=int(input("Høyde: "))
while hoyde != 0:
    bmi=hoyde*701
    print("BMI:",bmi)
    print("Skriv inne en høyde i tall for å regne liksom BMI eller 0 for å avslutte")
    hoyde=int(input("Høyde: "))

number = float(input("Enter a number between 1 and 100: "))
while number<1 or 100<number:
    number = float(input("Invalid value. Enter a number between 1 and 100: "))

for minutes in range(60):
    for seconds in range(60):
        print(minutes,":",seconds)

