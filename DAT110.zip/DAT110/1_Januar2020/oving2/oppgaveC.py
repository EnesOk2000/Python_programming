def farget_sekskant(size, color):
    import turtle
    turtle.fillcolor(color)
    turtle.begin_fill()
    for tall in range(6):
        turtle.forward(size)
        turtle.right(60)
    turtle.end_fill()
    return size, color

if __name__ == "__main__":
    size=int(input("Lengde på hver side i sekskanten: "))
    color=input("Farge på figuren (skriv på engelsk): ")
    farget_sekskant(size,color)
    import turtle
    turtle.done()

