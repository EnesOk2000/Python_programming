def liter():
    amerikansk_gallons_streng = input("Antall amerikanske gallons: ")
    amerikansk_gallons_tall = float(amerikansk_gallons_streng)
    liter = amerikansk_gallons_tall * 3.785411784
    print("Antal liter ", format(liter,"10.3f"))
    return liter

liter()


