import oppgaveD as D
antKolonner=int(input("Skriv inn øsnket antall kolonner: "))
antRader=int(input("Skriv inn øsnket antall rader: "))
D.monster(40,100,antKolonner,antRader)
