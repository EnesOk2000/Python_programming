def liter(gallons):
    liter = gallons * 3.785411784
    return liter

gallons=int(input("Antall gallons: "))
print("Antal liter ", format(liter(gallons),"10.3f"))


