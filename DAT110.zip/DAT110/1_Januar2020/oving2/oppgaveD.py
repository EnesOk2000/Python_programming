def monster(size=40,distance=130,column=4,row=5):
    import oppgaveC as C
    import turtle # burde skrive "as t" og så kan jeg bare skrive t. hver gang istedenfor turtle_tasks_chapter4. hver gang
    turtle.penup()
    turtle.goto(-300,300)
    turtle.pendown()
    blue=True
    for y in range(column):
        for x in range(row):
            if blue==True:
                C.farget_sekskant(size,"blue")
                blue=False
                turtle.penup()
                turtle.forward(distance)
                turtle.pendown()
            elif blue==False:
                C.farget_sekskant(size,"red")
                blue=True
                turtle.penup()
                turtle.forward(distance)
                turtle.pendown()
        turtle.penup()
        turtle.backward(distance*row)
        turtle.right(90)
        turtle.forward(distance)
        turtle.left(90)
        turtle.pendown()
    turtle.done()

if __name__ == "__main__":
    monster()


