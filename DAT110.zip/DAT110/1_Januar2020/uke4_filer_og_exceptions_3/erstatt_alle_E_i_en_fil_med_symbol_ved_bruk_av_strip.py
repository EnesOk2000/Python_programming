fil_referanse = open("test.txt", "r")
for linje in fil_referanse:
    ordene = linje.split()
    #print(ordene)
    for ord in ordene: #gå gjennom element for element i hele "ordene"
        bokstav=list(ord)
        #print(bokstav)
        for ja in bokstav:
            ja=ja.strip("e")
            if ja != "":
                print(ja, end="")
            else:
                print("_",end="")
        print(" ",end="")
    print(" ")
fil_referanse.close()
