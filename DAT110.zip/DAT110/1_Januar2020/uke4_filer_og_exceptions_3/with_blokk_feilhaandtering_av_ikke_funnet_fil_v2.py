try:
    with open("test.txt", "r", encoding="UTF-8") as fil_referanse: #fil_referanse er en variabel for resurrsen open(...)
        # utfører with-blokken, men uansett hvordan eller hvor man forlater with-blokken så lukkes resurrsen,
        # altså filen i dette tilfellet
        linje = fil_referanse.readline()
        for linje in fil_referanse:
            print(linje, end="")
except IOError as feilmeldingen:
    print("Feil i håndtering av fil: " + str(feilmeldingen))
except UnicodeDecodeError as e:
    print("Feil i koding av tekstfil: " + str(e))
