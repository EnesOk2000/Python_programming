fil_referanse = open("test.txt", "r")
streng = fil_referanse.readline() # readline() returnerer en streng.
streng = streng.strip() # "strip"-metoden fjerner whitespace på starten og slutten av en streng. finnes r-strip som gjør det bare på right. lstrip
print(str(streng),end="")

# metode: funksjon som operer på et objekt <objekt-refereanse>.metodenavn(parametre)

#open("mappe/fil.txt")
#open("mappe\\fil.txt")
#begge gjør samme
