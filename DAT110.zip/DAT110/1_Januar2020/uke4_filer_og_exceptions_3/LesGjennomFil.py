fil_referanse = open("test.txt", "r") #første parameter i parantesen er filen man ha tak i. andre parameter betyr at man vil lese filen (r for read)
#open returnerer et objekt. objektet representerer filen
streng = fil_referanse.readline() # ber objektet lese en linje. readline() returnerer en streng.
#print(streng)
for linje in fil_referanse: # går gjennom filen. for loopen ser objektet som en liste med linjer med text. kan erstatte variabelen linje med annet navn.
    print(linje, end="")

#objekt: samling av data og operasjoner. representerer en "ting"
#filer: tekstfiler (lesbare filer). binærfiler (uleslig for en person. disse filer kjøres av spesifikke programmer laget for hver enkelt fil)
