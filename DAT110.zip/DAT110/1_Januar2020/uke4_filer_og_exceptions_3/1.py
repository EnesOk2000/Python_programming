#fil_referanse = open("tall_filtrert.txt")
#linje = fil_referanse.read
#print(linje)

#fil_referanse = open("C:/Users/Enes Ok/PycharmProjects/1_Januar2020/oving3/tall_filtrert.txt", "r")
#linje = fil_referanse.readline()
#tall = float(linje)
#print(str(tall))
#for linje in fil_referanse:
    #print(linje, end="")
#fil_referanse.close()
