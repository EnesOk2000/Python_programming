def feilinput_enkel(representerer="en tallverdi"):
    exit = 0
    while exit == 0:
        brukerinput = input("Skriv inn "+representerer+": ")
        try:
            tallverdi=float(brukerinput)
            exit = 1
        except:
            print("Ugyldig verdi. Prøv på nytt med en lovlig verdi.")
    return tallverdi

tall = feilinput_enkel("vekt i antall kilogram")
print(str(tall),": ",type(tall))
#print(str(tall))
