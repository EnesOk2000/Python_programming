try:
    fil_referanse = open("test.txt", "r", encoding="UTF-8") # skev test,txt med vilje for å få IOError
    linje = fil_referanse.readline()
    for linje in fil_referanse:
        print(linje, end="")
        # forskjell på print og fil_referanse.write er at "print" lager automatisk "\n" på slutten mens ".write" ikke gjør det.
        # I tillegg er ".write" for å lage nye linjer i en fil mens "print" ikke er til det.
    #fil_referanse.close()
except IOError as feilmeldingen:
    print("Feil i håndtering av fil: " + str(feilmeldingen))
except UnicodeDecodeError as e:
    print("Feil i koding av tekstfil: " + str(e))
finally:
    try:
        fil_referanse.close()
    except IOError:
        print("Feil under close")
# en "finally"-blokk kjøres uansett etter try/except blokkene
