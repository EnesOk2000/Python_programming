def les_inn_tekst_fra_bruker(filnavn):
    fil_referanse = open(filnavn, "w") # w for wrtie. betyr lage en ny fil
    # , encoding="UTF-8"           legg dett til som tredje parameter i parantesen over så kan du se åøæ
    print("Skriv inn en tekst. Avslutt med tom linje.")
    linja = input(">>> ")
    fil_referanse.write(linja + "\n")
    while linja != "":
        linja = input(">>> ")
        if linja == "":
            break
        fil_referanse.write(linja + "\n")
    fil_referanse.close() # må huske å lukke fila

if __name__ == "__main__":
    les_inn_tekst_fra_bruker("test_filskriving.txt")

# r: betyr read. leser fila, får exception hvis den ikke finnes
# w: betyr write. skriver fila, lager den om den ikke fins, overskriver om den fins
# a: betyr append. skriver fila, lager den om den ikke fins, legger til på slutten hvis den allered fins.
