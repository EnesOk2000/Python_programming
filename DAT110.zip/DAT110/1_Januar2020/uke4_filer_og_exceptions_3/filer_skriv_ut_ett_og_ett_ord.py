fil_referanse = open("test.txt", "r")
for linje in fil_referanse:
    ordene = linje.split()
    for ord in ordene: #gå gjennom element for element i hele "ordene"
        print(ord, end="")
fil_referanse.close()
