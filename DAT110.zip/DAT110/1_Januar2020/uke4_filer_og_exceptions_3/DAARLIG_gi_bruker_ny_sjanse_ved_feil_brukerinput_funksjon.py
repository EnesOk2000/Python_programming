def feilinput():
    try:
        brukerinput = input("Skriv inn en tallverdi: ")
        tallverdi = float(brukerinput)
    except:
        exit = 0
        while exit == 0:
            print("Ugyldig verdi. Prøv på nytt med en lovlig verdi.")
            brukerinput = input("Skriv inn en tallverdi: ")
            try:
                tallverdi=float(brukerinput)
                exit = 1
            except:
                exit = 0
    return tallverdi
tall = feilinput()
print(str(tall))
