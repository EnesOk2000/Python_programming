import turtle

for tall in range(5):
    turtle.forward(200)
    turtle.right(72)
turtle.done()
