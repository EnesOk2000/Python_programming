import turtle # importerer inn turtle_tasks_chapter4 funksjonen sånn at det fungerer å bruke turtle_tasks_chapter4 etter denne linjen.
# man kan også importere "math"
turtle.forward(60)
turtle.right(90)
turtle.forward(60)
turtle.right(90)
#turtle_tasks_chapter4.pendown()
turtle.forward(60)
#turtle_tasks_chapter4.penup()
turtle.done() # uten denne så lukker turtle_tasks_chapter4-vinduet seg når kodene i scriptet er kjørt
