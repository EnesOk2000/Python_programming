# skriv inn flere linjer tekst, hvor brukeren avslutter med å skrive ei tom linje
print("skriv inn noe du")
linja=input(">>> ")
resultat = linja + "\n"
while linja != "":
    linja = input(">>> ")
    #resultat = resultat + linja + "\n"
    resultat += linja + "\n" # betyr det samme som linjen over
print(resultat)
