k=1
while k==1:
    print("dumming")
# dette er en evig while-loop
