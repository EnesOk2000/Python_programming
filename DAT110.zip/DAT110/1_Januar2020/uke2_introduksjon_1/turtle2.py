import turtle
turtle.forward(60) # tallet inni sier hvor langt turtlen skal gå
turtle.left(90) # tallet inni er antall grader turtle_tasks_chapter4 dreier seg til venstre
turtle.forward(60)
turtle.right(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(60)
turtle.right(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(60)
turtle.right(90)
turtle.forward(60)
turtle.left(90)
turtle.forward(60)
turtle.right(90)
turtle.forward(60)
turtle.done() # uten denne så lukker turtle_tasks_chapter4-vinduet seg når kodene i scriptet er kjørt
