lengde_streng = input("Lengden til rommet: ") # definerer en variabel som settes lik det brukeren putter inn
bredde_streng = input("Bredden til rommet: ")
lengde_tall = float(lengde_streng) # konverterer streng til tall sånn at det kan regnes med
bredde_tall = float(bredde_streng)
areal = lengde_tall * bredde_tall
print("Arealet er: " + str(areal))
# print("Arealet er: ", end="")
# print(str(areal))
# disse to linjene med kode ville kommet opp på hver si linje om det ikke var for end=""
# print(format(areal, "10.6f")) # gjør sånn at areal kun har 6 desimaler
# evalueres innenfra og ut, format kjører først, og så sendes resultatet av format til print
