tallet_streng = input("Skriv inn et tall")
tallet = float(tallet_streng)
# if betingelse: blokk
if tallet < 0:
    print("Tallet er negativt") # denne kjører bare hvis tallet er negativt
print(str(tallet)) # mens denne her kjøres uansett om tallet er negattivt eller ikke





