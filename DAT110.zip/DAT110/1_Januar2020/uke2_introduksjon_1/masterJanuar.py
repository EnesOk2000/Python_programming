print("en","streng","med","flere","parametere")
print("en","streng","med","flere","parametere",sep="+") # seperatoren er nå + istedenfor mellomrom
print("Tester linjeskift \n ny linje") # lager linjeskift
print("Tester linjeskift \t tab") # lager tab
print("Tester linjeskift \" ny anførselstegn") # skriver ut "
print("""Tester "anforseltegn" ja """)
print("Tester linjeskift \\ ny backslash")

import math
tall=math.pow(3,5)
print(tall)

tall=3**5 # tallet er 3 opphøyd i 5
type(tall) # viser hva slags type variabelen tall er

tall=5/3 # gir tall = 1.6666666666666667
round(tall) # gir tall = 2. Runder av til nærmeste heltall
int(tall) # gir tall = 1. Fjerner desimalene til et tall. Blir gjort om til en integer.

a!=b # betyr at a er ulik b
boolske operatorer: and or not

# ET SCRIPT ER ET PYTHON PROGRAM SOM BESTÅR AV FLERE LINJE AV KODE SOM KJØRER HVER FOR SEG I REKKEFØLGE

tall=132
tall > 100 # true
tall > 100 and tall < 150 # true
tall > 100 and tall < 120 # false
not tall < 100 # true


GRAVITASJON_JORDA = 9.81
# man burde skrive en variabel i bare store bokstaver om det er en variabel som ike skal endres på

streng1="test"
streng2="mer"
streng3=streng1+streng2 # skriver ut "testmer"
streng3=streng1+" "+streng2 # skriver ut "test mer"


