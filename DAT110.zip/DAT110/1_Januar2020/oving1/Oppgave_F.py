import turtle as t

RUTESTORRELSE = 50
RUTER_HORISONTAL = 3
RUTER_VERTIKAL = 4

for g in range(4):
    for h in range(RUTER_HORISONTAL):
        for i in range(4):
            t.forward(RUTESTORRELSE)
            t.right(90)
        t.forward(RUTESTORRELSE)
    t.backward(RUTESTORRELSE*RUTER_HORISONTAL)
    t.right(90)
    t.forward(RUTESTORRELSE)
t.done()
