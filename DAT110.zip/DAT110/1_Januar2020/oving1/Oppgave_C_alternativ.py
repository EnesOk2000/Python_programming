statment=True # True må skrives akkurat sånn her True. Stor T og små bokstaver for rue
pris=0
while statment==True:
    pakke_vekt_str = input("Oppgi pakkens vekt i kilogram: ")
    if pakke_vekt_str == "":
        break # både "break" og "statement=False" gjør sånn at man kommer seg ut av while-loopen
    if float(pakke_vekt_str) <= 0:
        statment=False # False må også skrives akkurat sånn
    pakke_vekt_nbr=float(pakke_vekt_str)
    if 0 < pakke_vekt_nbr < 10:
        pris+=149
        print("Pluss 149")
    elif 10 <= pakke_vekt_nbr < 25:
        pris+=268
        print("Pluss 268")
    elif 25 <= pakke_vekt_nbr <= 35:
        pris+=381
        print("Pluss 381")
    elif 35 < pakke_vekt_nbr:
        print("Pakker over 35 kilo er ikke tillatt")
    else:
        break
print("Total pris for alle pakkene: ", pris)

# inspirert av Eirik
