amerikansk_fot_streng = input("Antall amerikanske fot: ") # definerer en variabel som settes lik det brukeren putter inn
amerikansk_fot_tall = float(amerikansk_fot_streng) # konverterer streng til tall sånn at det kan regnes med
meter = amerikansk_fot_tall * 0.3048
print(format(meter,"10.3f"))
