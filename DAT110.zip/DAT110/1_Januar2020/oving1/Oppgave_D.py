import turtle
turtle.speed(7)
turtle.penup()
turtle.forward(100)
turtle.pendown()
for g in range(36):      #9   , 24  , 36  , 36 , 12 , 90
    turtle.right(130)   #160 , 165 , 130 , 170 , 30 , 92
    turtle.forward(400)
turtle.done()
