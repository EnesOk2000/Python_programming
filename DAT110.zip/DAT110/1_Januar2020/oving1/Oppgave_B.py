pakke_vekt_str = input("Oppgi pakkens vekt i kilogram: ") # definerer en variabel som settes lik det brukeren putter inn
pakke_vekt_nbr = float(pakke_vekt_str) # konverterer streng til tall sånn at det kan regnes med
if 0 <= pakke_vekt_nbr < 10:
    melding="149,-"
elif 10 <= pakke_vekt_nbr < 25:
    melding="268,-"
elif 25 <= pakke_vekt_nbr <= 35:
    melding="381,-"
elif 35 < pakke_vekt_nbr:
    melding="Pakker over 35 kilo er ikke tillatt."
elif pakke_vekt_nbr < 0:
    melding="Du kan ikke oppgi en negativ vekt på pakken."
else:
    melding="Noe gikk galt."
print(melding) # kunne eventuelt hatt en print kode (med unik beskjed) i hver if betingelse
