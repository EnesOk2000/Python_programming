# inni while loopen

if totalpris > maks_belop:
        totalpris -= pakkepris
        break
