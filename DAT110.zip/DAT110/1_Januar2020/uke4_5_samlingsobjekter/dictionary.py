# kalles dictionary, map, ssosiativ tabel.
# man har en collection og øsnker etter noko basert på noe som ikke er et tall.
# f. eks. har telefon katalog. har navnet på noen og ønskker å finne nummer. i dette tilfellet trengs dictionary.

telefonkatalog = {}
telefonkatalog["Jan Johansen"] = 12345678
telefonkatalog["Berit Wilsen"] = 23456789
telefonkatalog["David Tungdal"] = 34567892
print(telefonkatalog)

# et dictonary lagrer en serie med nøkkel-verdi par.
# "nøkkel: verdi." sånn ser det ut når man printer det ut
#nøkkelen må være unik. man kan si at man har en MENGDE med nøkler

telefonkatalog["Jan Johansen"] = 87654321 # overskriver forrige verdi fordi man bare kan ha en verdi for hver nøkkel
print(telefonkatalog)

# første gang så oppretter man en nøkkel, andre gangen så overskriver man.
#man henter ting basert på nøkkel

#telefonkatalog["Jan dohansen"] # gir keyerror

er_han_der = "Jan Johansen" in telefonkatalog # bruker in-operatoren for å sjekke om nøkkelen er i dictionaryet
print(er_han_der)

#er_han_der = "Jan JOhansen" in telefonkatalog # gir false
#skiller mellom store og små bokstaver

# hvis dere bruker strenger i dictionary, ville jeg anbefalt å konvertere alt til små bokstaver for eksempel, før man
# setter det inn for å hindre at brukers taster inn JAn og det gir feil.

#nøkler trenger ikke å ha samme type. kan ikke være en liste som type nøkkel

#nokkel_sok = input("Navn på person: ")
nokkel_sok = "David Tungdal" # f. eks

if nokkel_sok in telefonkatalog:
    print(telefonkatalog[nokkel_sok])
else:
    print("Personen du leter etter er ikke med")
# lar bruker taste inn et navn og kjører en if-test for å sjekke om personen finnes i dictionaryet og hvis ja, oppgir verdien

dictionary_2 = {"test": 5, "test2": 9}
print(dictionary_2)

# Generell syntaks dictionary[nøkkel] = verdi

for verdi in telefonkatalog:
    print(verdi)
# får ut nøkkelene i dictionaret

for nokkel in telefonkatalog:
    print(str(nokkel) + ": " + str(telefonkatalog[nokkel]))
# får ut nøkkelene og veridene

telefonkatalog["Åsmund Vik"]= 22225555
telefonkatalog[(3,6)]=33336666 # legger inn en tuppel som nøkkel
print(telefonkatalog)

del telefonkatalog[(3,6)] # hvordan slette en nøkkel, sletter også veriden til nøkkelen.
print(telefonkatalog)


