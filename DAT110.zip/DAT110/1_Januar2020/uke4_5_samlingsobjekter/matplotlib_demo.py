import matplotlib.pyplot as plt #plt er standardnavn for matplotlib
# for å plotte trenger du to lister. det kan være lister, numpy arrayes. muligens tupler eller ranges

x_koordinater = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
y_koordinater = []
for verdi in x_koordinater:
    y_koordinater.append(verdi**2)

# numpy
# import numpy as np
# x_koordinater = np.array(10)
# y_koordinater = x_koordinater**2 # med numpy slipper du den der for-loopen over.

plt.plot(x_koordinater,y_koordinater)
plt.xlabel("x-verdi")
plt.ylabel("y-verdi")
plt.title("Tester plotting")

y_2 = []
for verdi in x_koordinater:
    y_2.append(verdi*4)

plt.plot(x_koordinater,y_2)
plt.legend(("X i andre", "X ganger 4")) # rekkefølgen i tuppelet må være samme rekkefølge som det du plotter det i
plt.grid(True)
plt.plot(x_koordinater,y_koordinater,"o")
plt.show()
