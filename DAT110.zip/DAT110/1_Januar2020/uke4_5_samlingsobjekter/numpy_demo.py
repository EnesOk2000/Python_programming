import numpy as np

array = np.arange(7) # lager et array med 7 elementer. Fra og med 0 til og med 6.
for element in array:
    print(element) #printer ut alle elemente i arrayet med nylon tegn etter hvert element
array2 = np.zeros(6) # lager et array bestående av 6 nuller
array2[2] = 14.7 # bytter ut nullene i et element i arrayet med noe annet
print(array2[2]) # printer ut array sitt element nummer tre
print(array2[-2]) # printer ut nest siste element
print(array2) # printer ut hele arrayet
#del array2[2] # går ikke. append går heller ikke. man ikke legge til eller fjerne elementer i arrayet. bare endre verdier.
array2 = array2 + 5 # går gjennom hvert element og plusser hvert element med fem. kan også gange, dele, opphøye, osv.
print(array2)

array3 = np.array([2, 3, 2, 3, 2, 3, 2])
print(array3)
array = array * array3
print(array)

matrise1 = np.array([[1, 2, 3], [4, 5, 6]])
print(matrise1)
matrise2 = np.array([[4, 3], [5, 4], [6, 5]])
matrise3 = matrise1 @ matrise2 # ganger to patriser
print(matrise2)
print(matrise3)
matrise4 = matrise2 @ matrise1 # dette gir noe annet enn matrise3
print(matrise4)

# numpy:
# kan representere matrise
# spesiallaget for matematikk
# liste med kun float inni seg. kan kun inneholde float

zeroes_3d = np.zeros([2,3])
print(zeroes_3d)
zeroes_3d[1][1] = 4
print(zeroes_3d)

liste1 = [1, 2, 3]
liste2 = [4, 5, 6]
liste3 = [7, 8, 9]
liste_lister = []
liste_lister.append(liste1)
liste_lister.append(liste2)
liste_lister.append(liste3)

matrise_laget_av_lister = np.array(liste_lister)
print(matrise_laget_av_lister)
print(matrise_laget_av_lister[0:2, 0:2])
