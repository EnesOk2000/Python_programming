# en mengde er en samnling objetker so ikke kna inneholfer duplikat hvor objektene ikke har noen fast rekkefløre

mengde = set()
mengde = set([1, 2, 3])
print(mengde)
mengde.add(4) # kan ikke legge til et element som allerede er der. gjør ingenting.
print(mengde)
mengde.remove(2)
print(mengde)

# kan ikke bruke indexering på mengder.
# ikke samme rekkefølge på mengder

#mengder brukes

if 2 in mengde: # dette er rasker for mengder enn for lister
    print("2 er med")
else:
    print("2 er ikke med")

mengde2 = set([1, 3, 5, 7, 9, 11, 13])
mengde3=mengde.intersection(mengde2) # lager en ny mengde som inneholder begge mengenen
print(mengde3)
mengde4=mengde.union(mengde2) # motsatte, tar mengen av det som er med i minst en av mengdene
print(mengde4)

mengde5 = mengde - mengde2 # spør om hvilke elementer som finnes i den første som ikke finnes i mengde2.
# at det er elementer i den andre som det ikke er i den første, det spiller ingen rolle i denne operasjonen
print(mengde5)

mengde.add("Test") # går fint
mengde.add(3.6) # går fint
#mengde.add([5,6]) # dette går ikke. kan bare legge til ting som er immutable. ting som ikke kan endres.
mengde.add((5, 6)) # en tuppel kan legges til da.

mengde3 = set((2,4))
ja=mengde3 <= mengde2
print(ja)
#mengder er kjekke til bruk av medlemslitster i foreninger. sjekke hvem som er medlem i begge, elr hvem som er med i den ene men ikke andre

#printer ut alle element i en mengde
for e in mengde:
    print(e)

