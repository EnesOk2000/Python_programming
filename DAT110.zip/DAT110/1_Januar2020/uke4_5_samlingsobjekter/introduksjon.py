liste = [1, 2, 3, 4, 5] #liste som variabelnavn
print(liste)
print(liste[0])
print(liste[-1]) # negtiv indeks teller fra slutten. -1 gir siste element i listen. -2 gir nest siste

liste[0] = 8
print(liste)

liste.append(6) #metoden "append" legger til elementet inni parantesen inn i listen. append legger til ekstra element i lista
print(liste)

print(len(liste)) # gir lengden (len for length) på listen. F. eks: 6

#kan gå igjennom alle elementene i en liste
for element in liste:
    print(element) # du kan velge hva du gjør med hvert element.

liste[2] = "tjue"
# en liste kan inneholde element av forskjellige typer.
# En liste kan inneholde f. eks. inneholde to elementer av typen int, et element som er en streng og kan til og med
# inneholde en annen liste som et element.
print(liste)

liste[3] = [3, 4, 5]
print(liste)

print(liste[3][1])# tre-dimensjonalt array kaller på 4. element i listen og så 2. element i listen i listen
# dette er måten å lage fler-dimensjonale array

liste_av_lister = []
liste_av_lister.append([2, 3, 4, 5])
liste_av_lister.append([2, 3, 4])
liste_av_lister.append([5, 1])

#liste[7]=8 # for at dette skal gå må listen allerede ha et element [7]

print(type(liste_av_lister))

# lister er objekter og "append" er en metode som virker på disse objektene

liste3 = liste + liste_av_lister # man kan kombinere lister til en liste
print(liste3)
#liste3 = liste3 + 5 # dette går ikke

liste4 = [1]*10
print(liste4)

liste5 = [0,1]*10 # lager en liste med 0,1 ti ganger
print(liste5)

liste6 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print(liste6[2:5]) # dette kalles på engelsk en list-slice. [fra-og-med : til-men-ikke-med]
print(liste6[:5]) # tar fra begynnelsen og til [5], altså til-og-med element 5, men ikke 6. element
print(liste6[5:]) # fra og med element nr6 og til slutten av arrayet
print(liste6[:]) # printer ut alle verdiene
print("HEI",liste6[1:20:2]) # tredje parameter i [] er antall steg, skrittellere. gjør ikke noe her om parameter 2 er for stor

liste_test = liste6
liste6[0] = 8
print(liste_test[0]) # man skulle tro at 0 printes ut, men ut ifra linjen før så endres [0] til 8.
# Både liste6 og liste_test referer til samme liste så når en verdi i listen endres ser man det for begge variabelene

liste_test = liste6[:] # dette lager en ny liste for liste_test og elementene er like som de i liste6
liste6[8] = 16
print(liste_test[8]) # her printes ikke 16 ut fordi liste_test har en egen liste for seg selv nå.

mmmmmmm = 6 in liste6 # returnerer True eller False
vvvvvvv = 18 in liste6
print(mmmmmmm,vvvvvvv)

verdi = -5
if verdi in liste6: # for å sjekke om verdien er i liste
    print("Verdien er i lista")
else: # eller ikke
    print("Verdien er ikke i lista")

print(liste6)
print(liste6.index(7))
print(liste6.index(16)) # returnerer kun indexen på plassen som tallet 16 ligger

liste6.insert(7, 14) # setter in verdien 14 i index 7 og alle elementer etter blir forskjøvet et hakk opp
print(liste6)

liste6.remove(5) # fjerner kun første forekomst av tallet 5. listen forskyves deretter et hakk opp/ned
print(liste6)

del liste6[0] # hvis jeg ønsker å fjerne på indeks. dette er en operator og ikke funksjon.
print(liste6)

print("Usortert: ",liste6)
liste6.sort()
print("Sortert: ",liste6)

print(liste)
#liste.sort() # går ikke hvis det er blanding av "int" og "str", men det går å sortere listen hvis det bare er en av typene

5<7 #returnerer True
5<3 #returnerer False
"A" < "C" #returnerer True fordi askii koden (nummeret) til A er mindre enn C.
"F" < "D" #returnerer False fordi F er lenger frem i alfabetet enn D
"G" < "a" #returnerer True fordi store bokstaver har lavere verdi i askiikoden enn småbokstaver

streng = "Test"
print(len(streng))
print(streng[2])

liste9876=[] # dette er en måte å lage en liste på men den under er foretrukket
liste12345=list() # er en konstrktør. ikke en vanlig funksjon. tema: klasser og objekter. dette er anbefalt å lage en liste på denne måten
# foreløpig kan en konstruktør tenkes som en funksjon som lager et objekt med det navnet. finnes flere konstruktører
liste12345.append([2, 3, 4, 5])
liste12345.append([8, 9])
print(liste12345)

for teller, verdi in enumerate(liste6):
    print(str(teller) + ": " + str(verdi))

print( min(liste6) ) # finner minste verdi i en liste. dette krever at listen er sammenlignbar (at elementer er av samme type)
print( max(liste6) ) # hvis de ikke er sammenlignbare så kommer det TypeError

tuppel= (1, 2, 3)
print(tuppel)
print(type(tuppel))
print(tuppel[0])
print(tuppel[1])
print(tuppel[0:1]) #ser ut som at kommaet regnes som et element
print(tuppel[0:2])
#tuppel[0] = 5 # går ikke fordi man ikke kan endre en tuppel

#tuppel.append(7) # et tuppel har ikke denne metoden. denne metoden kan ikke brukes på tuppel
# En tuppel kan anses som en liste som ikke kan endres etter at den er laget. kan ikke forandre.
# hvorfor bruke tuppel: fordi mer effektiv i bruken, og behandling hvis alt man ønsker å gjøre er lesing. tar mindre plass
# I tillegg så kan tupler brukes steder hvor lister ikke kan brukes

