def pluss(v1,v2):
    v1 = v1 + v2
    print(v1)

tall = 5
tall2 = 7
pluss(tall, tall2)
print(tall)
print(tall2)

def listefunk(liste1):
    liste1[3] = 6
    print("6")

liste = [0, 1, 2, 3, 4, 5, 6]
listefunk(liste)
for element in liste:
    print(element)
