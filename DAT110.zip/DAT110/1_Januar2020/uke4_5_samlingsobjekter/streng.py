# en streng kan sees på som en liste med tegn
# mye av det man kan gjøre med lister, kan man gjøre med strenger

streng = "Dette er en streng"
print(len(streng))
print(streng[3])
print(streng[3:12])
ordliste = streng.split() # metode som kaller på streng. gir array av strenger. kan kalles uten paramet. kan spittes på +,. eller hva enn
print(ordliste)

streng.strip() # fjerner whitespace (melleomrom, shift og nylon-tegn) fra starten og slutten av streng.
streng.strip(",.;:") # fjerner dette fra starten og slutten av en streng

streng2=streng.lower() # konverterer alle bokstavene i variabelen "streng" til små bokstaver og så lager en ny streng av det. .upper finnes

pris = 129
pris -= 100
print(pris)
formatert_streng = "Total pris: %d" % pris # kan også skrive %6d, gir 6 siffer. %3d og andre tall funker også. "d" for desimal
print(formatert_streng)

formatert_streng = "Total pris: %8.5f" % pris #funder opp til tall med fem desimall

lengde = 4.0
bredde = 3.0
import math
vinkel = math.pi/2.0
areal = 0.5*lengde*bredde*math.sin(vinkel)

#lang = "Arealet til en trekant med lengde %7.2f og bredde %7.2f og vinkel %6.2 er %8.2f" % (lengde, bredde, vinkel, areal)
#print(lang)

#formatert_streng = "Total pris: "+format(pris, "%6d") # "8.5f"
#print(formatert_streng)

#tall=1.2
#formatert_streng = "Total pris: {pris}"
#formatert_streng.format{pris = tall}

#formatert_streng = "Total pris: {testtall:8.5f}"
#formatert_streng.format{testtall=neinei}

formatert_streng = f"Totalpris: {pris}"
print(formatert_streng)

formatert_streng = f"Totalpris: {pris:8.5f}"
print(formatert_streng)

formatert_streng = f"lengde {lengde:8.5f}, bredde {bredde:2.2f}, vinkel {vinkel:4.2f},,, areal={areal}"
print(formatert_streng)


