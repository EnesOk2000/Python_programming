fil_referanse = open("tall_filtrert.txt", "r")
linje = fil_referanse.readline()
tall = float(linje)
print(str(tall))
i=0
min=2
max=0
sum=0
for linje in fil_referanse:
    #print(linje, end="")
    i+=1
    sum=sum+float(linje)
    if float(linje)<float(min):
        min=linje
    if float(linje)>float(max):
        max=linje
    gjn=sum/i
fil_referanse.close()
ant="Antall: "+str(i)+"\n" # var egentligprint
min="Minimum: "+str(min)
max="Maksimum: "+str(max)
gje="Gjennomsnittet: "+str(gjn)+"\n"

#x=type(tall)
#print(x)

#fil_referanse = open("tall_filtrert.txt","r")
#linje = fil_referanse.read()
#linje = float(linje)
#print(str(linje),end="")

new = open("new.txt", "w+")
new.write(ant+gje+max+min)
#new.write("Antall: "+str(i)+"\n"+"Gjennomsnittet: "+str(gjn)+"\n"+"Maksimum: "+str(max)+"\n"+"Minimum: "+str(min))
#new.write(gje)
#new.write(max)
#new.write(min)


