def pakker():
    try:
        pakke_vekt_str = "e"
        totalpris=0 # dette kalles for en akumulator siden den
        pris=0
        while pakke_vekt_str != "":
            pakke_vekt_str = input("Oppgi pakkens vekt i kilogram: ")
            if pakke_vekt_str == "":
                break
            pakke_vekt_nbr = float(pakke_vekt_str)
            if pakke_vekt_nbr <= 0:
                pakke_vekt_str = ""
                #print("ok")
            if 0 < pakke_vekt_nbr < 10: # det å skrive " 0 < pakke... " er ikke nødvendig siden ut ifra forigge if test så vet vi at vekten er mer enn 0.
                pris=149
                print("Pluss 149")
            elif 10 <= pakke_vekt_nbr < 25:
                pris=268
                print("Pluss 268")
            elif 25 <= pakke_vekt_nbr <= 35:
                pris=381
                print("Pluss 381")
            elif 35 < pakke_vekt_nbr:
                print("Pakker over 35 kilo er ikke tillatt")
            else:
                break
            totalpris += pris
        print("Total pris for alle pakkene: ", totalpris)
    except ValueError:
        print("Feil: Ikke gyldig inntasting for vekt")
pakker()
