import turtle as t
from random import randint

def trekant():
    for i in range(3):
        t.forward(50)
        if i < 2:
            t.left(120)

#t.speed(0)
t.tracer(0)
for g in range(10000):
    GRADER=60
    LF=randint(0,10)
    if LF < 10:
        t.left(GRADER)
    if LF == 10:
        t.right(GRADER)
    t.forward(10)
    t.update()
    #print(LF)
t.done()
