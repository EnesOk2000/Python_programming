import turtle as t

def trekant(length):
    for i in range(3):
        t.forward(length)
        t.left(120)

#t.forward(120)

def sekskant(length):
    for j in range(6):
        t.forward(length)
        t.left(60)

start_length=60
for k in range(3,31,3):
    trekant(start_length*k)
    t.forward(start_length*k*0.3)
    sekskant(start_length*k*0.3)
    print(k)

t.done()
