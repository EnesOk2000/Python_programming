import turtle as t

t.penup()
t.goto(0,-250)
t.pendown()

def up():
    t.left(90)
    t.penup()
    t.forward(40)
    t.pendown()
    t.right(90)

#t.speed(0)
t.tracer(0)

rotate=6
for i in range(1080): # for hver 60 lages det en krusedull
    value=rotate*i
    t.left(value)
    t.forward(10)

    if i==120:
        up()
    if i==240:
        up()
    if i==360:
        up()
    if i==480:
        up()
    if i==600:
        up()
    if i==720:
        up()
    if i==840:
        up()
    if i==960:
        up()
    #print(value)
    t.update()

t.done()
