import turtle as t
from random import randint

def firkant():
    for i in range(4):
        t.forward(50)
        if i < 3:
            t.left(90)

def trekant():
    for i in range(3):
        t.forward(50)
        if i < 2:
            t.left(120)

t.speed(0)
#t.tracer(0)
CHANCE=0
left=True
GRADER=randint(30,60)
for g in range(100):
    if left == True:
       left=False
       firkant()
    elif left == False:
        left=True
        trekant()
    if CHANCE == 0:
        t.left(GRADER)
    elif CHANCE == 1:
        t.right(GRADER)
    t.forward(100)
    CHANCE=randint(0,1)
    #t.update()
t.done()
