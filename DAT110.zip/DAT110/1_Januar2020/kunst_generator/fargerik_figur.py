import turtle as t

def trekant(length):
    for i in range(3):
        t.forward(length)
        t.left(120)

def firkant(length):
    for i in range(4):
        t.forward(length)
        t.left(90)

def sekskant(length,color):
    t.fillcolor(color)
    t.begin_fill()
    for j in range(6):
        t.forward(length)
        t.left(60)
    t.end_fill()

#for k in range(1,7,2):
    #trekant(360/k)
    #t.forward(360/(2*k))
    #print(k)
t.penup()
t.goto(-300,-300)
t.pendown
t.tracer(0)
#t.speed(0)
n=360
blue=True
while n>4:
    if blue==True:
        sekskant(n,"blue")
        blue=False
    elif blue==False:
        sekskant(n,"red")
        blue=True
    t.penup()
    t.left(60)
    t.forward(n*0.15)
    t.right(60)
    t.pendown()
    n*=0.90

#t.update()
#for i in range(3):
        #t.forward(360)
        #t.left(120)
#t.forward(180/2)
#for i in range(3):
        #t.forward(180)
        #t.left(120)
#t.forward(90/2)
#for i in range(3):
        #t.forward(90)
        #t.left(120)
#t.forward(40/3)
t.done()
