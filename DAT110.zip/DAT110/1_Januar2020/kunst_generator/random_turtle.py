import turtle as t
from random import randint

for g in range(100):
    LENGDE=randint(0,100)
    if LENGDE == 0:
        t.done()
    if 0 < LENGDE <= 45:
        t.left(LENGDE)
    elif 55 <= LENGDE <= 100:
        t.right(LENGDE)
    t.forward(LENGDE)
t.done()
