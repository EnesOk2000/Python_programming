import turtle as t
from random import randint

for g in range(10000):
    #t.speed(0)
    t.tracer(0)
    LENGDE=randint(0,30)
    GRADER=randint(0,360)
    t.right(GRADER)
    t.forward(LENGDE)
    #t.update()
t.done()

#t.speed(0) alene tegner i raskest hastighet

#t.tracer(0) og til slutt t.update() tegner super duper raskt, raskere enn raskest

#t.tracer(0) alene tegner alt opp på en gang på et øyeblunk
