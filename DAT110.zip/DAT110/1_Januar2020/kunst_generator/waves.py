import turtle as t

#t.left(10.25)
#t.forward(500)

#t.speed(0)
t.tracer(0)

t.penup()
t.goto(-800,0)
t.pendown()

rotate=1 # 6
for i in range(1440): # 120
    value=rotate*i
    t.left(value)
    t.forward(30)

    print(value)
    t.update()
    if i==180:
        t.left(90)
    if i==360:
        t.left(90)
    if i==540:
        t.left(90)
    if i==720:
        t.left(90)
    if i==900:
        t.left(90)
    if i==1080:
        t.left(90)
    if i==1260:
        t.left(90)
t.done()
