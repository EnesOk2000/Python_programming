from random import randint

for x in range(100):
    value = randint(0,100)
    print(value)

