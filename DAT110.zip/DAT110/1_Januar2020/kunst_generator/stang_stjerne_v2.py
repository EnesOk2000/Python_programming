import turtle as t
def stang():
    for a in range(1,10):
        t.forward(5*a)
        t.right(a)
    for b in range(11,1,-1):
        t.forward(5*b)
        t.right(120)
    t.penup()
    t.goto(0,0)
    t.pendown()
    t.left(120*10)
    t.left(45)
t.speed(0)
for f in range(18):
    t.right(20)
    stang()
t.done()
