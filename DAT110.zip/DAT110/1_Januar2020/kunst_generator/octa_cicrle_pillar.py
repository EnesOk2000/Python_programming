import turtle as t
def sirkel(big):
    for i in range(72):
        t.forward(big)
        t.left(5)
t.tracer(0)
#t.speed(0)
t.penup()
t.goto(0,-200)
t.pendown()
sirkel(17)
t.left(90)
def octa():
    sirkel(7)
    t.penup()
    for i in range(18+9*1): #18*k=18 --> k=1
        t.forward(7)
        t.left(5)
    t.pendown()
    t.left(180)
#sirkel(4)
#t.penup()
#for i in range(45):
#        t.forward(4)
#        t.left(5)
#t.pendown()
for u in range(1,9):
    octa()
t.penup()
t.forward(65)
t.pendown()
t.right(90)
sirkel(11)
t.update()
t.done()
