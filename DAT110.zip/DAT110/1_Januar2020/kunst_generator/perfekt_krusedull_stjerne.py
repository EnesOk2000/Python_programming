import turtle as t

#t.speed(0)
t.tracer(0)

rotate=0.1
for i in range(28800): # for hver 3600 lages det en krusedull
    value=rotate*i
    t.left(value)
    t.forward(10)

    if i == 7200:
        t.left(90)
    if i == 14400:
        t.left(45)
    if i == 21600:
        t.left(90)
    #print(value)
    #t.update()

t.done()
