import turtle as t
from random import randint
left=True
for g in range(1000):
    #t.speed(0)
    t.tracer(0)
    LENGDE=randint(0,10)
    GRADER=randint(0,120)
    t.update()
    if left==True:
        t.left(GRADER)
        left=False
    elif left==False:
        t.right(GRADER)
        left=True
    t.forward(LENGDE)
t.done()

#t.speed(0) alene tegner i raskest hastighet

#t.tracer(0) og til slutt t.update() tegner super duper raskt, raskere enn raskest

#t.tracer(0) alene tegner alt opp på en gang på et øyeblunk

# om disse linjene med kode er inni eller utenfor for-loopen gjør en forskjell
