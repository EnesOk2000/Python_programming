import turtle as t

#t.left(10.25)
#t.forward(500)

t.speed(0)
#t.tracer(0)

rotate=6 # 100, 10
for i in range(120):
    value=rotate*i
    t.left(value)
    t.forward(100) # 400 , 40

    t.penup()
    t.left(180)
    t.forward(10) # 40 , 400
    t.left(180)
    t.pendown()
    print(value)
    #t.update()
t.done()
