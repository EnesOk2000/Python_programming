import turtle as t

#t.speed(0)
t.tracer(0)

rotate=1
for i in range(720): # for hver 3600 lages det en krusedull
    value=rotate*i
    t.left(value)
    t.forward(30)
    #print(value)
    #t.update()

t.left(180)

for i in range(720): # for hver 3600 lages det en krusedull
    value=rotate*i
    t.right(value)
    t.forward(30)
    #print(value)
    #t.update()

t.left(90)

for i in range(720): # for hver 3600 lages det en krusedull
    value=rotate*i
    t.right(value)
    t.forward(30)

t.done()
