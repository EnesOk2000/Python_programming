import turtle as t
from random import randint

for g in range(100):
    LENGDE=randint(0,50)
    GRADER=randint(45,135)
    #if GRADER == 45 or g == 99:
        #t.done()
        #break
    if 0 < LENGDE <= 20:
        t.left(GRADER)
    elif 30 < LENGDE <= 50:
        t.right(GRADER)
    t.forward(LENGDE)
t.done()
