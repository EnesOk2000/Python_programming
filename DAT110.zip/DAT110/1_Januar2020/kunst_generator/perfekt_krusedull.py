import turtle as t

t.penup()
t.goto(-250,-250)
t.pendown()

#t.speed(0)
t.tracer(0)

rotate=0.01
for i in range(10000): # for hver 60 lages det en krusedull
    value=rotate*i
    t.left(value)
    t.forward(5)

    #print(value)
    #t.update()

t.done()
