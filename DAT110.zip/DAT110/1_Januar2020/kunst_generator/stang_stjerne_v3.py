import turtle as t
def stang():
    for a in range(1,10):
        t.forward(10*a)
        t.right(a*5)
    for b in range(11,1,-1):
        t.forward(5*b)
        t.right(100)
    t.penup()
    t.goto(0,0)
    t.pendown()
    t.left(100*10)
    t.left(45)
t.speed(0)
for f in range(100):
    t.right(72)
    stang()
t.done()
