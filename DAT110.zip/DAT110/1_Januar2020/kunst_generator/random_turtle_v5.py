import turtle as t
from random import randint
#t.penup()
#t.goto(200,100)
#t.pendown()
big=True
for g in range(10000):
    #t.speed(0)
    t.tracer(0)
    #t.update()
    LENGDE=400 #randint(110,111)
    # 400 , --- , --- , 300
    #GRADER=randint(120,121)
    #t.right(GRADER)
    #t.forward(LENGDE)

    t.speed()
    #t.tracer(0)
    #t.update()
    if big==True:
        t.right(180.25)
        # 121 , 161 , 171 , 181
        big=False
    elif big==False:
        t.right(180)
        # 120 , 160 , 170 , 180
        big=True
    t.forward(LENGDE)
t.done()

#t.speed(0) alene tegner i raskest hastighet

#t.tracer(0) og til slutt t.update() tegner super duper raskt, raskere enn raskest

#t.tracer(0) alene tegner alt opp på en gang på et øyeblunk
