import turtle as t

def ok():
    t.left(120)
    t.forward(20)

#t.speed(0)
t.tracer(0)

rotate=0.1
for i in range(21600): # for hver 3600 lages det en krusedull
    value=rotate*i
    t.left(value)
    t.forward(10)

    if i == 3600:
        ok()
    if i == 7200:
        ok()
    if i == 10800:
        ok()
    if i == 14400:
        ok()
    if i == 18000:
        ok()

    #print(value)
    #t.update()

t.done()
