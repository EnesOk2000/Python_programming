hoyde = int(input("Høyde: "))
bredde = int(input("Bredde: "))
# rader burde være innerst
for y in range(hoyde):
    for x in range(bredde):
        print("*", end="") #denne print setningen kjører hoyde*bredde ganger
    print() #skriver ut tom linje
