# Regner ut volumet av et rom

#lager egen funksjon
def les_inn_flyttall(representerer):
    tall_streng = input(representerer + ": ")
    tall = float(tall_streng)
    # return 0, gjør at funksjonen slutter her
    while tall <= 0:
        print(representerer + " må være positiv!")
        tall_streng = input(representerer + ": ")
        tall = float(tall_streng)
    return tall #returnerer en verdi
    # husk på at "tall" her er en lokal variabel

print("Volumet til et rom:")
lengde = les_inn_flyttall("Lengde")
bredde = les_inn_flyttall("Bredde")
hoyde = les_inn_flyttall("Hoyde")
volum = lengde*bredde*hoyde
print("Volumet er: ", str(volum))

#print("Volumet til et rom:")
#lengde_streng = input("Lengde: ")
#lengde = float(lengde_streng)
#while lengde <= 0:
#    print("Rommet må ha positiv lengde!")
#    lengde_streng = input("Lengde: ")
#    lengde = float(lengde_streng)
