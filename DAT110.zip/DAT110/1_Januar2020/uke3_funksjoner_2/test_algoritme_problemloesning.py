# Eksempel på hvordan å løse et problem gjennom å dele problemet i deler
# og løse hver del for seg, en etter en.
#
# Tegn en "diamant" med oppgitt størrelse. Eksempel med størrelse 4:
# - - - X - - -
# - - X - X - -
# - X - - - X -
# X - - - - - X
# - X - - - X -
# - - X - X - -
# - - - X - - -
def diamant(storrelse=3,mellomrom=" ",symbol="*"):
#print("Diamant eksempel")
#storrelse = int(input("Størrelse: "))
    for y in range(storrelse):
        for x in range(storrelse):
            if x == storrelse-y-1:
                print(symbol, end="")
            else:
                print(mellomrom, end="")
        for x in range(storrelse-1):
            if x == y-1:
                print(symbol, end="")
            else:
                print(mellomrom, end="")
        print()
    for y in range(1, storrelse):
        for x in range(storrelse):
            if x == y:
                print(symbol, end="")
            else:
                print(mellomrom, end="")
        for x in range(storrelse-1):
            if x == storrelse-y-2:
                print(symbol, end="")
            else:
                print(mellomrom, end="")
        print()

diamant(6)
diamant(4," - "," x ")
