def skriv_ut_firkant(hoyde=3, bredde=3, tegn="x"): # tegn="*" gir tegn en default verdi
    for y in range(hoyde):
        for x in range(bredde):
            print(tegn, end="")
        print()

hoyde = int(input("Høyde: "))
bredde = int(input("Bredde: "))
skriv_ut_firkant(hoyde, bredde, "#")

# skriv_ut_firkant()
# en funksjon har paranteser etter seg mens variabler har ikke det
# om kodenlinjen over kjører uten de tre over så vil default verdiene til funksjonen bli brukt i funksjonen
