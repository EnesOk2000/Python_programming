# Range med en parameter: range(til) gir rekka 0, 1, 2, ..., til-1
tall = int(input("Tallet jeg skal ta fakultet av: "))
# Range med to parameter: range(fra, til) gir rekka fra, fra+1, fra+2, ..., til-1
resultat = 1
while tall < 0:
    print("Kan ikke ta fakultet av negative tall.")
    tall = int(input("Tallet jeg skal ta fakultet av: "))
for i in range(1, tall+1):
    resultat *= i
print(resultat)

# Range med tre parametre: range(fra, til, steg)
# steg sier noe om hvor mange skritt den hopper med fra steg til steg. skritteller
for j in range(1, 10, 2):
    print(j)
print("\n")
for k in range(10, 1, -1):
    print(k)




