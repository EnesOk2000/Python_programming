import volum_rom # filen du skal importere fra må ligge i samme mappe som denne filen
volum_rom.funk_vol() # importerer funksjonen "funk_vol()" fra "volum_rom" python script filen.


