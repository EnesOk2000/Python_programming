def les_inn_flyttall(representerer):
    tall_streng = input(representerer + ": ")
    tall = float(tall_streng)
    while tall <= 0:
        print(representerer + " må være positiv!")
        tall_streng = input(representerer + ": ")
        tall = float(tall_streng)
    return tall

def funk_vol():
    print("Volumet til et rom:")
    lengde = les_inn_flyttall("Lengde")
    bredde = les_inn_flyttall("Bredde")
    hoyde = les_inn_flyttall("Hoyde")
    volum = lengde*bredde*hoyde
    print("Volumet er: ", str(volum))

if __name__ == "__main__":
    # __name__ er et spesialnavn og i denne if-setningen sjekkes det hvilket navn det er på scriptet som kjøres nå
    # spesialnavn begynner og slutter med to underscore
    print("Kjører main koden")
    funk_vol()
    # det denne if setningen gjør i praksis er å kjøre kodene inni if-setningen hvis man kjører dette scriptet fra scriptet i seg selv,
    # men hvis man importerer dette scriptet og eventuelt en funksjon i det så vil disse linjene med kode i if-setningen ikke kjøre.
