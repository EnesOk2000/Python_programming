


import turtle as t

t.setup(1200,700)
t.tracer(0)
t.penup()
t.goto(-500,-300)
t.pendown()

for x in range(0,51):
    t.dot()
    t.forward(20)
t.penup()
t.goto(-500,-320)
for x in range(0,51):
    t.write(x)
    t.forward(20)

t.goto(-500,-300)
t.left(90)
t.pendown()

for y in range(0,31):
    t.dot()
    t.forward(20)
t.penup()
t.goto(-520,-305)
for y in range(0,31):
    t.write(y)
    t.forward(20)
t.goto(-500,-300)
t.pendown()


# 0.5x + 10
angle = 45 / 2
t.goto(-500,-300 + 10*20)
t.setheading(0)
t.left(angle)
for q in range(51):
    t.forward(20)


t.update()
t.done()
