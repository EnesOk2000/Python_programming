import turtle as t

a=float(input("Stigningstall: "))
b=float(input("Konstantledd: "))

t.setup(1400,800)
t.tracer(0)
t.hideturtle()

for x in range(0,33):
    t.dot()
    t.forward(20)
t.penup()
t.goto(0,-20)
for x in range(0,33):
    t.write(x)
    t.forward(20)

t.goto(0,0)
t.left(90)
t.pendown()

for y in range(0,19):
    t.dot()
    t.forward(20)
t.penup()
t.goto(-20,-5)
for y in range(0,19):
    t.write(y)
    t.forward(20)
t.goto(0,0)
t.pendown()
t.pencolor("red")

for q in range(1000):
    x=q*20
    y=a*x+b*20
    if q != 0:
        t.goto(x,y)
        t.dot()
    else:
        t.penup()
        t.goto(x,y)
        t.dot()
        t.pendown()
    if y >= 360 or x >= 640:
        break

t.penup()
t.goto(0,0)
t.pendown()
t.pencolor("green")

for q in range(1000):
    x=q*20
    y=a*q**2*20+b*20
    if q != 0:
        t.goto(x,y)
        t.dot()
    else:
        t.penup()
        t.goto(x,y)
        t.dot()
        t.pendown()
    if y >= 360 or x >= 640:
        break


t.update()
t.done()

### Kan lage en v3 med 4 kvadranter. og flere funksjonstyper
