tall = 140 # primtall opp til 100
for tall in range(2, tall + 2):
    primtall = True
    for divisor in range(2, (tall//2 +1)):
        if tall % divisor == 0:
            primtall = False
            break
    if primtall == True:
        print(tall, end=" ")
print("Ferdig")
