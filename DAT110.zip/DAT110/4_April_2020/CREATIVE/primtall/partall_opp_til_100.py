tall=100 # partall opp til 100

for tall in range(tall+1):
   if tall % 2 == 0:        # kan skrive != for å få oddetall
       print(tall,end=" ")
print("Ferdig")
