tall=25
for divisor in range(1,tall+1):
    x = tall / divisor
    print(tall,"/",divisor,"=",format(x, "10.2f"))

print("***********************")

primtall=23
for divisor in range(1,primtall+1):
    x = primtall / divisor
    print(primtall,"/",divisor,"=",format(x, "10.2f"))
