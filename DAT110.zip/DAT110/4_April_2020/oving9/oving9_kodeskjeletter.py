# oppgave a) er å skrive innholdet i denne klassen
class Integrator:
    # Merk: time_start skal være 0 og trengs derfor ikke som parameter
    def __init__(self, delta_time, time_end):
        # Fyll inn kode for å sette egenskapene delta_time og time_end her
        pass

    def integrate(self, function, initial_condition_vector):
        # Fyll inn kode for å gjøre selve integreringen, som beskrevet i avsnittet
        # "numerisk integrasjon" her.
        pass


# Oppgave b) og c) er å skrive to versjoner av denne klassen. Versjonene
# skal begge være implementasjoner av grensesnittet "Evaluate"
class Function:
    # Denne skal ta flere parametere enn self, sjekk oppgave b) og c)
    # for de to ulike funksjonsklassene. De ulike funksjonsklassene tar
    # ulike parametre til konstruktøren.
    def __init__(self):
        # Fyll inn kode for å sette egenskapene
        pass

    # Denne funksjonen skal regne ut og returnere en endringsvektor basert på
    # tilstandsvektoren. Bruk formelen oppgitt i oppgaven.
    # Merk at parameteren "tidspunkt" egentlig er unødvendig
    # i denne oppgaven, og er med siden eksemplet er hentet fra et mer komplekst
    # eksempel.
    def evaluate(self, tidspunkt, tilstandsvektor):
        pass
