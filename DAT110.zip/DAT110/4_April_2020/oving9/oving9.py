import numpy as np
import math as m
import matplotlib.pyplot as plt

class integrator:
    def __init__(self, delta_tid, tid_slutt, funksjon, original_vektor):
        self.delta_tid = delta_tid
        self.tid_slutt = tid_slutt
        self.funksjon = funksjon
        self.original_vektor = original_vektor
        self.parameter_vektor = self.parameter_vektor
        self.naatid = 0.0

    def begynn(self):
        self.parameter_vektor = self.original_vektor
        self.naatid = 0.0

    def neste(self):
        self.naatid += self.delta_tid
        if self.naatid > self.tid_slutt:
            raise StopIteration
        change_vector = self.funksjon.evaluer(self.naatid, self.parameter_vektor)
        for i in range(len(self.parameter_vektor)):
            self.parameter_vektor[i] += self.delta_tid * change_vector[i]
        return self.parameter_vektor[:]

class basic_ball_track:
    def __init__(self, gravity):
        self.gravity = gravity

    def evaluer(self, timestamp, condition_vector):
        x_speed = condition_vector[2]
        y_speed = condition_vector[3]
        return [x_speed, y_speed, 0, self.gravity]


class air_resistance_ball_track:
    def __init__(self, gravity, air_resistance):
        self.gravity = gravity
        self.air_resistance = air_resistance
        pass

    def evaluer(self, timestamp, condition_vector):
        x_speed = condition_vector[2]
        y_speed = condition_vector[3]
        speed = m.sqrt(x_speed**2+y_speed**2)
        c = self.air_resistance
        return [x_speed, y_speed, -(c*x_speed*speed), self.gravity-(c*y_speed*speed)]


class Main_Program:
    def __init__(self):
        self.gravity = -9.81
        self.timestepper = 0.01
        self.end_time = 0.45
        self.air_resistance = 0.5
        self.start_condition = [0, 0, 1, 2]

    def run(self):
        nbr_rows = int(self.end_time / self.timestepper)
        nbr_columns = len(self.start_condition)
        matrix = np.zeros((nbr_rows, nbr_columns))
        matrix[0, :] = self.start_condition
        matrix_ar = np.zeros((nbr_rows, nbr_columns))
        matrix_ar[0, :] = self.start_condition
        for i in range(45):
            funksjon = basic_ball_track(self.gravity)
            Integrator = integrator(self.timestepper, self.end_time, funksjon, self.start_condition)
            matrix[i, :] = Integrator.neste()
            funksjon_lm = air_resistance_ball_track(self.gravity, self.air_resistance)
            Integrator = integrator(self.timestepper, self.end_time, funksjon_lm, self.start_condition)
            matrix_ar[i, :] = Integrator.neste()
        plt.plot(matrix[:, 0], matrix[:, 1])
        plt.plot(matrix_ar[:, 0], matrix[:, 1])
        plt.show()

if __name__ == "__main__":
    trajectory = Main_Program()
    trajectory.run()
