import turtle as t
from random import randint

t.speed(0)
#t.tracer(0)

t.penup()
t.goto(-300,0)
t.pendown()
t.forward(20)
def stick(start,slutt):
    for i in range(start,slutt,-1):
        turn=randint(0,2)
        if turn==0:
            r=randint(0,1)
            if r==0:
                t.left(i)
                t.forward(i)
                t.backward(i)
                t.right(i)
            else:
                t.right(i)
                t.forward(i)
                t.backward(i)
                t.left(i)
        t.forward(5)

for i in range(70,20,-1):
        turn=randint(0,2)
        if turn==0:
            r=randint(0,1)
            if r==0:
                t.left(45)
                stick(70,20)
            else:
                t.right(45)
                stick(70,20)
        t.forward(5)
t.update()
t.done()
