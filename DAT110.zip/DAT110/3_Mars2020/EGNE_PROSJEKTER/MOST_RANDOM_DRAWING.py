import turtle as t
from random import randint

t.speed(0)
#t.tracer(0)
t.bgcolor("peach puff") # thistle     peach puff      papaya whip     blanched almond     bisque      steel blue      lawn green

t.setup(700, 700)

for i in range(100):
    x=randint(-30,30)*10
    y=randint(-10,10)*30
    t.goto(x,y)
    #t.dot()
t.done()
