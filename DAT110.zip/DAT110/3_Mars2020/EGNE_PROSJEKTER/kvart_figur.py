import turtle as t
from random import randint
import math as m

#t.speed(0)
t.tracer(0)
# det blir feil i tegningen med "t.tracer(0)" hvis ikke "t.update()" er med


for i in range(0,46): # for hver 60 lages det en krusedull
    #t.left(10)
    #t.forward(10)
    t.left(i)
    lengde=200-2*i
    t.forward(lengde)
    t.goto(0,0)
    t.right(i)
for i in range(46,91):
    t.left(i)
    lengde=20+2*i
    t.forward(lengde)
    t.goto(0,0)
    t.right(i)
t.update()
t.done()
