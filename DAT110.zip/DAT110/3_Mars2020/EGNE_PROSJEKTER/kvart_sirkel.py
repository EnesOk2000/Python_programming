import turtle as t
import math as m

LENGDE=300

t.speed(0)
#t.tracer(0)

for i in range(4):
    t.forward(LENGDE)
    t.backward(LENGDE)
    t.left(90)

def kvart(LENGDE=300):
    for x in range(LENGDE):
        t.left(90)
        t.forward(m.sqrt(LENGDE**2-x**2))
        t.backward(m.sqrt(LENGDE**2-x**2))
        t.right(90)
        t.forward(1)
kvart()

t.update()
t.done()
