import turtle as t
from random import randint

t.speed(0)
#t.tracer(0)
t.hideturtle()
t.backward(200)
t.forward(400)
t.backward(200)
t.left(90)
t.forward(20)
def stick(start,slutt):
    for i in range(start,slutt,-1):
        turn=randint(0,2)
        if turn==0:
            r=randint(0,4)
            if r==0:
                t.left(i)
                t.forward(i)
                t.backward(i)
                t.right(i)
            elif r==1:
                t.right(i)
                t.forward(i)
                t.backward(i)
                t.left(i)
        t.forward(5)


stick(70,20)
t.forward(40)
t.update()
t.done()
