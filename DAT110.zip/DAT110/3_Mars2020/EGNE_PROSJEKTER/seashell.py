import turtle as t
from random import randint

#t.speed(0)
t.tracer(0)

for i in range(1000):
    t.left(i)
    t.forward(i*0.3)
    t.goto(0,0)
    t.right(i)
t.done()
