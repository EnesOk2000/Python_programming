import turtle as t

LENGDE=300

#t.speed(0)
t.tracer(0)

for i in range(4):
    t.forward(LENGDE)
    t.backward(LENGDE)
    t.left(90)

def kvart(LENGDE=300):
    for i in range(LENGDE):
        t.left(90)
        t.forward(i**2/LENGDE)
        t.backward(i**2/LENGDE)
        t.right(90)
        t.forward(1)

t.backward(LENGDE)
for i in range(4):

    kvart()
    t.left(90)
    t.forward(LENGDE)
    t.right(180)
t.update()
t.done()
