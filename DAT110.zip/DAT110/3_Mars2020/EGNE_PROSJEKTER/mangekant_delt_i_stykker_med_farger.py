import turtle as t
import math

antVinkler=int(input("Skriv inn antall kanter: "))

t.setup(700, 700)
HYPO=300
t.speed(1)
#t.tracer(0)
t.left(270)
sumV=180*(antVinkler-2)
u=sumV/antVinkler
c=360/antVinkler

C=math.radians(c)
U=math.radians(u)

KATET_liten=(HYPO*math.sin(C))/math.sin(U)
if KATET_liten < 0:
    KATET_liten=-KATET_liten

print(sumV,"/",antVinkler,"=",u,"og vinkel inni er:",c)
print(KATET_liten)

for n in range(1,2):

    t.forward(HYPO)
    t.left(u)
    t.forward(KATET_liten)
    t.left(u)
    t.goto(0,0)
    #t.left(180)
    #t.left(c)
    #t.update()

t.done()

#if n % 2 == 0:
       # t.end_fill()
   # else:
     #   t.begin_fill()
