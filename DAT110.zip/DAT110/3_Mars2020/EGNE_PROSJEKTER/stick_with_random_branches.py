import turtle as t
from random import randint

t.speed(1)
#t.tracer(0)

t.penup()
t.goto(-300,0)
t.pendown()

for i in range(100):
    forward=randint(0,2)
    if forward==0:
        r=randint(0,1)
        turn=randint(3,7)*10
        forward=randint(1,10)*10
        if r==0:
            t.left(turn)
            t.forward(forward)
            t.backward(forward)
            t.right(turn)
        else:
            t.right(turn)
            t.forward(forward)
            t.backward(forward)
            t.left(turn)
    t.forward(10)
t.update()
t.done()
