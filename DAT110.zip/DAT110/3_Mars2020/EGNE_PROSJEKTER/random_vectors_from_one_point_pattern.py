import turtle as t
from random import randint

#t.speed(0)
t.tracer(0)

for i in range(20):
    xpos=randint(-50,50)*11
    ypos=randint(-50,50)*7
    t.penup()
    t.goto(xpos,ypos)
    t.pendown()
    for j in range(100):
        t.goto(xpos,ypos)
        VINKEL=randint(0,360)
        t.left(VINKEL)
        LENGDE=randint(1,10)*10
        t.forward(LENGDE)
t.update()
t.done()
