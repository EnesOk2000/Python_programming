import turtle as t

antVinkler=int(input("Skriv inn antall kanter: "))

t.setup(700, 700)
LENGDE=300
t.speed(10)
#t.tracer(0)

t.penup()
t.goto(0,-LENGDE)
t.pendown()

t.circle(LENGDE,360,antVinkler) # på 20 og 30 for i er det lett å se at det ikke er en sirkel, men ved 40 og opp så kan man ikke telle kantene selv lenger

t.penup()
t.goto(0,0)
t.pendown()
t.left(270)
for n in range(1,antVinkler+1):
    t.left(360/antVinkler)
    t.forward(LENGDE)
    t.backward(LENGDE)
    #t.update()

t.done()
