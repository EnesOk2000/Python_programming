import turtle as t

t.setup(700, 700)
t.speed(7)
#t.tracer(0)

t.penup()
t.goto(0,-300)
t.pendown()

for i in range(1,51):
    t.circle(300,360,i) # på 20 og 30 for i er det lett å se at det ikke er en sirkel, men ved 40 og opp så kan man ikke telle kantene selv lenger
    #t.update()

t.done()
