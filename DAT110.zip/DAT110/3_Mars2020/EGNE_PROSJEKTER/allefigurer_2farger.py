import turtle as t
import math as m

t.speed(10)
t.right(90)

antV=int(input("Antall kanter: "))
sumV=180*(antV-2)
UV=sumV/antV
SV=360/antV

print("sumV:",sumV)
print("UV:",UV/2)
print("SV:",SV)

kli=100
kla=3*kli
hypo=m.sqrt(kli**2+kla**2)
print(hypo)

for h in range(antV):
    if h % 2 == 0:
        t.fillcolor("pink")
    else:
        t.fillcolor("sky blue")
    #else:
        #t.fillcolor("red")
    t.begin_fill()

    t.forward(hypo)
    t.left(180-UV/2)
    print(t.heading())
    t.forward(kli*2)
    t.left(180-UV/2)
    t.forward(hypo)

    t.end_fill()
    t.left(180)
t.done()
