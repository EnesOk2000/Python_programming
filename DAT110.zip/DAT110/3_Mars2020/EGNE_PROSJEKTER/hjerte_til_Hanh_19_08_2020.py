LENGDE=50
def firkant():
    for j in range(4):
        t.forward(LENGDE)
        t.right(90)

import turtle as t
t.setup(700,700)
t.speed(10)

t.penup()
t.goto(-270,270)
t.pendown()
def newline():
    t.backward(9*LENGDE)
    t.right(90)
    t.forward(LENGDE)
    t.left(90)

def rad():
    for i in range(9):
        firkant()
        t.forward(LENGDE)
    newline()

for i in range(8):
    rad()

def skip():
    t.forward(LENGDE)

def fill():
    t.fillcolor("red")
    t.begin_fill()
    firkant()
    t.end_fill()

t.penup()
t.goto(-270,270)
t.pendown()
t.right(90)
t.forward(7*LENGDE)
t.left(90)
t.forward(4*LENGDE)

fill()
t.backward(4*LENGDE)
t.left(90)
t.forward(LENGDE)
t.right(90)
t.forward(3*LENGDE)
for i in range(3):
    fill()
    t.forward(LENGDE)

t.backward(6*LENGDE)
t.left(90)
t.forward(LENGDE)
t.right(90)
t.forward(2*LENGDE)
for i in range(5):
    fill()
    t.forward(LENGDE)
t.backward(7*LENGDE)
t.left(90)
t.forward(LENGDE)
t.right(90)
t.forward(LENGDE)
for i in range(7):
    fill()
    t.forward(LENGDE)
t.backward(8*LENGDE)
t.left(90)
t.forward(LENGDE)
t.right(90)
for i in range(9):
    fill()
    t.forward(LENGDE)
t.backward(9*LENGDE)
t.left(90)
t.forward(LENGDE)
t.right(90)
t.forward(LENGDE)
for i in range(3):
    fill()
    t.forward(LENGDE)
skip()
for i in range(3):
    fill()
    t.forward(LENGDE)
t.backward(8*LENGDE)
t.left(90)
t.forward(LENGDE)
t.right(90)
t.forward(2*LENGDE)
fill()
skip()
skip()
skip()
skip()
fill()


t.penup()

t.goto(-300,-250)
t.pencolor("red")
t.write("I love you, Hanh", font=("Arial",60))





t.update()

t.done()
