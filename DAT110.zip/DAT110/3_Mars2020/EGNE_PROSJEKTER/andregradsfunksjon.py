import turtle as t

LENGDE=200

#t.speed(0)
t.tracer(0)
for i in range(4):
    t.forward(LENGDE)
    t.backward(LENGDE)
    t.left(90)


for i in range(LENGDE):
    t.left(90)
    t.forward(i**2/LENGDE)
    t.backward(i**2/LENGDE)
    t.right(90)
    t.forward(1)

t.backward(LENGDE)
t.left(180)

for i in range(LENGDE):
    t.right(90)
    t.forward(i**2/LENGDE)
    t.backward(i**2/LENGDE)
    t.left(90)
    t.forward(1)

t.update()
t.done()
