import turtle as t
from random import randint

#t.speed(0)
t.tracer(0)

for i in range(361):
    t.left(i)
    t.forward(i)
    #t.left(180)
    #t.forward(LENGDE)
    #t.left(180)

    #t.penup()
    t.goto(0,0)
    #t.pendown()
    t.right(i)
t.update()
t.done()
