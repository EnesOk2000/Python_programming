number = int(input("Skriv inn et positivt heltall som du vil ha gjort om til binær: "))
orgnumber = number
array = list()

while number != 0:
    remainder = number % 2
    array.append(remainder)
    number = int(number / 2)

if number == 0:
    array.append(0)

array = list(reversed(array))
string = ""
for element in array:
    string = string + str(element)

seperate = 4
string = string.lstrip("0")
string2 = [string[i:i+seperate] for i in range(0, len(string), seperate)]
string3 = ' '.join(string2)
print(orgnumber, "skrevet i binær er:", string3)
print("Antall bit:",str(len(string)))
byte=0
while byte>-1:
    byte+=1
    if 8*byte > len(string):
        print("Antall byte:",str(byte))
        break
