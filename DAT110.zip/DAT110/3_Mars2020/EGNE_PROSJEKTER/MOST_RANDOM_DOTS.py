import turtle as t
from random import randint

t.speed(0)
t.tracer(0)
t.bgcolor("peach puff") # thistle     peach puff      papaya whip     blanched almond     bisque      steel blue      lawn green

t.setup(500, 500)
t.penup()
for i in range(500): # 100, 3000, 30000
    x=randint(-20,20)*10
    y=randint(-20,20)*10
    t.goto(x,y)
    t.dot()
t.done()
