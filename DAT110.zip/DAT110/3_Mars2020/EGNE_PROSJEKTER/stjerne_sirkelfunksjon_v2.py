import turtle as t
import math as m

LENGDE=300

t.speed(0)
#t.tracer(0)

for i in range(4):
    t.forward(LENGDE)
    t.backward(LENGDE)
    t.left(90)

def kvart(LENGDE=300):
    for x in range(0,LENGDE,5):
        t.left(90)
        t.forward(LENGDE-m.sqrt(LENGDE**2-x**2))
        t.backward(LENGDE-m.sqrt(LENGDE**2-x**2))
        t.right(90)
        t.forward(5)

t.backward(LENGDE)
for i in range(4):
    kvart()
    t.left(90)
    t.forward(LENGDE)
    t.right(180)

t.update()
t.done()
