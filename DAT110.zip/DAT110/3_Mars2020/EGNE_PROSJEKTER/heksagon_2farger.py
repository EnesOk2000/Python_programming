import turtle as t

b=200
n=int(input("Oppgi et tall: "))
cv=360/n
for h in range(6):
    if h % 2 == 0:
        t.fillcolor("pink")
    else:
        t.fillcolor("sky blue")
    t.begin_fill()
    for i in range(3):
        t.forward(b)
        t.left(cv)
    t.end_fill()
    t.left(60)
t.done()
