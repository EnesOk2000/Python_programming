import turtle as t
from random import randint

t.speed(0)
#t.tracer(0)

for i in range(1000):
    VINKEL=randint(0,360)
    t.left(VINKEL)
    LENGDE=randint(1,30)*10
    t.forward(LENGDE)
    #t.left(180)
    #t.forward(LENGDE)
    #t.left(180)

    #t.penup()
    t.goto(0,0)
    #t.pendown()

    #t.right(VINKEL)
t.done()
