import turtle as t
import math as m

t.speed(10)
t.right(90)

antV=int(input("Antall kanter: "))
sumV=180*(antV-2)
UV=sumV/antV
SV=360/antV

#print("sumV:",sumV)
#print("UV:",UV/2)
#print("SV:",SV)

kli=100
kla=3*kli
hypo=m.sqrt(kli**2+kla**2)
#print(hypo)

for h in range(1,antV+1):
    if antV % 2 == 0:
        if h % 2 == 0:
            t.fillcolor("pink")
        else:
            t.fillcolor("sky blue")
    else:
        if h % 2 == 0:
            t.fillcolor("red")
        #elif h % 11 == 0:
            #t.fillcolor("cyan")
        #elif h % 7 == 0:
            #t.fillcolor("purple")
        #elif h % 5 == 0:
           # t.fillcolor("blue")
        #elif h % 3 == 0:
            #t.fillcolor("green")
        else:
            t.fillcolor("yellow")
            print(h)
    t.begin_fill()

    t.forward(hypo)
    x=t.xcor()
    y=t.ycor()
    t.backward(hypo)
    t.left(SV)
    t.forward(hypo)
    t.goto(x,y)
    t.goto(0,0)

    t.end_fill()

t.done()
