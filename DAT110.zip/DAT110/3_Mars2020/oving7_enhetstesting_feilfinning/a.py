import unittest
from sprite import *

class SpriteTest(unittest.TestCase):
    #
    # Tester egenskaper
    #
    def test_bredde_hoyde(self):
        #spriten = Sprite(0,0,-1,-1)
        #self.assertEqual(spriten.bredde, -1)
        #self.assertEqual(spriten.hoyde, -1)
        spriten = Sprite(0,0,0,0)
        self.assertEqual(spriten.bredde, 0)
        self.assertEqual(spriten.hoyde, 0)
        spriten = Sprite(0,0,1,1)
        self.assertEqual(spriten.bredde, 1)
        self.assertEqual(spriten.hoyde, 1)
        spriten = Sprite(0,0,1.5,1.5)
        self.assertEqual(spriten.bredde, 1.5)
        self.assertEqual(spriten.hoyde, 1.5)

    def test_xy(self):
        spriten = Sprite(-1,-1,0,0)
        self.assertEqual(spriten.x_start, -1)
        self.assertEqual(spriten.y_start, -1)
        spriten = Sprite(0,0,0,0)
        self.assertEqual(spriten.x_start, 0)
        self.assertEqual(spriten.y_start, 0)
        spriten = Sprite(1,1,0,0)
        self.assertEqual(spriten.x_start, 1)
        self.assertEqual(spriten.y_start, 1)
        spriten = Sprite(1.5,1.5,0,0)
        self.assertEqual(spriten.x_start, 1.5)
        self.assertEqual(spriten.y_start, 1.5)

    #
    # Tester metoder
    #
    def test_areal(self):
        spriten = Sprite(0,0,2,3)
        self.assertEqual(Sprite.areal(spriten),6)
        spriten = Sprite(0,0,4,3)
        self.assertEqual(Sprite.areal(spriten),12)

    def test_er_inni(self):
        spriten = Sprite(1,2,3,4)
        self.assertFalse(Sprite.er_inni(spriten, 0, 3)) # x for liten
        spriten = Sprite(1,2,3,4)
        self.assertFalse(Sprite.er_inni(spriten, 8, 3)) # x for stor
        spriten = Sprite(1,2,3,4)
        self.assertFalse(Sprite.er_inni(spriten, 2, 0)) # y for liten
        spriten = Sprite(1,2,3,4)
        self.assertFalse(Sprite.er_inni(spriten, 2, 8)) # y for stor
        spriten = Sprite(1,2,3,4)
        self.assertTrue(Sprite.er_inni(spriten, 2, 3)) # x og y inni

    def test_flytt(self):
        spriten = Sprite(6,5,4,3)
        self.assertEqual(Sprite.flytt(spriten,-4,-5),2)
        spriten = Sprite(6,5,4,3)
        self.assertEqual(Sprite.flytt(spriten,4,5),10)
        spriten = Sprite(6,5,4,3)
        self.assertEqual(Sprite.flytt(spriten,14,5),20)
        spriten = Sprite(6,5,4,3)
        self.assertEqual(Sprite.flytt(spriten,6.4,5),12.4)

if __name__ == "__main__":
    unittest.main()
